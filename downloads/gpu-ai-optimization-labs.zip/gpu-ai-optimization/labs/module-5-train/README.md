# Module 5 Lab · A Training Loop That Survives

**Time:** ~50 minutes · **Runs on:** any laptop (Python 3.9+ and numpy; each script finishes in under a minute) · **Optional:** PyTorch, or a machine with an NVIDIA GPU

Training runs are where the biggest GPU bills are, and where the most waste goes unnoticed. You will build, at laptop scale, the parts every serious training platform has:

| Script | Question it answers |
|---|---|
| `precision_demo.py` | Why BF16/FP16 compute, FP32 master weights, and loss scaling for FP16? |
| `train.py` | Is the "GPU" starving for data? Can the job survive a crash and a spot termination notice, and resume bit-for-bit? |
| `memory_calc.py` | How much memory does training an N-parameter model need per GPU, under DDP, ZeRO/FSDP and tensor parallel? |
| `goodput.py` | How much of the time we paid for became progress we kept? How often should we checkpoint? Is spot really cheaper? |
| `train_torch.py` | _Optional:_ the same loop with real PyTorch APIs (DataLoader workers, BF16 autocast, GradScaler, checkpoint/resume). |

> **Your numbers will differ.** Timings depend on your CPU and on what else is running. The patterns (who waits, what gets lost, which option is cheaper) do not. The final-weights fingerprint is deterministic and should match exactly.

---

## Stage 1 · Set up (5 min)

```bash
# macOS / Linux
cd labs/module-5-train
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt      # numpy only
python3 data/make_data.py            # rebuilds data/train.npz (already committed; same bytes every time)
```
```powershell
# Windows PowerShell
cd labs\module-5-train
py -m venv .venv; .venv\Scripts\Activate.ps1
pip install -r requirements.txt
py data\make_data.py
```
On Windows, use `py` wherever this guide says `python3`.

## Stage 2 · Mixed precision, in four experiments (8 min)

```bash
python3 precision_demo.py --out reports/precision.md
```

Expected (excerpt; the numbers are exact because it is deterministic):

```
  fp16            1     15.5%           0             1.114%      <- 15.5% of gradients become exactly 0
  fp16        1,024      0.1%           0             0.020%      <- loss scaling fixes it
  fp16       65,536      0.0%           9       step skipped      <- too big a scale overflows
  bf16            1      0.0%           0             0.135%      <- BF16: FP32's range, no scaling needed
  weights in fp16: 1.0 + 1,000 x 1e-4 = 1.0000   (should be 1.1000)
  weights in fp32: 1.0 + 1,000 x 1e-4 = 1.1000   (should be 1.1000)
  fp16 accumulator:   32.000
  bf16 accumulator:    4.000
  fp32 accumulator:  100.003
```

- **Underflow:** FP16's smallest normal number is about 6e-5; below about 3e-8 everything is 0. Gradients are often that small. Multiplying the loss by a scale (and dividing the gradients back in FP32) moves them into range. Real scalers are _dynamic_: start high, skip the step and halve on inf/NaN, grow again later.
- **Master weights:** an update smaller than half the gap between neighbouring 16-bit numbers simply disappears. That is why the optimizer keeps an FP32 copy of the weights.
- **Accumulation:** a 16-bit running sum stalls. Tensor cores take 16-bit (or FP8) inputs but accumulate in FP32.

**Do:** in one sentence each, explain why BF16 usually needs no loss scaler and FP16 does.

## Stage 3 · Feed the GPU: change one thing (10 min)

`train.py` trains a small MLP. Each batch costs a simulated 4 ms to "decode" (a stand-in for image decoding, tokenization, or a slow network read). With `--workers 0` the training loop does that work itself and waits; with `--workers 4`, background workers prepare batches ahead into a prefetch queue.

```bash
python3 train.py --run w0 --workers 0
python3 train.py --run w4 --workers 4
python3 goodput.py logs/w0.csv logs/w4.csv --out reports/goodput_workers.md
```

Expected (excerpt; your timings will differ, the fingerprint will not):

```
[w0] finished at step 2000: 2000 steps in 15.54 s = 128.7 steps/s | data-wait 54% of step time | compute 3.52 ms/step
     final weights fingerprint 9ce1a539d5eb
[w4] finished at step 2000: 2000 steps in 5.95 s = 336.2 steps/s | data-wait 1% of step time | compute 2.89 ms/step
     final weights fingerprint 9ce1a539d5eb
CHANGE ONE THING  logs/w0.csv -> logs/w4.csv
  data-wait share   54.4% -> 1.4%  (-53.0 pts)
  steps per second  128.6 -> 335.7  (+161%)
  goodput           45.2% -> 97.1%  (+51.9 pts)
```

Same model, same weights (identical fingerprint), **2.6x the steps per second**, and nothing about the model changed. On a real cluster, the w0 pattern shows up as GPU activity that comes in waves: busy, idle, busy, idle. That is why you look at activity over time, not the average.

Honest caveat: the workers here are threads, which works because the simulated decode is a sleep (sleeping releases Python's GIL). Real CPU-heavy decoding needs worker _processes_, which is what PyTorch's `DataLoader(num_workers=N)` gives you (see the optional track).

**Do:** try `--workers 1` and `--workers 2`. Find the smallest number of workers that gets data-wait under 5%.

## Stage 4 · Split the work: size the memory (7 min)

```bash
python3 memory_calc.py --params 7e9 --gpus 8 --out reports/memory_7b.md
python3 memory_calc.py --params 70e9 --gpus 64 --tp 8 --layers 80 --hidden 8192
```

Expected (excerpt; exact):

```
7B parameters, mixed precision + Adam = 16 bytes/param = 112 GB of model state
  weights 14 GB | gradients 14 GB | optimizer (FP32 master + m + v) 84 GB
  strategy                            weights   grads   optim  state/GPU  + act (recomp)  fits 80 GB?
  DDP (full copy per GPU)               14.0G   14.0G   84.0G     112.0G          113.1G  NO
  ZeRO-1 (optimizer sharded /8)         14.0G   14.0G   10.5G      38.5G           39.6G  yes
  ZeRO-2 (+ gradients sharded /8)       14.0G    1.8G   10.5G      26.2G           27.3G  yes
  ZeRO-3 / FSDP full shard /8            1.8G    1.8G   10.5G      14.0G           15.1G  yes
```

The 16 bytes per parameter are 2 (BF16 weights) + 2 (BF16 gradients) + 12 of optimizer state (FP32 master 4 + Adam m 4 + Adam v 4), **before activations**. A 7B model needs 112 GB of state, so it does not train on one 80 GB GPU with plain data parallel. Sharding divides it; the price is more communication (FSDP gathers each layer's weights in the forward and backward pass). Activation estimates are rough (see the script's docstring); with full activation recomputation they are small, without it they can dominate.

**Do:** find the smallest GPU count where a 13B model fits on 24 GB GPUs with FSDP (`--params 13e9 --gpu-mem 24 --gpus N`).

## Stage 5 · The spot drill: crash, notice, resume, goodput (15 min)

### 5a · Scripted drill (reproducible)

```bash
python3 train.py --run drill --workers 4 --ckpt-every 100 --crash-at 750               # hardware failure
python3 train.py --run drill --workers 4 --ckpt-every 100 --resume --preempt-at 1500    # termination notice
python3 train.py --run drill --workers 4 --ckpt-every 100 --resume                      # finish
python3 goodput.py logs/drill.csv --out reports/goodput_drill.md
```

Expected (excerpt):

```
  !! simulated hardware failure after step 750. No checkpoint, no goodbye.
[drill] session 2: resumed at step 700/2000 ...
  received simulated SIGTERM: saved checkpoint at step 1500 in 3.0 ms; exiting cleanly
[drill] session 3: resumed at step 1500/2000 ...
  train accuracy 98.9% | final weights fingerprint 9ce1a539d5eb       <- same as the run that never stopped
logs/drill.csv: 3 session(s), 2 restart(s), 2000 steps kept, 50 steps redone
  GOODPUT 93.6%
```

The crash lost the 50 steps since the last checkpoint (700 to 750). The termination notice lost nothing, because the handler saved first. The final weights are **bit-for-bit identical** to an uninterrupted run, because the checkpoint holds the weights, the Adam state, the step, and the random-number-generator state, and the data order is a function of the step.

Checkpoints are **atomic**: written to `latest.npz.tmp`, flushed to disk, then renamed over the old file. A crash in the middle of a save leaves the previous checkpoint intact.

### 5b · Do it by hand (the real signal)

```bash
python3 train.py --run spot --workers 4 --ckpt-every 100 --steps 6000
# after a few seconds: press Ctrl+C   (or, from a second terminal: kill -TERM <pid printed on the first line>)
python3 train.py --run spot --workers 4 --ckpt-every 100 --steps 6000 --resume
python3 goodput.py logs/spot.csv
```

You should see `received SIGINT: saved checkpoint at step N ...; exiting cleanly` (or `SIGTERM`). SIGTERM is what Kubernetes, and most clouds' spot/preemptible shutdown paths, send before a machine goes away; the grace period is short (often 30 seconds to 2 minutes), so the save must be fast.

**Windows:** Ctrl+C (SIGINT) works the same. There is no catchable SIGTERM from another process on Windows (`taskkill /F` ends the process instantly, like a hard crash), so use Ctrl+C or `--preempt-at`. Also, Python before 3.11 on Windows sleeps in ~15 ms ticks, so the 4 ms decode is slower there; the comparison still holds.

### 5c · Change one thing: checkpoint interval

```bash
python3 train.py --run c500 --workers 4 --ckpt-every 500 --crash-at 1480 --quiet
python3 train.py --run c500 --workers 4 --ckpt-every 500 --resume --quiet
python3 train.py --run c50  --workers 4 --ckpt-every 50  --crash-at 1480 --quiet
python3 train.py --run c50  --workers 4 --ckpt-every 50  --resume --quiet
python3 goodput.py logs/c500.csv logs/c50.csv --out reports/goodput_ckpt.md
```

Expected: `lost work 1.81 s -> 0.09 s (480 -> 30 steps redone)`, `goodput 77.4% -> 93.3%`. Checkpoint time went up (0.2% to 2.6% of wall time): that is the trade-off Young's formula balances.

### 5d · Choose the interval, and price spot honestly

```bash
python3 goodput.py --young --ckpt-cost-s 60 --mtbf-h 3
python3 goodput.py --simulate --out reports/spot_vs_ondemand.md
```

Expected (excerpt; exact, the simulation is seeded):

```
Young's approximation: tau = sqrt(2 x 60 s x 3 h) = 19.0 min between checkpoints

  ckpt every | on-demand goodput  $ per run | spot goodput  $ per run
      19 min |             94.7%     12,980 |        85.3%      5,765
     110 min |             97.9%     12,552 |        68.2%      7,206
     360 min |             96.2%     12,772 |        29.8%     16,485
  best spot:      every 19 min -> $5,765 (goodput 85.3%), 54% cheaper than the best on-demand run
  spot, checkpoint every 360 min -> $16,485: 31% MORE than the best on-demand run.
```

The job: 48 hours of compute on 64 GPUs. **All prices and failure rates are examples** ($4.00 vs $1.60 per GPU-hour; job-level MTBF 100 h on-demand, 3 h on spot); change the flags to your own. Spot done right is less than half the price. Spot with a lazy checkpoint interval costs _more_ than on-demand. Young's approximation (tau = sqrt(2 x checkpoint cost x MTBF)) assumes failures are random and the checkpoint cost is small compared with the MTBF; the simulation confirms it lands near the cheapest interval.

---

## Optional track · Real PyTorch (`train_torch.py`, verified on CPU)

```bash
pip install torch                                         # CPU wheels are fine
python3 train_torch.py --workers 0                        # starved:  44.1 steps/s, data-wait 85%
python3 train_torch.py --workers 2                        # fed:     109.9 steps/s, data-wait 66% (2-core machine)
python3 train_torch.py --workers 2 --dtype fp32           # loss at step 200: 0.341 vs 0.342 with bf16
python3 train_torch.py --run tdrill --workers 2 --ckpt-every 50 --preempt-at 120
python3 train_torch.py --run tdrill --workers 2 --ckpt-every 50 --resume   # fingerprint 220a0ed4089d, same as uninterrupted
```

What it uses, and what to say about each:

- `DataLoader(num_workers=N, prefetch_factor=2, persistent_workers=True, pin_memory=True on GPU)`: worker **processes** decode samples in parallel; pinned (page-locked) host memory lets `.to("cuda", non_blocking=True)` overlap the copy with compute. More workers than CPU cores stops helping (the build machine had 2 cores, so data-wait stayed at 66%).
- `torch.autocast(device_type, dtype=torch.bfloat16)`: matmuls run in BF16; parameters stay FP32 (they are the master weights). On a CPU this is not faster; on tensor-core GPUs (A100, H100) it typically is, and it halves activation memory. `--dtype fp16` adds `torch.amp.GradScaler` (dynamic loss scaling).
- Checkpoint = model + optimizer + step + RNG state (+ scaler), saved to a temp file then `os.replace`. A private `generator=` on the DataLoader keeps worker seeding from consuming the global RNG, which is what makes resume bit-for-bit. Workers ignore SIGINT so Ctrl+C reaches only the main loop.

On a real multi-GPU job you would launch with `torchrun --nproc_per_node=8 train.py`, wrap the model in `FullyShardedDataParallel` (FSDP) to shard parameters, gradients and optimizer state, and save with `torch.distributed.checkpoint` (each rank writes its own shard in parallel; `async_save` lets training continue while the files are written). FP8 training (for example NVIDIA Transformer Engine on H100-class GPUs) can be faster again, but compare its loss curve against a BF16 baseline before trusting it. Not tested by this course's build; check your framework's docs for the current API.

---

## Deliverable (portfolio)

Commit `reports/` and add a Module 5 section to `FINDINGS.md`:

1. Baseline: data-wait share and steps/s with `--workers 0`
2. The bottleneck and how you know (data-wait vs. compute per step)
3. The one change (`--workers 4`), and the result: data-wait 54% -> 1%, steps/s +161% (use your numbers)
4. The drill: what a crash cost (steps redone), what a termination notice cost (nothing), goodput, and the matching fingerprint
5. The spot decision: your checkpoint interval (Young), and effective cost per run, spot vs. on-demand

**Resume line you can now defend:** _Built a fault-tolerant training loop (atomic checkpoints, SIGTERM handling, bit-for-bit resume) and cut data-loader stall from 54% to 1% of step time (+161% steps/s); modelled spot training at 54% lower cost per run with Young's checkpoint interval._

## Interview check

- GPU utilization comes in waves during training. What do you check? (data-wait per step, loader workers, CPU, storage; activity over time, not the average)
- How much memory does training a 7B model with Adam need, and how does FSDP help? (16 bytes/param = 112 GB before activations; shard params, grads and optimizer state across GPUs)
- How would you run training on spot GPUs safely? How often do you checkpoint? (handle SIGTERM, atomic + frequent checkpoints, Young's tau = sqrt(2 x C x MTBF), measure goodput and cost per run)
