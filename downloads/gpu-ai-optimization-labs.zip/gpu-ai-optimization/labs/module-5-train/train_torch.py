#!/usr/bin/env python3
"""
Module 5 · Optional track — the same survivable loop, in real PyTorch.

Not required for the course. Needs `pip install torch` (CPU wheels are fine).
Verified on CPU; on an NVIDIA GPU pass --device cuda (pinned memory and the
FP16 GradScaler path switch on there).

What it shows, with the real APIs:
  * DataLoader(num_workers=N, prefetch_factor, pin_memory, persistent_workers):
    worker PROCESSES do the slow per-sample "decode" (a sleep here), so the
    training loop does not wait for it.
  * torch.autocast(dtype=torch.bfloat16): matmuls in BF16, parameters stay
    FP32 (the master weights), no loss scaling needed. --dtype fp16 adds
    torch.amp.GradScaler (dynamic loss scaling).
  * Atomic checkpoints (torch.save to a temp file, then os.replace) holding the
    model, optimizer, step and RNG state; a SIGTERM/SIGINT handler that saves
    at the next step boundary; --resume that continues bit-for-bit.

Usage:
  python3 train_torch.py --workers 0                  # starved
  python3 train_torch.py --workers 4                  # fed
  python3 train_torch.py --dtype fp32                 # compare against BF16 autocast
  python3 train_torch.py --run tdrill --ckpt-every 50 --preempt-at 120
  python3 train_torch.py --run tdrill --ckpt-every 50 --resume
"""
import argparse, os, signal, sys, time
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset, Sampler

HERE = os.path.dirname(os.path.abspath(__file__))
STOP = {"flag": None}


class SlowSynthetic(Dataset):
    """Deterministic samples; each one costs `decode_ms` to "decode"."""
    def __init__(self, n=8192, d=32, classes=10, decode_ms=0.05, seed=5):
        g = torch.Generator().manual_seed(seed)
        self.x = torch.randn(n, d, generator=g)
        w = torch.randn(d, classes, generator=g)
        self.y = (self.x @ w).argmax(1)
        self.decode_s = decode_ms / 1000

    def __len__(self):
        return len(self.x)

    def __getitem__(self, i):
        time.sleep(self.decode_s)
        return self.x[i], self.y[i]


class ResumableSampler(Sampler):
    """Same order every run (seeded per epoch) and able to start mid-epoch, so a resumed run sees the same batches."""
    def __init__(self, n, batch, seed, start_batch, total_batches):
        self.n, self.batch, self.seed, self.start, self.total = n, batch, seed, start_batch, total_batches

    def __iter__(self):
        per_epoch = self.n // self.batch
        for b in range(self.start, self.total):
            e, pos = divmod(b, per_epoch)
            perm = torch.randperm(self.n, generator=torch.Generator().manual_seed(self.seed + 1000 + e))
            yield from perm[pos * self.batch:(pos + 1) * self.batch].tolist()

    def __len__(self):
        return (self.total - self.start) * self.batch


def worker_init(_):
    # Ctrl+C reaches every process in the terminal's group. Let only the main process react,
    # so workers keep serving batches until the main loop has saved its checkpoint.
    signal.signal(signal.SIGINT, signal.SIG_IGN)


def on_signal(signum, frame):
    STOP["flag"] = signal.Signals(signum).name


def save(path, step, model, opt, scaler):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    state = {"step": step, "model": model.state_dict(), "opt": opt.state_dict(), "rng": torch.get_rng_state(),
             "scaler": scaler.state_dict() if scaler else None,
             "cuda_rng": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None}
    tmp = path + ".tmp"
    torch.save(state, tmp)
    os.replace(tmp, path)


def fingerprint(model):
    import hashlib
    h = hashlib.sha256()
    for k, v in sorted(model.state_dict().items()):
        h.update(v.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()[:12]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--run", default="torch")
    ap.add_argument("--steps", type=int, default=200)
    ap.add_argument("--batch", type=int, default=128)
    ap.add_argument("--workers", type=int, default=0)
    ap.add_argument("--prefetch", type=int, default=2, help="prefetch_factor (batches per worker)")
    ap.add_argument("--decode-ms", type=float, default=0.05, help="simulated decode cost per SAMPLE")
    ap.add_argument("--dtype", choices=["bf16", "fp16", "fp32"], default="bf16")
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--ckpt-every", type=int, default=0)
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--preempt-at", type=int)
    a = ap.parse_args()

    signal.signal(signal.SIGINT, on_signal)
    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, on_signal)
    torch.manual_seed(0)
    torch.set_num_threads(1)
    dev = torch.device(a.device)
    model = nn.Sequential(nn.Linear(32, 256), nn.ReLU(), nn.Dropout(0.1), nn.Linear(256, 256), nn.ReLU(),
                          nn.Dropout(0.1), nn.Linear(256, 10)).to(dev)
    opt = torch.optim.AdamW(model.parameters(), lr=1e-3)
    scaler = torch.amp.GradScaler(dev.type) if a.dtype == "fp16" else None
    ckpt = os.path.join(HERE, "ckpt", a.run, "latest.pt")
    step = 0
    if a.resume:
        if not os.path.exists(ckpt):
            sys.exit(f"no checkpoint at {os.path.relpath(ckpt)}")
        st = torch.load(ckpt, map_location=dev, weights_only=False)   # our own file; trusted
        model.load_state_dict(st["model"]); opt.load_state_dict(st["opt"]); torch.set_rng_state(st["rng"].cpu())
        if st.get("cuda_rng") is not None and torch.cuda.is_available():
            torch.cuda.set_rng_state_all(st["cuda_rng"])
        if scaler and st["scaler"]:
            scaler.load_state_dict(st["scaler"])
        step = st["step"]

    ds = SlowSynthetic(decode_ms=a.decode_ms)
    # A private generator: the DataLoader draws worker seeds from it, not from the global RNG
    # that dropout uses, so a resumed run consumes exactly the same random numbers.
    kw = dict(num_workers=a.workers, pin_memory=(dev.type == "cuda"), generator=torch.Generator().manual_seed(1),
              worker_init_fn=worker_init)
    if a.workers > 0:
        kw.update(prefetch_factor=a.prefetch, persistent_workers=True)
    dl = DataLoader(ds, batch_size=a.batch, sampler=ResumableSampler(len(ds), a.batch, 0, step, a.steps), **kw)
    amp_dtype = {"bf16": torch.bfloat16, "fp16": torch.float16, "fp32": None}[a.dtype]
    print(f"[{a.run}] {'resumed at' if a.resume else 'starting at'} step {step}/{a.steps} | workers={a.workers} "
          f"dtype={a.dtype} device={dev}")

    wait = comp = 0.0; n = 0
    t_prev = time.perf_counter(); t_begin = t_prev
    for xb, yb in dl:
        t0 = time.perf_counter()
        xb = xb.to(dev, non_blocking=True); yb = yb.to(dev, non_blocking=True)
        with torch.autocast(device_type=dev.type, dtype=amp_dtype, enabled=amp_dtype is not None):
            loss = nn.functional.cross_entropy(model(xb).float(), yb)   # loss computed in FP32
        opt.zero_grad(set_to_none=True)
        if scaler:
            scaler.scale(loss).backward(); scaler.step(opt); scaler.update()
        else:
            loss.backward(); opt.step()
        t1 = time.perf_counter()
        if n == 0:
            startup = t0 - t_prev; t_begin = t0                # worker start-up + first batch: reported separately
        else:
            wait += t0 - t_prev
        comp += t1 - t0; n += 1; step += 1
        if step % 50 == 0:
            print(f"  step {step:4d}  loss {loss.item():.3f}")
        if a.ckpt_every and step % a.ckpt_every == 0:
            save(ckpt, step, model, opt, scaler)
        if a.preempt_at and step == a.preempt_at:
            STOP["flag"] = "simulated SIGTERM"
        if STOP["flag"]:
            save(ckpt, step, model, opt, scaler)
            print(f"  received {STOP['flag']}: checkpoint saved at step {step}; exiting cleanly")
            break
        t_prev = time.perf_counter()
    total = time.perf_counter() - t_begin
    if n:
        print(f"  {n} steps in {total:.2f} s = {n/total:.1f} steps/s | data-wait {wait/total:.0%} | "
              f"compute {comp/n*1e3:.2f} ms/step | first batch (incl. worker start-up) {startup:.2f} s")
    if step >= a.steps:
        print(f"  final weights fingerprint {fingerprint(model)}")


if __name__ == "__main__":
    main()
