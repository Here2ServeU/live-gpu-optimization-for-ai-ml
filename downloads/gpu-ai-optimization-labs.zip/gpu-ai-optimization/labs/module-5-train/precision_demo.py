#!/usr/bin/env python3
"""
Module 5 · Stage 2 — Why mixed precision works the way it does.

Four small experiments, all in numpy, all deterministic:

  1. The formats: range (how big / how small) vs. precision (how fine).
     FP16 has fine steps but a narrow range. BF16 keeps FP32's range with
     coarse steps. numpy has no bfloat16, so we emulate it exactly: take a
     float32 and round away its low 16 bits (round-to-nearest-even).
  2. Underflow: realistic tiny gradients cast to FP16 become exactly zero.
     Multiplying the loss (so every gradient) by a scale factor first moves
     them back into range. Too big a scale overflows to inf instead, which is
     why real loss scalers are dynamic (back off on inf, grow when safe).
     BF16 does not underflow here: same exponent range as FP32.
  3. Master weights: a weight of 1.0 receiving updates of 1e-4. In FP16 or
     BF16 the update is smaller than half the gap to the next number, so it
     rounds away and the weight never moves. An FP32 master copy keeps it.
  4. Accumulation: adding 0.01 ten thousand times. A 16-bit running sum
     stalls; an FP32 sum does not. That is why tensor cores multiply in
     16-bit (or 8-bit) but accumulate in FP32.

Usage:
  python3 precision_demo.py
  python3 precision_demo.py --out reports/precision.md
"""
import argparse, os
import numpy as np


def bf16(x):
    """round float32 -> bfloat16 (kept in a float32 container). Exact for finite values."""
    x = np.asarray(x, dtype=np.float32)
    u = x.view(np.uint32).astype(np.uint64)
    u = (u + 0x7FFF + ((u >> 16) & 1)) & 0xFFFF0000
    out = u.astype(np.uint32).view(np.float32)
    return np.where(np.isfinite(x), out, x)


def f16(x):
    with np.errstate(over="ignore"):
        return np.asarray(x, dtype=np.float32).astype(np.float16).astype(np.float32)


CAST = {"fp32": lambda v: np.asarray(v, np.float32), "bf16": bf16, "fp16": f16}


def formats(md):
    print("\n1) THE FORMATS: range vs. precision")
    print(f"  {'format':6s} {'bits (exp/mantissa)':>20s} {'largest':>10s} {'smallest normal':>16s} {'step at 1.0':>12s}")
    md += ["## 1. Range vs. precision", "", "| Format | Exponent / mantissa bits | Largest | Smallest normal | Step at 1.0 |", "|---|---|---:|---:|---:|"]
    rows = [("fp32", "8 / 23", float(np.finfo(np.float32).max), float(np.finfo(np.float32).tiny), float(np.finfo(np.float32).eps)),
            ("bf16", "8 / 7", float(np.array([0x7F7F0000], np.uint32).view(np.float32)[0]), float(np.finfo(np.float32).tiny),
             float(bf16(np.float32(1) + np.float32(2 ** -7)) - 1)),
            ("fp16", "5 / 10", float(np.finfo(np.float16).max), float(np.finfo(np.float16).tiny), float(np.finfo(np.float16).eps))]
    for n, bits, mx, mn, eps in rows:
        print(f"  {n:6s} {bits:>20s} {mx:10.3g} {mn:16.3g} {eps:12.3g}")
        md.append(f"| {n} | {bits} | {mx:.3g} | {mn:.3g} | {eps:.3g} |")
    print("  (fp8 for reference: E4M3 max 448, E5M2 max 57344; training uses per-tensor scaling to fit.)")
    print("  BF16 = FP32's range with coarse steps. FP16 = finer steps, but below 6e-5 it loses bits and below ~3e-8 it is 0.")
    md += ["", "FP8 for reference: E4M3 max 448, E5M2 max 57,344. FP8 training relies on per-tensor (or finer) scaling factors."]


def underflow(md, rng):
    print("\n2) UNDERFLOW: tiny gradients vanish in FP16")
    # gradient magnitudes spread over many orders of magnitude, as in real networks
    g = (10.0 ** rng.normal(-6.0, 1.5, 200_000)).astype(np.float32) * rng.choice([-1, 1], 200_000).astype(np.float32)
    mag = np.abs(g)
    print(f"  200,000 gradients, magnitudes {mag.min():.0e} to {mag.max():.0e}; median {np.median(mag):.0e}")
    print(f"  {'format':6s} {'loss scale':>10s} {'became 0':>9s} {'became inf':>11s} {'median rel. error':>18s}")
    md += ["", "## 2. Underflow and loss scaling", "",
           "| Format | Loss scale | Became 0 | Became inf (count) | Median relative error after unscale |", "|---|---:|---:|---:|---:|"]
    res = {}
    for name, scale in [("fp32", 1), ("bf16", 1), ("fp16", 1), ("fp16", 2 ** 10), ("fp16", 2 ** 16), ("fp16", 2 ** 24)]:
        q = CAST[name](g * np.float32(scale))
        zero = float(np.mean(q == 0)); n_inf = int(np.sum(~np.isfinite(q)))
        back = q.astype(np.float64) / scale
        rel = np.abs(back - g) / mag
        es = "step skipped" if n_inf else f"{np.median(rel):.3%}"
        res[(name, scale)] = (zero, n_inf, float(np.median(rel)))
        print(f"  {name:6s} {scale:10,d} {zero:9.1%} {n_inf:11,d} {es:>18s}")
        md.append(f"| {name} | {scale:,} | {zero:.1%} | {n_inf:,} | {es} |")
    z1, _, e1 = res[("fp16", 1)]; z2, _, e2 = res[("fp16", 1024)]
    print(f"  -> FP16 unscaled: {z1:.1%} of gradients become exactly 0, and the median one is off by {e1:.0%} (subnormal: few bits left).")
    print(f"     Scale x1,024: {z2:.1%} zero, median error {e2:.3%}. BF16 unscaled: {res[('bf16', 1)][0]:.1%} zero.")
    print("     Too large a scale overflows (one inf poisons the step). Real scalers start high, skip the step and")
    print("     halve the scale on inf/NaN, and grow it again after a run of clean steps.")
    md += ["", "Dynamic loss scaling (e.g. PyTorch `GradScaler`): start high, skip the step and halve on inf/NaN, grow periodically."]


def master_weights(md):
    print("\n3) MASTER WEIGHTS: small updates round away in 16-bit")
    md += ["", "## 3. Master weights", "", "| Weights stored in | After 1,000 updates of +1e-4 (start 1.0) |", "|---|---:|"]
    for name in ("fp16", "bf16", "fp32"):
        w = CAST[name](np.float32(1.0))
        for _ in range(1000):
            w = CAST[name](w + np.float32(1e-4))
        print(f"  weights in {name}: 1.0 + 1,000 x 1e-4 = {float(w):.4f}   (should be 1.1000)")
        md.append(f"| {name} | {float(w):.4f} |")
    print("  -> keep an FP32 master copy for the optimizer step; cast to BF16/FP16 for the matmuls.")


def accumulation(md):
    print("\n4) ACCUMULATION: a 16-bit running sum stalls")
    md += ["", "## 4. Accumulation", "", "| Accumulator | Sum of 10,000 x 0.01 (should be 100) |", "|---|---:|"]
    for name in ("fp16", "bf16", "fp32"):
        s = CAST[name](np.float32(0)); step = CAST[name](np.float32(0.01))
        for _ in range(10_000):
            s = CAST[name](s + step)
        print(f"  {name} accumulator: {float(s):8.3f}")
        md.append(f"| {name} | {float(s):.3f} |")
    print("  -> tensor cores take 16-bit (or FP8) inputs but accumulate in FP32. Reductions (loss, norms) stay FP32 too.")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--seed", type=int, default=5)
    ap.add_argument("--out", default=None, help="write a markdown report here")
    a = ap.parse_args()
    rng = np.random.default_rng(a.seed)
    md = ["# Mixed precision, in four experiments", ""]
    formats(md); underflow(md, rng); master_weights(md); accumulation(md)
    print("\nRecipe: BF16 compute + FP32 master weights, usually no loss scaling. FP16 needs a dynamic loss scaler.")
    print("Always compare the loss curve to an FP32 (or BF16) baseline, and count NaN/inf steps.\n")
    if a.out:
        os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
        open(a.out, "w").write("\n".join(md) + "\n")
        print(f"wrote {a.out}")


if __name__ == "__main__":
    main()
