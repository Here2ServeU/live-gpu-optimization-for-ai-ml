#!/usr/bin/env python3
"""
Module 5 · Stage 3 — How much GPU memory does training need, per GPU?

Model STATE for mixed-precision training with Adam, per parameter:

  BF16/FP16 weights        2 bytes
  BF16/FP16 gradients      2 bytes
  FP32 master weights      4 bytes  \
  Adam first moment (m)    4 bytes   } 12 bytes of optimizer state
  Adam second moment (v)   4 bytes  /
                          --------
                          16 bytes per parameter, BEFORE activations

How each strategy divides it across d data-parallel GPUs (or t tensor-parallel):

  DDP                   every GPU holds all 16 bytes/param
  ZeRO-1                shard optimizer state:            2 + 2 + 12/d
  ZeRO-2                shard optimizer + gradients:      2 + (2 + 12)/d
  ZeRO-3 / FSDP full    shard everything:                 16/d
  Tensor parallel (t)   split each layer's matrices:      16/t  (inside one node; needs NVLink)
  Pipeline parallel (p) split the layers into stages:     16/p  (per stage, roughly)

ACTIVATIONS are separate and depend on sequence length and micro-batch, not
just parameters. A rough estimate per transformer layer (Korthikanti et al.,
2022, BF16): about 34 x seq x batch x hidden bytes when attention scores are
not stored (FlashAttention), or about 2 x seq x batch x hidden with full
activation recomputation (checkpointing). Treat these as order-of-magnitude.

Also not counted: CUDA context, communication buffers, fragmentation, and the
parameters FSDP temporarily gathers for the layer it is computing. Leave a few
GB of headroom.

Usage:
  python3 memory_calc.py --params 7e9 --gpus 8
  python3 memory_calc.py --params 70e9 --gpus 64 --tp 8
  python3 memory_calc.py --params 7e9 --gpus 8 --layers 32 --hidden 4096 --seq 4096 --micro-batch 1
"""
import argparse, os

GB = 1e9


def strategies(n, d, t):
    w, g, o = 2 * n, 2 * n, 12 * n
    rows = [("DDP (full copy per GPU)", w, g, o),
            (f"ZeRO-1 (optimizer sharded /{d})", w, g, o / d),
            (f"ZeRO-2 (+ gradients sharded /{d})", w, g / d, o / d),
            (f"ZeRO-3 / FSDP full shard /{d}", w / d, g / d, o / d)]
    if t > 1:
        rows.append((f"TP {t} (inside a node)", w / t, g / t, o / t))
        if d >= t and d % t == 0:
            dp = d // t
            rows.append((f"TP {t} x FSDP {dp} ({d} GPUs)", w / d, g / d, o / d))
    return rows


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--params", type=float, default=7e9)
    ap.add_argument("--gpus", type=int, default=8, help="data-parallel GPUs (for sharding)")
    ap.add_argument("--tp", type=int, default=1, help="tensor-parallel degree (also shown combined with FSDP)")
    ap.add_argument("--gpu-mem", type=float, default=80, help="GB per GPU")
    ap.add_argument("--layers", type=int, default=32)
    ap.add_argument("--hidden", type=int, default=4096)
    ap.add_argument("--seq", type=int, default=4096)
    ap.add_argument("--micro-batch", type=int, default=1)
    ap.add_argument("--out", help="write a markdown report here")
    a = ap.parse_args()

    n, d = a.params, a.gpus
    total = 16 * n
    sbh = a.seq * a.micro_batch * a.hidden
    act_flash = 34 * sbh * a.layers
    act_recomp = 2 * sbh * a.layers

    print(f"\n{n/1e9:g}B parameters, mixed precision + Adam = 16 bytes/param = {total/GB:,.0f} GB of model state")
    print(f"  weights {2*n/GB:,.0f} GB | gradients {2*n/GB:,.0f} GB | optimizer (FP32 master + m + v) {12*n/GB:,.0f} GB")
    print(f"  activations (rough, {a.layers} layers, seq {a.seq}, micro-batch {a.micro_batch}, hidden {a.hidden}): "
          f"~{act_flash/GB:.0f} GB stored, ~{act_recomp/GB:.1f} GB with full recomputation\n")
    hdr = f"  {'strategy':34s} {'weights':>8s} {'grads':>7s} {'optim':>7s} {'state/GPU':>10s} {'+ act (recomp)':>15s}  fits {a.gpu_mem:g} GB?"
    print(hdr)
    md = ["# Training memory per GPU", "",
          f"{n/1e9:g}B params, 16 bytes/param (BF16 weights 2 + BF16 grads 2 + FP32 master 4 + Adam m 4 + Adam v 4) = "
          f"**{total/GB:,.0f} GB** of model state. Activations estimated separately (rough).", "",
          f"| Strategy | Weights | Grads | Optimizer | State per GPU | + activations (recompute) | Fits {a.gpu_mem:g} GB? |",
          "|---|---:|---:|---:|---:|---:|---|"]
    for name, w, g, o in strategies(n, d, a.tp):
        st = w + g + o
        tp = a.tp if name.startswith("TP") else 1
        act = act_recomp / tp                      # TP + sequence parallelism also splits activations
        fits = "yes" if (st + act) / GB <= a.gpu_mem * 0.9 else "NO"
        print(f"  {name:34s} {w/GB:7.1f}G {g/GB:6.1f}G {o/GB:6.1f}G {st/GB:9.1f}G {(st+act)/GB:14.1f}G  {fits}")
        md.append(f"| {name} | {w/GB:.1f} GB | {g/GB:.1f} GB | {o/GB:.1f} GB | **{st/GB:.1f} GB** | {(st+act)/GB:.1f} GB | {fits} |")
    print(f"\n  'fits' leaves 10% headroom. Sharding trades memory for communication: FSDP all-gathers weights")
    print(f"  every layer, forward and backward. Measure the communication time, not just the memory.")
    print(f"  Rule of thumb: tensor parallel inside a node (NVLink); pipeline / data parallel across nodes.\n")
    md += ["", "Not counted: CUDA context, communication buffers, fragmentation, FSDP's temporarily gathered layer. "
               "Activation numbers are order-of-magnitude (Korthikanti et al., 2022)."]
    if a.out:
        os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
        open(a.out, "w").write("\n".join(md) + "\n")
        print(f"wrote {a.out}")


if __name__ == "__main__":
    main()
