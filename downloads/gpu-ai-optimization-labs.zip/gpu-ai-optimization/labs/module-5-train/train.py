#!/usr/bin/env python3
"""
Module 5 · Stages 2-4 — A training loop that survives.

A small numpy MLP learns the synthetic dataset in data/train.npz. Around it is
the plumbing every real training job needs, at laptop scale:

  * A data loader with N worker threads and a prefetch queue. Each batch pays
    a simulated "decode" cost (--decode-ms, a sleep standing in for JPEG
    decoding, tokenization or a slow network read). With --workers 0 the
    training loop waits for every batch itself: the GPU-starvation pattern.
  * Per-step timing: how long the step waited for data vs. how long it
    computed. Written to logs/<run>.csv, one row per step.
  * Atomic checkpoints every --ckpt-every steps: weights, Adam state, step
    and RNG state are written to a temp file, fsync'd, then renamed over the
    old one. A crash mid-write can never leave a half-written checkpoint.
  * A termination handler: SIGTERM (what Kubernetes and most clouds send
    before a spot/preemptible VM is taken away) or SIGINT (Ctrl+C) finishes
    the current step, saves a checkpoint and exits cleanly.
  * --resume continues from the last checkpoint and produces bit-for-bit the
    same weights as a run that was never interrupted (check the fingerprint).

Honest simplifications: it is a CPU numpy model, so "compute" is a few
milliseconds per step, not a GPU kernel. Worker threads work here because the
simulated decode is a sleep, which releases Python's GIL. Real CPU-heavy
decoding needs processes; that is why PyTorch's DataLoader uses processes.

Windows note: Ctrl+C (SIGINT) works everywhere. `kill -TERM <pid>` is macOS /
Linux; on Windows there is no catchable SIGTERM from outside the process
(taskkill /F terminates instantly, like a hard crash), so use Ctrl+C or the
--preempt-at flag to rehearse a termination notice.

Usage:
  python3 train.py --run w0 --workers 0                      # starved baseline
  python3 train.py --run w4 --workers 4                      # same job, fed
  python3 train.py --run drill --ckpt-every 100 --crash-at 750   # hard failure
  python3 train.py --run drill --resume --preempt-at 1000         # spot notice
  python3 train.py --run drill --resume                           # finish
"""
import argparse, csv, hashlib, json, os, queue, signal, sys, threading, time
# One BLAS thread: steadier timings, the same on every laptop, and the
# "compute" stays on one core while loader threads wait on their decode.
for _v in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
    os.environ.setdefault(_v, "1")
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
FIELDS = ["session", "event", "step", "loss", "data_wait_ms", "compute_ms", "ckpt_ms", "t_wall"]


# ---------------------------------------------------------------- data loader
class Loader:
    """Delivers batches in a fixed order. Batch b is always the same rows, no
    matter how many workers fetch it, so the training result never depends on
    --workers; only the waiting does."""

    def __init__(self, x, y, batch, seed, decode_ms, workers, prefetch, start_batch):
        self.x, self.y, self.batch, self.seed = x, y, batch, seed
        self.decode_s = decode_ms / 1000.0
        self.per_epoch = len(x) // batch
        self.workers, self.next_b, self.start = workers, start_batch, start_batch
        self._perm_cache = {}
        self._lock = threading.Lock()
        self.stop = threading.Event()
        if workers > 0:
            # one bounded queue per worker, read round-robin (like PyTorch's DataLoader)
            self.qs = [queue.Queue(maxsize=prefetch) for _ in range(workers)]
            for k in range(workers):
                threading.Thread(target=self._work, args=(k, start_batch + k), daemon=True).start()

    def _perm(self, epoch):
        with self._lock:
            if epoch not in self._perm_cache:
                self._perm_cache[epoch] = np.random.default_rng(self.seed + 1000 + epoch).permutation(len(self.x))
                self._perm_cache.pop(epoch - 2, None)
            return self._perm_cache[epoch]

    def _make(self, b):
        epoch, pos = divmod(b, self.per_epoch)
        idx = self._perm(epoch)[pos * self.batch:(pos + 1) * self.batch]
        time.sleep(self.decode_s)                      # the "decode / tokenize / network read" cost
        return self.x[idx], self.y[idx]

    def _work(self, k, b):
        while not self.stop.is_set():
            item = self._make(b)
            while not self.stop.is_set():
                try:
                    self.qs[k].put(item, timeout=0.1); break
                except queue.Full:
                    continue
            b += self.workers

    def next(self):
        b = self.next_b; self.next_b += 1
        if self.workers == 0:
            return self._make(b)                      # the training loop does the decoding itself
        return self.qs[(b - self.start) % self.workers].get()   # worker k owns batches start+k, start+k+N, ...


# ---------------------------------------------------------------- model
def init_params(rng, sizes):
    p = {}
    for i, (a, b) in enumerate(zip(sizes[:-1], sizes[1:])):
        p[f"W{i}"] = (rng.standard_normal((a, b)) * np.sqrt(2.0 / a)).astype(np.float32)
        p[f"b{i}"] = np.zeros(b, np.float32)
    return p


def step_fn(p, x, y, rng, dropout):
    """forward + backward for an MLP with ReLU + dropout; returns loss, grads"""
    n_layers = len(p) // 2
    acts, masks = [x], []
    h = x
    for i in range(n_layers):
        z = h @ p[f"W{i}"] + p[f"b{i}"]
        if i < n_layers - 1:
            h = np.maximum(z, 0)
            m = (rng.random(h.shape, dtype=np.float32) >= dropout).astype(np.float32) / (1 - dropout)
            h = h * m
            masks.append(m); acts.append(h)
        else:
            h = z
    z = h - h.max(1, keepdims=True)
    e = np.exp(z); prob = e / e.sum(1, keepdims=True)
    n = len(y)
    loss = float(-np.log(prob[np.arange(n), y] + 1e-12).mean())
    g = prob; g[np.arange(n), y] -= 1; g /= n
    grads = {}
    for i in reversed(range(n_layers)):
        grads[f"W{i}"] = acts[i].T @ g
        grads[f"b{i}"] = g.sum(0)
        if i > 0:
            g = (g @ p[f"W{i}"].T) * (acts[i] > 0) * masks[i - 1]
    return loss, grads


def adam(p, g, st, lr, b1=0.9, b2=0.999, eps=1e-8):
    st["t"] += 1
    t = st["t"]
    for k in p:
        st["m"][k] = b1 * st["m"][k] + (1 - b1) * g[k]
        st["v"][k] = b2 * st["v"][k] + (1 - b2) * g[k] * g[k]
        mh = st["m"][k] / (1 - b1 ** t); vh = st["v"][k] / (1 - b2 ** t)
        p[k] -= (lr * mh / (np.sqrt(vh) + eps)).astype(np.float32)


def fingerprint(p):
    h = hashlib.sha256()
    for k in sorted(p):
        h.update(np.ascontiguousarray(p[k]).tobytes())
    return h.hexdigest()[:12]


# ---------------------------------------------------------------- checkpoints
def save_ckpt(path, step, p, st, rng, cfg, ema=None):
    """write tmp -> flush -> fsync -> atomic rename. The old checkpoint stays valid until the new one is complete."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    arrays = {f"p_{k}": v for k, v in p.items()}
    arrays.update({f"m_{k}": v for k, v in st["m"].items()})
    arrays.update({f"v_{k}": v for k, v in st["v"].items()})
    meta = {"step": step, "adam_t": st["t"], "rng": rng.bit_generator.state, "cfg": cfg, "loss_ema": ema}
    with open(tmp, "wb") as f:
        np.savez(f, meta=np.array(json.dumps(meta)), **arrays)
        f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)                              # atomic on POSIX and Windows


def load_ckpt(path):
    z = np.load(path, allow_pickle=False)
    meta = json.loads(str(z["meta"]))
    p = {k[2:]: z[k] for k in z.files if k.startswith("p_")}
    st = {"t": meta["adam_t"], "m": {k[2:]: z[k] for k in z.files if k.startswith("m_")},
          "v": {k[2:]: z[k] for k in z.files if k.startswith("v_")}}
    rng = np.random.default_rng()
    rng.bit_generator.state = meta["rng"]
    return meta, p, st, rng


# ---------------------------------------------------------------- main
STOP = {"flag": None}


def on_signal(signum, frame):
    # Do as little as possible inside a handler: set a flag, let the loop save at a step boundary.
    STOP["flag"] = signal.Signals(signum).name


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--run", default="run", help="run name: logs/<run>.csv, ckpt/<run>/latest.npz")
    ap.add_argument("--steps", type=int, default=2000, help="total steps for the whole run")
    ap.add_argument("--batch", type=int, default=256)
    ap.add_argument("--hidden", type=int, default=256)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--dropout", type=float, default=0.1)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--workers", type=int, default=0, help="data loader worker threads (0 = load in the training loop)")
    ap.add_argument("--prefetch", type=int, default=2, help="batches each worker may queue ahead")
    ap.add_argument("--decode-ms", type=float, default=4.0, help="simulated decode cost per batch")
    ap.add_argument("--ckpt-every", type=int, default=0, help="checkpoint every N steps (0 = never)")
    ap.add_argument("--resume", action="store_true", help="continue from ckpt/<run>/latest.npz")
    ap.add_argument("--crash-at", type=int, help="simulate a hard failure (no checkpoint) right after this step")
    ap.add_argument("--preempt-at", type=int, help="simulate a termination notice right after this step")
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args()

    signal.signal(signal.SIGINT, on_signal)
    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, on_signal)

    d = np.load(os.path.join(HERE, "data", "train.npz"))
    x, y = d["x"], d["y"]
    cfg = {"batch": a.batch, "hidden": a.hidden, "lr": a.lr, "dropout": a.dropout, "seed": a.seed}
    ckpt = os.path.join(HERE, "ckpt", a.run, "latest.npz")
    log_path = os.path.join(HERE, "logs", f"{a.run}.csv")
    os.makedirs(os.path.dirname(log_path), exist_ok=True)

    t_start = time.time()
    session = 1
    if a.resume:
        if not os.path.exists(ckpt):
            sys.exit(f"no checkpoint at {os.path.relpath(ckpt)}; run without --resume first")
        meta, p, st, rng = load_ckpt(ckpt)
        if meta["cfg"] != cfg:
            sys.exit(f"checkpoint config {meta['cfg']} differs from this run {cfg}; refusing to mix them")
        step = meta["step"]
        if os.path.exists(log_path):
            with open(log_path) as f:
                session = max(int(r["session"]) for r in csv.DictReader(f)) + 1
        mode = "a"
    else:
        rng = np.random.default_rng(a.seed)
        p = init_params(rng, [x.shape[1], a.hidden, a.hidden, int(y.max()) + 1])
        st = {"t": 0, "m": {k: np.zeros_like(v) for k, v in p.items()}, "v": {k: np.zeros_like(v) for k, v in p.items()}}
        step = 0
        mode = "w"
        if os.path.isdir(os.path.dirname(ckpt)) and os.path.exists(ckpt):
            os.remove(ckpt)                          # a fresh run must not resume someone else's state later

    logf = open(log_path, mode, newline="")
    log = csv.DictWriter(logf, fieldnames=FIELDS)
    if mode == "w":
        log.writeheader()
    log.writerow({"session": session, "event": "start", "step": step, "t_wall": f"{t_start:.4f}"}); logf.flush()

    ld = Loader(x, y, a.batch, a.seed, a.decode_ms, a.workers, a.prefetch, step)
    say = (lambda *s: None) if a.quiet else print
    say(f"[{a.run}] pid {os.getpid()} session {session}: {'resumed at' if a.resume else 'starting at'} step {step}/{a.steps} | "
        f"workers={a.workers} decode={a.decode_ms:g} ms/batch ckpt-every={a.ckpt_every or 'never'}")

    waits, comps = [], []
    ema = meta.get("loss_ema") if a.resume else None
    t_loop = time.perf_counter()
    exit_reason = "finished"
    while step < a.steps:
        t0 = time.perf_counter()
        xb, yb = ld.next()
        t1 = time.perf_counter()
        loss, g = step_fn(p, xb, yb, rng, a.dropout)
        adam(p, g, st, a.lr)
        t2 = time.perf_counter()
        step += 1
        ema = loss if ema is None else 0.98 * ema + 0.02 * loss
        waits.append(t1 - t0); comps.append(t2 - t1)
        log.writerow({"session": session, "event": "step", "step": step, "loss": f"{loss:.5f}",
                      "data_wait_ms": f"{(t1-t0)*1e3:.3f}", "compute_ms": f"{(t2-t1)*1e3:.3f}", "t_wall": f"{time.time():.4f}"})
        logf.flush()
        if step % 200 == 0:
            say(f"  step {step:5d}  loss {ema:.3f}")
        if a.ckpt_every and step % a.ckpt_every == 0:
            c0 = time.perf_counter(); save_ckpt(ckpt, step, p, st, rng, cfg, ema); c1 = time.perf_counter()
            log.writerow({"session": session, "event": "ckpt", "step": step, "ckpt_ms": f"{(c1-c0)*1e3:.3f}",
                          "t_wall": f"{time.time():.4f}"}); logf.flush()
        if a.crash_at and step == a.crash_at:
            say(f"  !! simulated hardware failure after step {step}. No checkpoint, no goodbye.")
            logf.flush(); os._exit(1)
        if a.preempt_at and step == a.preempt_at:
            STOP["flag"] = "simulated SIGTERM"
        if STOP["flag"]:
            c0 = time.perf_counter(); save_ckpt(ckpt, step, p, st, rng, cfg, ema); c1 = time.perf_counter()
            log.writerow({"session": session, "event": "preempt", "step": step, "ckpt_ms": f"{(c1-c0)*1e3:.3f}",
                          "t_wall": f"{time.time():.4f}"}); logf.flush()
            say(f"  received {STOP['flag']}: saved checkpoint at step {step} in {(c1-c0)*1e3:.1f} ms; exiting cleanly")
            exit_reason = "preempted"
            break
    t_end = time.perf_counter()
    ld.stop.set()
    log.writerow({"session": session, "event": "end", "step": step, "t_wall": f"{time.time():.4f}"}); logf.close()

    n = len(waits)
    if n:
        loop_s = t_end - t_loop
        wait_share = sum(waits) / loop_s
        say(f"  {exit_reason} at step {step}: {n} steps in {loop_s:.2f} s = {n/loop_s:.1f} steps/s | "
            f"data-wait {wait_share:.0%} of step time | compute {np.mean(comps)*1e3:.2f} ms/step")
    if step >= a.steps:
        logits = x
        for i in range(len(p) // 2):
            logits = logits @ p[f"W{i}"] + p[f"b{i}"]
            if i < len(p) // 2 - 1:
                logits = np.maximum(logits, 0)
        acc = float((logits.argmax(1) == y).mean())
        say(f"  train accuracy {acc:.1%} | final weights fingerprint {fingerprint(p)}")
        os.makedirs(os.path.join(HERE, "reports"), exist_ok=True)
        rep = os.path.join(HERE, "reports", f"train_{a.run}.md")
        with open(rep, "w") as f:
            f.write(f"# Training run `{a.run}`\n\n"
                    f"- Config: {json.dumps(cfg)}, workers={a.workers}, prefetch={a.prefetch}, decode={a.decode_ms:g} ms/batch, "
                    f"ckpt-every={a.ckpt_every or 'never'}\n"
                    f"- Sessions: {session} (log: `logs/{a.run}.csv`)\n"
                    f"- Final session: {n} steps, {n/loop_s:.1f} steps/s, data-wait {wait_share:.1%} of step time\n"
                    f"- Train accuracy {acc:.1%}, final weights fingerprint `{fingerprint(p)}`\n\n"
                    f"Run `python3 goodput.py logs/{a.run}.csv` for the full goodput breakdown across sessions.\n")
        say(f"  wrote {os.path.relpath(rep)}")


if __name__ == "__main__":
    main()
