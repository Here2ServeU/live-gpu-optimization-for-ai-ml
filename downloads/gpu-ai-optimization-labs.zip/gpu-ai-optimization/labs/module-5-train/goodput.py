#!/usr/bin/env python3
"""
Module 5 · Stages 4-5 — Goodput, checkpoint interval, and the real cost of spot.

GOODPUT is the share of the time you paid for that became training progress
you kept. Uptime counts every second the job was "running". Goodput does not
count:
  * steps that were redone because they ran after the last checkpoint (lost work)
  * time spent waiting for data
  * time spent writing checkpoints
  * startup and restore time after every restart

Three modes:

1) Read training logs written by train.py (one or more):
     python3 goodput.py logs/drill.csv
     python3 goodput.py logs/w0.csv logs/w4.csv --out reports/goodput_workers.md

   A step counts as kept only in the LAST session that ran it. Earlier runs
   of the same step number are lost work. Gaps between sessions (you typing
   the resume command) are not counted; use --downtime-s to charge an
   assumed reschedule time per restart, as a real cluster would.

2) Young's approximation for the checkpoint interval:
     python3 goodput.py --young --ckpt-cost-s 60 --mtbf-h 4
   tau ~= sqrt(2 x checkpoint_cost x MTBF). First-order: it assumes the
   checkpoint cost is much smaller than the MTBF.

3) Simulate a long job on on-demand vs spot capacity, across checkpoint intervals:
     python3 goodput.py --simulate
   Failures arrive at random (exponential, seeded). Each failure loses the
   work since the last finished checkpoint, plus a restart cost. Every
   price and failure rate is an EXAMPLE for the lab: change the flags to
   your own numbers. Real spot discounts and interruption rates vary by
   cloud, region and GPU type, and change over time.
"""
import argparse, csv, math, os, random
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))


# ---------------------------------------------------------------- 1) logs
def analyse(path, downtime_s=0.0):
    rows = list(csv.DictReader(open(path, newline="")))
    sessions = defaultdict(list)
    for r in rows:
        sessions[int(r["session"])].append(r)
    wall = 0.0
    last_run = {}                       # step -> session that ran it last
    step_rows = []
    ckpt_s = 0.0
    for sid in sorted(sessions):
        rs = sessions[sid]
        t = [float(r["t_wall"]) for r in rs]
        wall += max(t) - min(t)
        for r in rs:
            if r["event"] == "step":
                k = int(r["step"]); last_run[k] = sid
                step_rows.append((sid, k, float(r["data_wait_ms"]) / 1e3, float(r["compute_ms"]) / 1e3))
            elif r["event"] in ("ckpt", "preempt"):
                ckpt_s += float(r["ckpt_ms"]) / 1e3
    restarts = len(sessions) - 1
    wall += restarts * downtime_s
    kept_compute = kept_wait = lost = 0.0
    lost_steps = 0
    for sid, k, w, c in step_rows:
        if last_run[k] == sid:
            kept_compute += c; kept_wait += w
        else:
            lost += w + c; lost_steps += 1
    other = max(0.0, wall - kept_compute - kept_wait - lost - ckpt_s)
    kept_steps = len(last_run)
    return {"file": os.path.relpath(path), "sessions": len(sessions), "restarts": restarts,
            "wall": wall, "compute": kept_compute, "wait": kept_wait, "lost": lost, "ckpt": ckpt_s, "other": other,
            "kept_steps": kept_steps, "lost_steps": lost_steps,
            "goodput": kept_compute / wall if wall else 0.0,
            "steps_per_s": kept_steps / wall if wall else 0.0,
            "wait_share": kept_wait / (kept_wait + kept_compute) if kept_compute else 0.0}


def log_mode(a):
    res = [analyse(p, a.downtime_s) for p in a.logs]
    md = ["# Goodput report", ""]
    for r in res:
        print(f"\n{r['file']}: {r['sessions']} session(s), {r['restarts']} restart(s), "
              f"{r['kept_steps']} steps kept, {r['lost_steps']} steps redone")
        print(f"  {'paid wall time':24s} {r['wall']:8.2f} s  100.0%")
        for lab, k in [("useful compute (kept)", "compute"), ("waiting for data", "wait"),
                       ("lost work (redone)", "lost"), ("writing checkpoints", "ckpt"),
                       ("startup / restore / other", "other")]:
            print(f"  {lab:24s} {r[k]:8.2f} s  {r[k]/r['wall']:6.1%}")
        print(f"  GOODPUT {r['goodput']:.1%}   ({r['steps_per_s']:.1f} kept steps per second of paid time)")
    if len(res) > 1:
        b, n = res[0], res[-1]
        print(f"\nCHANGE ONE THING  {b['file']} -> {n['file']}")
        print(f"  data-wait share   {b['wait_share']:.1%} -> {n['wait_share']:.1%}  "
              f"({(n['wait_share']-b['wait_share'])*100:+.1f} pts)")
        print(f"  steps per second  {b['steps_per_s']:.1f} -> {n['steps_per_s']:.1f}  "
              f"({(n['steps_per_s']/b['steps_per_s']-1)*100:+.0f}%)")
        print(f"  lost work         {b['lost']:.2f} s -> {n['lost']:.2f} s ({b['lost_steps']} -> {n['lost_steps']} steps redone)")
        print(f"  goodput           {b['goodput']:.1%} -> {n['goodput']:.1%}  ({(n['goodput']-b['goodput'])*100:+.1f} pts)")
    md += ["| Log | Sessions | Paid s | Useful compute | Data wait | Lost work | Checkpoints | Other | Goodput | Kept steps/s |",
           "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for r in res:
        md.append(f"| `{r['file']}` | {r['sessions']} | {r['wall']:.2f} | {r['compute']/r['wall']:.1%} | {r['wait']/r['wall']:.1%} | "
                  f"{r['lost']/r['wall']:.1%} | {r['ckpt']/r['wall']:.1%} | {r['other']/r['wall']:.1%} | **{r['goodput']:.1%}** | {r['steps_per_s']:.1f} |")
    if len(res) > 1:
        b, n = res[0], res[-1]
        md += ["", f"**Change one thing** (`{b['file']}` -> `{n['file']}`): data-wait share {b['wait_share']:.1%} -> {n['wait_share']:.1%}, "
                   f"steps/s {(n['steps_per_s']/b['steps_per_s']-1)*100:+.0f}%, goodput {b['goodput']:.1%} -> {n['goodput']:.1%}."]
    md += ["", "Goodput = compute time of the steps that survived into the final model / total paid wall time. "
               "Gaps between sessions are excluded unless `--downtime-s` is set."]
    return md


# ---------------------------------------------------------------- 2) Young
def young(c_s, mtbf_s):
    return math.sqrt(2 * c_s * mtbf_s)


def young_mode(a):
    c, m = a.ckpt_cost_s, a.mtbf_h * 3600
    tau = young(c, m)
    waste = c / tau + tau / (2 * m)
    print(f"\nYoung's approximation: tau = sqrt(2 x {c:g} s x {a.mtbf_h:g} h) = {tau/60:.1f} min between checkpoints")
    print(f"  expected waste at tau ~ C/tau + tau/(2 x MTBF) = {waste:.1%} of time (plus restart cost per failure)")
    for f in (0.25, 0.5, 2, 4):
        t = tau * f
        print(f"  checkpoint every {t/60:6.1f} min -> waste ~{c/t + t/(2*m):5.1%}")
    return [f"# Checkpoint interval (Young)", "", f"- checkpoint cost {c:g} s, MTBF {a.mtbf_h:g} h -> **tau = {tau/60:.1f} min**, "
            f"first-order waste {waste:.1%}"]


# ---------------------------------------------------------------- 3) simulate
def simulate(work_s, tau_s, c_s, r_s, mtbf_s, trials, seed):
    """mean wall seconds to finish work_s of compute, checkpointing every tau_s"""
    rng = random.Random(seed)
    total = 0.0
    for _ in range(trials):
        done, t = 0.0, 0.0
        nxt = rng.expovariate(1 / mtbf_s)          # time until the next failure
        while done < work_s:
            seg = min(tau_s, work_s - done)
            need = seg + (c_s if done + seg < work_s else 0.0)   # no checkpoint needed after the last segment
            if nxt >= need:
                t += need; nxt -= need; done += seg
            else:
                t += nxt + r_s                          # lose the segment in flight, pay the restart
                nxt = rng.expovariate(1 / mtbf_s)
        total += t
    return total / trials


def sim_mode(a):
    work_s = a.work_h * 3600
    c, r = a.ckpt_cost_s, a.restart_s
    pools = [("on-demand", a.ondemand_price, a.ondemand_mtbf_h), ("spot", a.spot_price, a.spot_mtbf_h)]
    print(f"\nJob: {a.work_h:g} h of useful compute on {a.gpus} GPUs | checkpoint {c:g} s | restart {r:g} s")
    for name, price, mtbf in pools:
        print(f"  {name:9s} ${price:.2f}/GPU-h (example), job-level MTBF {mtbf:g} h, Young tau {young(c, mtbf*3600)/60:.0f} min")
    md = ["# Spot vs on-demand: effective cost per training run", "",
          f"Job: {a.work_h:g} h useful compute on {a.gpus} GPUs; checkpoint cost {c:g} s; restart {r:g} s. "
          f"**Example prices**: on-demand ${a.ondemand_price:.2f}, spot ${a.spot_price:.2f} per GPU-hour. "
          f"Job-level MTBF: on-demand {a.ondemand_mtbf_h:g} h, spot {a.spot_mtbf_h:g} h. Seed {a.seed}, {a.trials} trials.", "",
          "| Checkpoint every | On-demand goodput | On-demand $/run | Spot goodput | Spot $/run |", "|---:|---:|---:|---:|---:|"]
    intervals = sorted(set(a.intervals_min + [round(young(c, m * 3600) / 60) for _, _, m in pools]))
    print(f"\n  {'ckpt every':>10s} | {'on-demand goodput':>17s} {'$ per run':>10s} | {'spot goodput':>12s} {'$ per run':>10s}")
    best = {}
    for iv in intervals:
        cells = []
        for name, price, mtbf in pools:
            wall = simulate(work_s, iv * 60, c, r, mtbf * 3600, a.trials, a.seed)
            cost = wall / 3600 * a.gpus * price
            cells.append((work_s / wall, cost))
            if name not in best or cost < best[name][1]:
                best[name] = (iv, cost, work_s / wall)
        (g1, c1), (g2, c2) = cells
        print(f"  {iv:6.0f} min | {g1:17.1%} {c1:10,.0f} | {g2:12.1%} {c2:10,.0f}")
        md.append(f"| {iv:.0f} min | {g1:.1%} | ${c1:,.0f} | {g2:.1%} | ${c2:,.0f} |")
    ideal = {name: a.work_h * a.gpus * price for name, price, _ in pools}
    print(f"\n  no-failure floor: on-demand ${ideal['on-demand']:,.0f}, spot ${ideal['spot']:,.0f}")
    bo, bs = best["on-demand"], best["spot"]
    worst_spot = max(intervals)
    ws = simulate(work_s, worst_spot * 60, c, r, a.spot_mtbf_h * 3600, a.trials, a.seed) / 3600 * a.gpus * a.spot_price
    print(f"  best on-demand: every {bo[0]:.0f} min -> ${bo[1]:,.0f} (goodput {bo[2]:.1%})")
    print(f"  best spot:      every {bs[0]:.0f} min -> ${bs[1]:,.0f} (goodput {bs[2]:.1%}), "
          f"{(1 - bs[1]/bo[1]):.0%} cheaper than the best on-demand run")
    verdict = (f"{ws/bo[1]-1:.0%} MORE than the best on-demand run" if ws > bo[1]
               else f"still {1-ws/bo[1]:.0%} cheaper than on-demand, but {ws/bs[1]-1:.0%} more than spot done right")
    print(f"  spot, checkpoint every {worst_spot:.0f} min -> ${ws:,.0f}: {verdict}.")
    print("  Cheap capacity is only cheap if your system expects failure.")
    md += ["", f"- Best on-demand: every {bo[0]:.0f} min, ${bo[1]:,.0f}. Best spot: every {bs[0]:.0f} min, ${bs[1]:,.0f} "
               f"(**{(1 - bs[1]/bo[1]):.0%} cheaper**).",
           f"- Spot checkpointing every {worst_spot:.0f} min: ${ws:,.0f} ({verdict}).",
           "", "> All prices and failure rates are examples. Replace them with your own before deciding anything."]
    return md


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("logs", nargs="*", help="training logs from train.py")
    ap.add_argument("--downtime-s", type=float, default=0.0, help="assumed reschedule time charged per restart")
    ap.add_argument("--young", action="store_true")
    ap.add_argument("--simulate", action="store_true")
    ap.add_argument("--ckpt-cost-s", type=float, default=60.0, help="seconds the job is paused to write a checkpoint")
    ap.add_argument("--mtbf-h", type=float, default=4.0, help="mean time between failures/interruptions of the JOB, hours")
    ap.add_argument("--restart-s", type=float, default=600.0, help="seconds to get going again after a failure")
    ap.add_argument("--work-h", type=float, default=48.0, help="hours of useful compute the job needs")
    ap.add_argument("--gpus", type=int, default=64)
    ap.add_argument("--ondemand-price", type=float, default=4.00, help="EXAMPLE $/GPU-hour")
    ap.add_argument("--spot-price", type=float, default=1.60, help="EXAMPLE $/GPU-hour")
    ap.add_argument("--ondemand-mtbf-h", type=float, default=100.0, help="EXAMPLE job-level MTBF (hardware failures)")
    ap.add_argument("--spot-mtbf-h", type=float, default=3.0, help="EXAMPLE job-level MTBF (preemptions + failures)")
    ap.add_argument("--intervals-min", type=float, nargs="+", default=[5, 15, 60, 360])
    ap.add_argument("--trials", type=int, default=400)
    ap.add_argument("--seed", type=int, default=5)
    ap.add_argument("--out", help="write a markdown report here")
    a = ap.parse_args()

    md = []
    if a.logs:
        md += log_mode(a)
    if a.young:
        md += ([""] if md else []) + young_mode(a)
    if a.simulate:
        md += ([""] if md else []) + sim_mode(a)
    if not md:
        ap.print_help(); return
    if a.out:
        os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
        with open(a.out, "w") as f:
            f.write("\n".join(md) + "\n")
        print(f"\nwrote {a.out}")


if __name__ == "__main__":
    main()
