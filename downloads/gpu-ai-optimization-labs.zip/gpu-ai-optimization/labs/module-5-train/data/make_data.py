#!/usr/bin/env python3
"""
Module 5 · sample data — a small, deterministic classification dataset.

A fixed random "teacher" network labels random inputs, so there is a real
pattern for the student MLP in train.py to learn. Same seed, same file, every
time, on every laptop.

  8,192 rows x 32 float32 features, 10 classes  ->  data/train.npz (~1 MB)

Usage:
  python3 data/make_data.py            # writes data/train.npz
  python3 data/make_data.py --rows 16384
"""
import argparse, os
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--rows", type=int, default=8192)
    ap.add_argument("--features", type=int, default=32)
    ap.add_argument("--classes", type=int, default=10)
    ap.add_argument("--seed", type=int, default=5)
    ap.add_argument("--out", default=os.path.join(HERE, "train.npz"))
    a = ap.parse_args()

    rng = np.random.default_rng(a.seed)
    x = rng.standard_normal((a.rows, a.features)).astype(np.float32)
    w1 = rng.standard_normal((a.features, 64)) / np.sqrt(a.features)
    w2 = rng.standard_normal((64, a.classes)) / np.sqrt(64)
    logits = np.tanh(x @ w1) @ w2 + 0.3 * rng.standard_normal((a.rows, a.classes))
    y = logits.argmax(1).astype(np.int64)
    np.savez_compressed(a.out, x=x, y=y)
    counts = np.bincount(y, minlength=a.classes)
    print(f"wrote {os.path.relpath(a.out)}: {a.rows} rows x {a.features} features, {a.classes} classes "
          f"(smallest class {counts.min()}, largest {counts.max()})")


if __name__ == "__main__":
    main()
