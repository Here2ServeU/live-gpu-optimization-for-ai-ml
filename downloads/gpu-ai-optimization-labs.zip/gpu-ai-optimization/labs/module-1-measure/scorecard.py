#!/usr/bin/env python3
"""
Module 1 · Stage 2 — The unit-cost scorecard.

Turns raw hourly usage (GPU hours, tokens, requests, errors) into the numbers
leadership and hiring managers care about:

  * cost per 1M tokens            (total and output-only)
  * cost per successful request   (errors cost money too)
  * idle spend                    (hours you paid for and served nothing)
  * p95 time to first token       (what users feel)

Usage:
  python3 scorecard.py data/usage_baseline.csv
  python3 scorecard.py data/usage_baseline.csv --compare data/usage_after.csv
  python3 scorecard.py data/usage_baseline.csv --out reports/baseline.md

Only the Python standard library is used.
"""
import argparse, csv, os, statistics
from collections import defaultdict


def load(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        for k in ("gpus", "requests", "errors", "input_tokens", "output_tokens", "p95_ttft_ms"):
            r[k] = int(r[k])
        r["price_per_gpu_hour"] = float(r["price_per_gpu_hour"])
    return rows


def score(rows):
    by = defaultdict(list)
    for r in rows:
        by[r["service"]].append(r)
    out = {}
    for svc, rs in by.items():
        cost = sum(r["gpus"] * r["price_per_gpu_hour"] for r in rs)          # every hour you pay for, busy or not
        idle_cost = sum(r["gpus"] * r["price_per_gpu_hour"] for r in rs if r["requests"] == 0)
        tin = sum(r["input_tokens"] for r in rs)
        tout = sum(r["output_tokens"] for r in rs)
        reqs = sum(r["requests"] for r in rs)
        errs = sum(r["errors"] for r in rs)
        ok = reqs - errs
        busy = [r["p95_ttft_ms"] for r in rs if r["requests"] > 0]
        out[svc] = {
            "gpu_type": rs[0]["gpu_type"],
            "gpu_hours": sum(r["gpus"] for r in rs),
            "cost": cost,
            "tokens": tin + tout,
            "cost_per_1m_tokens": cost / (tin + tout) * 1e6 if tin + tout else float("nan"),
            "cost_per_1m_output": cost / tout * 1e6 if tout else float("nan"),
            "cost_per_1k_success": cost / ok * 1000 if ok else float("nan"),
            "success_rate": ok / reqs if reqs else float("nan"),
            "idle_share": idle_cost / cost if cost else 0.0,
            "p95_ttft_ms_worst_hour": max(busy) if busy else 0,
            "p95_ttft_ms_median_hour": statistics.median(busy) if busy else 0,
        }
    return out


def fmt_table(sc, title):
    lines = [f"### {title}", "",
             "| Service | GPU | GPU-hrs | Cost/day | $ / 1M tokens | $ / 1M output | $ / 1k successful req | Success | Idle spend | p95 TTFT (worst hr) |",
             "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for svc, m in sc.items():
        lines.append(f"| {svc} | {m['gpu_type']} | {m['gpu_hours']} | ${m['cost']:,.2f} | ${m['cost_per_1m_tokens']:.3f} | "
                     f"${m['cost_per_1m_output']:.3f} | ${m['cost_per_1k_success']:.3f} | {m['success_rate']:.2%} | "
                     f"{m['idle_share']:.1%} | {m['p95_ttft_ms_worst_hour']} ms |")
    return "\n".join(lines)


def pct(a, b):
    return (b - a) / a * 100 if a else float("nan")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("baseline")
    ap.add_argument("--compare", help="a second CSV, after one change")
    ap.add_argument("--out", help="write a markdown report here")
    a = ap.parse_args()

    base = score(load(a.baseline))
    md = ["# GPU unit-cost scorecard", "", f"Source: `{a.baseline}`", "", fmt_table(base, "Baseline")]

    print("\nBASELINE")
    for svc, m in base.items():
        print(f"  {svc:16s} ${m['cost_per_1m_tokens']:.3f} per 1M tokens | ${m['cost_per_1k_success']:.3f} per 1k successful requests"
              f" | success {m['success_rate']:.2%} | idle spend {m['idle_share']:.1%} | worst-hour p95 TTFT {m['p95_ttft_ms_worst_hour']} ms")
        if m["idle_share"] > 0.05:
            print(f"    ! {m['idle_share']:.0%} of {svc} spend bought zero requests. That is the first thing to fix.")

    if a.compare:
        after = score(load(a.compare))
        md += ["", fmt_table(after, "After one change"), "", "### What changed", ""]
        print("\nAFTER  (one change)")
        for svc in base:
            b, n = base[svc], after.get(svc)
            if not n:
                continue
            d_cost = pct(b["cost_per_1m_tokens"], n["cost_per_1m_tokens"])
            d_ttft = pct(b["p95_ttft_ms_worst_hour"], n["p95_ttft_ms_worst_hour"])
            d_ok = (n["success_rate"] - b["success_rate"]) * 100
            line = (f"{svc}: cost per 1M tokens {d_cost:+.1f}% (${b['cost_per_1m_tokens']:.3f} -> ${n['cost_per_1m_tokens']:.3f}), "
                    f"worst-hour p95 TTFT {d_ttft:+.1f}%, success rate {d_ok:+.2f} pts")
            print("  " + line)
            md.append(f"- {line}")
        md += ["", "> Resume line template: _Cut cost per 1M tokens by X% and p95 TTFT by Y% on <service> by <one change>, "
                   "verified against a measured baseline._"]

    if a.out:
        os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
        with open(a.out, "w") as f:
            f.write("\n".join(md) + "\n")
        print(f"\nwrote {a.out}")


if __name__ == "__main__":
    main()
