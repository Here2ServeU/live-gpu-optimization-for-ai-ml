# Module 1 Lab · Your GPU Performance Scorecard

**Time:** ~45 minutes · **Runs on:** any laptop (Python 3.9+, no installs) · **Optional:** a machine with an NVIDIA GPU

You will build the three tools every ML infrastructure engineer reaches for before touching a model:

| Script | Question it answers |
|---|---|
| `scorecard.py` | What does it cost us to serve 1M tokens, and one successful request? Where are we paying for nothing? |
| `bottleneck.py` | Is this model + GPU limited by compute or by memory bandwidth? What is the speed ceiling? |
| `gpu_snapshot.py` | What is the GPU actually doing right now, and is "100% utilization" lying to us? |

---

## Stage 1 · Set up (5 min)

```bash
# macOS / Linux
cd labs/module-1-measure
python3 -m venv .venv && source .venv/bin/activate
python3 --version          # 3.9 or newer
```
```powershell
# Windows PowerShell
cd labs\module-1-measure
py -m venv .venv; .venv\Scripts\Activate.ps1
py --version
```
On Windows, use `py` wherever this guide says `python3`.

## Stage 2 · Baseline scorecard (10 min)

`data/usage_baseline.csv` is one day of hourly data for two services: GPU count, price, requests, errors, tokens, p95 time to first token.

```bash
python3 scorecard.py data/usage_baseline.csv --out reports/baseline.md
```

You should see `chat-assistant` at about **$0.95 per 1M tokens** and `doc-summarizer` flagged: **17% of its spend bought zero requests** (it ran at night with no traffic).

**Do:** open `reports/baseline.md`. Write one sentence for each service: _what is the unit cost and what is the first thing you would fix?_

## Stage 3 · Find the bottleneck (10 min)

```bash
python3 bottleneck.py --list
python3 bottleneck.py --params 8e9 --precision fp16 --gpu L4
python3 bottleneck.py --params 8e9 --precision int8 --gpu L4
python3 bottleneck.py --params 70e9 --precision fp16 --gpu A100-80GB --gpus 2
```

Read the table: at batch 1 an 8B FP16 model on an L4 tops out near **19 tokens/s per user**, because every token re-reads 16 GB of weights through a 300 GB/s pipe. Notice:

- Decode stays **memory-bound** until the batch is very large. Prefill is **compute-bound**.
- Halving bytes per parameter (INT8) doubles the memory-bound ceiling. That is why quantization (Module 2) works.
- A 70B FP16 model does **not fit** on one 80 GB GPU. That is why parallelism exists (Module 5).

**Do:** pick one model you care about. Record its weight size, ridge point, and batch-1 ceiling on two GPUs.

## Stage 4 · Read the GPU (10 min)

```bash
python3 gpu_snapshot.py            # live if you have nvidia-smi, else the recorded sample
python3 gpu_snapshot.py --sample   # force the sample
```

In the sample, GPU 0 shows **100% utilization at 142 W of 400 W**: busy, not productive. GPU 2 is idle and still billed. GPU 3 is power-capped and hot.

**Optional, with a GPU:** run NVIDIA's DCGM exporter and read the real production metrics:

```bash
docker run -d --gpus all --rm -p 9400:9400 nvcr.io/nvidia/k8s/dcgm-exporter:<tag-from-NGC>
curl -s localhost:9400/metrics | grep -E "DCGM_FI_DEV_GPU_UTIL|DCGM_FI_PROF_SM_ACTIVE|DCGM_FI_DEV_POWER_USAGE"
```

## Stage 5 · Change one thing, re-measure (10 min)

`data/usage_after.csv` is the same day after **one** change on `chat-assistant`: batching was tuned so the same traffic fits on 3 GPUs instead of 4.

```bash
python3 scorecard.py data/usage_baseline.csv --compare data/usage_after.csv --out reports/after.md
```

Expected: `chat-assistant` cost per 1M tokens **-25%**, worst-hour p95 TTFT **-20%**, success rate **+2.5 pts**. `doc-summarizer` is unchanged, because you changed one thing on one service. That is the loop.

---

## Deliverable (portfolio)

Commit `reports/baseline.md`, `reports/after.md` and a five-line `FINDINGS.md`:

1. Unit cost before and after (per 1M tokens and per 1k successful requests)
2. The bottleneck you found and how you know
3. The one change you made
4. The result, with numbers
5. What you would do next

**Resume line you can now defend:** _Built a GPU unit-cost scorecard (cost per 1M tokens, cost per successful request, idle spend) and used it to verify a 25% cost reduction and 20% p95 latency improvement on an LLM service._

## Interview check

- How do you measure the cost efficiency of an LLM service? (unit cost, include idle and errors)
- Why is decode memory-bound and prefill compute-bound? (arithmetic intensity vs. ridge point)
- `nvidia-smi` says 100%. Why might throughput still be poor? (utilization = "a kernel was running")
