#!/usr/bin/env python3
"""
Module 1 · Stage 3 — Compute-bound or memory-bound?

A back-of-the-envelope roofline for LLM inference. For every generated token,
the GPU must (a) read all model weights from memory and (b) do ~2 FLOPs per
parameter per sequence in the batch.

  bytes moved per decode step  ~= params * bytes_per_param     (shared by the whole batch)
  FLOPs per decode step        ~= 2 * params * batch
  arithmetic intensity         =  FLOPs / bytes  = 2 * batch / bytes_per_param
  GPU "ridge point"            =  peak FLOP/s / memory bandwidth (bytes/s)

Below the ridge point you are MEMORY-bound (bandwidth sets your speed).
Above it you are COMPUTE-bound (FLOPs set your speed).

Simplifications (say these out loud in an interview): ignores KV-cache reads,
attention FLOPs, kernel efficiency (real systems reach ~50-80% of these ceilings),
and multi-GPU communication. It is a ceiling, not a prediction.

Usage:
  python3 bottleneck.py --params 8e9 --precision fp16 --gpu L4
  python3 bottleneck.py --params 70e9 --precision fp8 --gpu H100-SXM --gpus 2
  python3 bottleneck.py --list
"""
import argparse, json, os

BYTES = {"fp32": 4, "bf16": 2, "fp16": 2, "fp8": 1, "int8": 1, "int4": 0.5}
HERE = os.path.dirname(os.path.abspath(__file__))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--params", type=float, default=8e9, help="model parameters, e.g. 8e9")
    ap.add_argument("--precision", default="fp16", choices=BYTES)
    ap.add_argument("--gpu", default="L4")
    ap.add_argument("--gpus", type=int, default=1, help="GPUs the model is split across (tensor parallel)")
    ap.add_argument("--prompt", type=int, default=1000, help="prompt length for the prefill line")
    ap.add_argument("--list", action="store_true")
    a = ap.parse_args()

    gpus = json.load(open(os.path.join(HERE, "data", "gpus.json")))
    gpus.pop("_note", None)
    if a.list:
        print(f"{'GPU':12s} {'mem GB':>7s} {'BW GB/s':>8s} {'TFLOPS':>7s} {'ridge FLOP/B':>13s} {'$/hr*':>6s}")
        for k, g in gpus.items():
            print(f"{k:12s} {g['memory_gb']:7d} {g['bandwidth_gbs']:8d} {g['fp16_tflops']:7d} "
                  f"{g['fp16_tflops']*1e12/(g['bandwidth_gbs']*1e9):13.0f} {g['price_hr']:6.2f}")
        print("* example prices for the lab; use your own.")
        return

    g = gpus[a.gpu]
    bpp = BYTES[a.precision]
    bw = g["bandwidth_gbs"] * 1e9 * a.gpus
    fp8_ok = a.gpu in ("H100-SXM", "H200", "L40S", "L4")   # Hopper / Ada tensor cores
    if a.precision == "fp8" and not fp8_ok:
        print(f"  note: {a.gpu} has no FP8 tensor cores; weights still shrink but math runs at FP16 speed")
    fast = (a.precision == "fp8" and fp8_ok) or a.precision == "int8"
    flops = g["fp16_tflops"] * 1e12 * a.gpus * (2 if fast else 1)
    weight_bytes = a.params * bpp
    mem_total = g["memory_gb"] * 1e9 * a.gpus

    print(f"\nModel {a.params/1e9:.0f}B params @ {a.precision} on {a.gpus}x {a.gpu}")
    print(f"  weights          {weight_bytes/1e9:7.1f} GB  of {mem_total/1e9:.0f} GB GPU memory "
          f"({weight_bytes/mem_total:.0%})" + ("   <-- DOES NOT FIT" if weight_bytes > mem_total * 0.9 else ""))
    ridge = flops / bw
    print(f"  ridge point      {ridge:7.0f} FLOPs per byte  (peak {flops/1e12:.0f} TFLOPS / {bw/1e9:.0f} GB/s)")
    b_star = ridge * bpp / 2
    print(f"  batch to become compute-bound in decode  ~{b_star:.0f} sequences\n")

    print(f"  {'batch':>6s} {'intensity':>10s} {'bound by':>10s} {'ceiling tok/s (total)':>22s} {'per user':>9s}")
    for b in (1, 4, 16, 32, 64, 128, 256):
        intensity = 2 * b / bpp
        mem_ceiling = b * bw / weight_bytes          # tokens/s if bandwidth-limited
        cmp_ceiling = flops / (2 * a.params)         # tokens/s if compute-limited
        ceiling = min(mem_ceiling, cmp_ceiling)
        bound = "memory" if mem_ceiling < cmp_ceiling else "compute"
        print(f"  {b:6d} {intensity:10.0f} {bound:>10s} {ceiling:22,.0f} {ceiling/b:9,.0f}")

    pre_int = 2 * a.prompt / bpp
    print(f"\n  prefill of a {a.prompt}-token prompt: intensity ~{pre_int:,.0f} FLOPs/byte -> "
          f"{'compute' if pre_int > ridge else 'memory'}-bound")
    usd_per_1m = g["price_hr"] * a.gpus / (min(64 * bw / weight_bytes, flops / (2 * a.params)) * 3600) * 1e6
    print(f"  best-case decode cost at batch 64: ~${usd_per_1m:.3f} per 1M output tokens "
          f"(ceiling; expect 2-3x more in practice)\n")
    print("  Takeaway: at small batches, decode speed is set by memory bandwidth, not FLOPs.")
    print("  Bigger batches and fewer bytes per parameter (quantization) are how you climb the roofline.")
    print("  Reality check: the KV cache, not this table, usually caps your batch size. That is Module 3.\n")


if __name__ == "__main__":
    main()
