# Regenerates the deterministic sample usage data. Run from labs/module-1-measure:  python3 data/make_data.py
import csv, random, math, sys
def gen(path, batching=False):
    random.seed(7); rows=[]
    for svc, gpu, n, price, base_rps, out_len in [("chat-assistant","A100-80GB",4,3.00,6.0,350),("doc-summarizer","L40S",2,1.80,1.6,220)]:
        b = batching and svc=="chat-assistant"   # change ONE thing, on ONE service
        for h in range(24):
            load = 0.15 + 0.85*max(0, math.sin((h-6)/24*2*math.pi))**1.3 if 6<=h<=23 else 0.08
            if svc=="doc-summarizer" and h in (1,2,3,4): load=0.0
            reqs = int(base_rps*3600*load*random.uniform(0.9,1.1))
            err_rate = 0.004 + (0.05 if load>0.85 and not b else 0.0)
            errors = int(reqs*err_rate)
            in_tok = reqs*int(random.uniform(1100,1300) if svc=="chat-assistant" else random.uniform(2800,3200))
            out_tok = reqs*int(out_len*random.uniform(0.9,1.1))
            rows.append(dict(hour=f"2026-10-01T{h:02d}:00", service=svc, gpu_type=gpu, gpus=n-1 if b else n,
                             price_per_gpu_hour=price, requests=reqs, errors=errors, input_tokens=in_tok, output_tokens=out_tok,
                             p95_ttft_ms=int((420 if svc=="chat-assistant" else 900)*(1+1.8*load**3)*(0.8 if b else 1))))
    with open(path,"w",newline="") as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
gen("data/usage_baseline.csv"); gen("data/usage_after.csv", batching=True)
