#!/usr/bin/env python3
"""
Module 1 · Stage 4 — Read the GPU like an SRE.

Runs nvidia-smi if this machine has an NVIDIA GPU; otherwise reads a recorded
sample (data/sample_nvidia_smi.csv) so everyone can do the exercise on a laptop.

It flags the patterns that fool people:
  * "utilization" near 100% but power far below the limit -> busy, not productive
  * memory almost full                                     -> no room for KV cache / bigger batches
  * a GPU at 0%                                            -> paid for, idle
  * clock event reasons (throttling)                       -> hot or power-capped, silently slower

Usage:
  python3 gpu_snapshot.py              # live if nvidia-smi exists, else sample
  python3 gpu_snapshot.py --sample     # force the recorded sample
"""
import csv, io, shutil, subprocess, sys, os

QUERY = "timestamp,index,name,utilization.gpu,memory.used,memory.total,power.draw,power.limit,temperature.gpu,clocks_event_reasons.active"
REASONS = {0x1: "idle", 0x2: "app clocks setting", 0x4: "SW power cap", 0x8: "HW slowdown",
           0x20: "SW thermal slowdown", 0x40: "HW thermal slowdown", 0x80: "HW power brake"}
HERE = os.path.dirname(os.path.abspath(__file__))


def read_rows():
    if "--sample" not in sys.argv and shutil.which("nvidia-smi"):
        res = subprocess.run(["nvidia-smi", f"--query-gpu={QUERY}", "--format=csv,nounits"],
                             capture_output=True, text=True)
        if res.returncode != 0:   # older drivers call it clocks_throttle_reasons
            res = subprocess.run(["nvidia-smi", "--query-gpu=" + QUERY.replace("clocks_event_reasons", "clocks_throttle_reasons"),
                                  "--format=csv,nounits"], capture_output=True, text=True, check=True)
        out = res.stdout
        src = "live nvidia-smi"
    else:
        out = open(os.path.join(HERE, "data", "sample_nvidia_smi.csv")).read()
        src = "recorded sample (no NVIDIA GPU found, or --sample)"
    rows = list(csv.reader(io.StringIO(out)))
    return src, [[c.strip() for c in r] for r in rows[1:] if r]


def num(x):
    try:
        return float(x.split()[0])
    except Exception:
        return float("nan")


def main():
    src, rows = read_rows()
    print(f"\nSource: {src}\n")
    print(f"{'GPU':>3s} {'util%':>6s} {'mem used':>9s} {'power':>12s} {'temp':>5s}  findings")
    for r in rows:
        idx, util = r[1], num(r[3])
        mu, mt = num(r[4]), num(r[5])
        pw, pl = num(r[6]), num(r[7])
        temp = num(r[8])
        try:
            reasons = int(r[9], 16)
        except Exception:
            reasons = 0
        f = []
        if util >= 90 and pw < 0.5 * pl:
            f.append("busy-but-not-productive: high util, low power (memory-bound or stalled kernels)")
        if util < 5:
            f.append("IDLE: you are paying for this GPU")
        if mt and mu / mt > 0.95:
            f.append("memory ~full (normal if vLLM pre-allocated it; otherwise no headroom for batch)")
        active = [v for k, v in REASONS.items() if reasons & k and k != 0x1]
        if active:
            f.append("THROTTLED: " + ", ".join(active))
        if temp >= 85:
            f.append(f"hot ({temp:.0f}C)")
        print(f"{idx:>3s} {util:6.0f} {mu/1024:7.1f}GB {pw:5.0f}/{pl:4.0f} W {temp:4.0f}C  " + ("; ".join(f) or "ok"))
    print("\n'utilization.gpu' only means a kernel was running. It does not mean the GPU did useful work.")
    print("In production, export these with DCGM exporter -> Prometheus and use SM activity and")
    print("tensor-core activity (DCGM_FI_PROF_SM_ACTIVE, DCGM_FI_PROF_PIPE_TENSOR_ACTIVE) instead.\n")


if __name__ == "__main__":
    main()
