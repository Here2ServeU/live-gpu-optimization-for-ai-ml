# GPU unit-cost scorecard

Source: `data/usage_baseline.csv`

### Baseline

| Service | GPU | GPU-hrs | Cost/day | $ / 1M tokens | $ / 1M output | $ / 1k successful req | Success | Idle spend | p95 TTFT (worst hr) |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| chat-assistant | A100-80GB | 96 | $288.00 | $0.952 | $4.191 | $1.498 | 97.06% | 0.0% | 1176 ms |
| doc-summarizer | L40S | 48 | $86.40 | $0.540 | $7.700 | $1.773 | 96.99% | 16.7% | 2520 ms |

### After one change

| Service | GPU | GPU-hrs | Cost/day | $ / 1M tokens | $ / 1M output | $ / 1k successful req | Success | Idle spend | p95 TTFT (worst hr) |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| chat-assistant | A100-80GB | 72 | $216.00 | $0.688 | $3.105 | $1.079 | 99.61% | 0.0% | 940 ms |
| doc-summarizer | L40S | 48 | $86.40 | $0.531 | $7.708 | $1.696 | 99.62% | 16.7% | 2016 ms |

### What changed

- chat-assistant: cost per 1M tokens -27.8% ($0.952 -> $0.688), worst-hour p95 TTFT -20.1%, success rate +2.55 pts
- doc-summarizer: cost per 1M tokens -1.7% ($0.540 -> $0.531), worst-hour p95 TTFT -20.0%, success rate +2.63 pts

> Resume line template: _Cut cost per 1M tokens by X% and p95 TTFT by Y% on <service> by <one change>, verified against a measured baseline._
