#!/usr/bin/env python3
"""
Module 6 · Stage 3 — SLOs and error budgets.

An SLO (service level objective) is a promise about what users feel, measured
over a window. This script reads 30 days of hourly production counts and, for
two SLOs:

  availability   good = the request succeeded            (default target 99.5%)
  latency        good = first token arrived within 1 s   (default target 95%,
                 which is the same promise as "p95 TTFT under 1 s")

computes:
  * the SLI (what you actually delivered)
  * the error budget: how many bad requests you were allowed this window,
    how many you spent, and how much is left
  * burn rate: how fast you are spending it right now (1.0 = exactly on pace
    to spend the whole budget by the end of the window)
  * multi-window burn-rate alerts, using the thresholds from the Google SRE
    workbook for a 30-day window: page at 14.4x over 1 h (2% of the budget in an
    hour) or 6x over 6 h (5%); open a ticket at 1x over 3 days (10%).
    The workbook pairs each long window with a short one (5 m, 30 m, 6 h) so
    alerts stop quickly after recovery; hourly data cannot show 5 m or 30 m,
    so this script checks the long windows and the 6 h short window only.
  * a decision: SHIP (budget left: optimizations may go out, through a canary)
    or FREEZE (budget gone or burning: reliability work only).

Usage:
  python3 slo_report.py
  python3 slo_report.py --availability 99.9          # a stricter promise, same month
  python3 slo_report.py --loadtest reports/loadtest_baseline.csv

Writes reports/slo_report.md and reports/slo_status.json (canary.py reads it).
Only the Python standard library is used.
"""
import argparse, csv, json, os

HERE = os.path.dirname(os.path.abspath(__file__))
PAGE_RULES = [("page", 1, 14.4, None), ("page", 6, 6.0, None), ("ticket", 72, 1.0, 6)]  # (kind, long h, burn, short h)


def load(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        for k in ("requests", "errors", "slow_ttft", "queue_p95_ms"):
            r[k] = int(r[k])
    return rows


def burn(rows, bad_key, target, hours, end=None):
    end = len(rows) if end is None else end
    w = rows[max(0, end - hours):end]
    tot = sum(r["requests"] for r in w); bad = sum(r[bad_key] for r in w)
    return (bad / tot) / (1 - target) if tot else 0.0


def analyse(rows, name, bad_key, target, freeze_below):
    tot = sum(r["requests"] for r in rows); bad = sum(r[bad_key] for r in rows)
    allowed = (1 - target) * tot
    remaining = 1 - bad / allowed if allowed else 0.0
    now = {h: burn(rows, bad_key, target, h) for h in (1, 6, 72)}
    alerts_now = []
    for kind, long_h, thr, short_h in PAGE_RULES:
        if now[long_h] >= thr and (short_h is None or now[short_h] >= thr):
            alerts_now.append(f"{kind}: burn {now[long_h]:.1f}x over {long_h} h (threshold {thr}x)")
    # replay the month: when would each rule have fired?
    fired = []
    for kind, long_h, thr, short_h in PAGE_RULES:
        hits = [i for i in range(long_h, len(rows) + 1)
                if burn(rows, bad_key, target, long_h, i) >= thr
                and (short_h is None or burn(rows, bad_key, target, short_h, i) >= thr)]
        if hits:
            first = rows[hits[0] - 1]["hour"]
            fired.append(f"{kind} ({thr}x over {long_h} h) first fired at {first}, active for {len(hits)} h")
    return {"name": name, "target": target, "sli": 1 - bad / tot, "total": tot, "bad": bad,
            "allowed": allowed, "remaining": remaining, "burn_now": now, "alerts_now": alerts_now,
            "fired_in_window": fired, "ok": remaining >= freeze_below and not alerts_now}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--log", default=os.path.join(HERE, "data", "requests_30d.csv"))
    ap.add_argument("--availability", type=float, default=99.5, help="target %% of requests that succeed")
    ap.add_argument("--latency", type=float, default=95.0, help="target %% of requests with TTFT <= 1 s")
    ap.add_argument("--freeze-below", type=float, default=0.25, help="freeze when less than this share of budget is left")
    ap.add_argument("--loadtest", help="optional loadtest CSV: check each concurrency level against the same targets")
    ap.add_argument("--outdir", default=os.path.join(HERE, "reports"))
    a = ap.parse_args(argv)

    rows = load(a.log)
    res = [analyse(rows, "availability (request succeeds)", "errors", a.availability / 100, a.freeze_below),
           analyse(rows, "latency (TTFT <= 1 s)", "slow_ttft", a.latency / 100, a.freeze_below)]
    decision = "SHIP" if all(r["ok"] for r in res) else "FREEZE"

    print(f"\nSLO REPORT  {os.path.basename(a.log)}  ({len(rows)} hours, {rows[0]['hour'][:10]} to {rows[-1]['hour'][:10]})")
    md = ["# SLO and error-budget report", "",
          f"Source: `{os.path.relpath(a.log, HERE)}` · {len(rows)} hours · window: 30 days", "",
          "| SLO | Target | Delivered | Budget (bad requests allowed) | Spent | Budget left | Burn 1 h / 6 h / 3 d |",
          "|---|---:|---:|---:|---:|---:|---|"]
    for r in res:
        b = r["burn_now"]
        print(f"  {r['name']:31s} target {r['target']:.2%}  delivered {r['sli']:.3%}  "
              f"budget left {r['remaining']:6.1%}   burn now 1h {b[1]:.1f}x  6h {b[6]:.1f}x  3d {b[72]:.1f}x")
        for f in r["fired_in_window"]:
            print(f"    this month: {f}")
        for al in r["alerts_now"]:
            print(f"    ACTIVE NOW: {al}")
        md.append(f"| {r['name']} | {r['target']:.2%} | {r['sli']:.3%} | {r['allowed']:,.0f} | {r['bad']:,} | "
                  f"**{r['remaining']:.1%}** | {b[1]:.1f}x / {b[6]:.1f}x / {b[72]:.1f}x |")
    md += ["", "### Alerts this month (multi-window burn rate, SRE workbook thresholds for a 30-day SLO)", ""]
    for r in res:
        md += [f"- **{r['name']}:** " + ("; ".join(r["fired_in_window"]) or "no alert would have fired")]
    notes = [rr["note"] for rr in rows if rr["note"]]
    if notes:
        md += ["", "Incidents in the log: " + ", ".join(sorted(set(notes))) + "."]

    if decision == "SHIP":
        why = (f"every SLO has at least {a.freeze_below:.0%} of its budget left and nothing is burning fast. "
               "Optimizations may ship, through a canary with automatic rollback.")
    else:
        bad = [r["name"] for r in res if not r["ok"]]
        why = (f"{', '.join(bad)}: budget under {a.freeze_below:.0%} or burning fast. "
               "Ship only reliability fixes until the budget recovers.")
    print(f"\n  DECISION: {decision} · {why}")
    md += ["", f"## Decision: **{decision}**", "", why]

    if a.loadtest:
        with open(a.loadtest, newline="") as f:
            lt = list(csv.DictReader(f))
        md += ["", f"### Load test levels against the same targets (`{os.path.basename(a.loadtest)}`)", "",
               "| Concurrency | Success rate | p95 TTFT | Within both targets |", "|---:|---:|---:|:---:|"]
        print(f"\n  load test levels vs targets ({os.path.basename(a.loadtest)}):")
        for r in lt:
            succ = 1 - float(r["error_rate"]); p95 = float(r["p95_ttft_ms"])
            ok = succ >= a.availability / 100 and p95 <= 1000
            md.append(f"| {r['concurrency']} | {succ:.1%} | {p95:.0f} ms | {'yes' if ok else 'no'} |")
            print(f"    {int(r['concurrency']):4d} users  success {succ:6.1%}  p95 TTFT {p95:6.0f} ms  {'ok' if ok else 'outside SLO'}")

    os.makedirs(a.outdir, exist_ok=True)
    with open(os.path.join(a.outdir, "slo_report.md"), "w") as f:
        f.write("\n".join(md) + "\n")
    status = {"decision": decision, "slos": [{k: r[k] for k in ("name", "target", "sli", "remaining", "alerts_now")} for r in res]}
    with open(os.path.join(a.outdir, "slo_status.json"), "w") as f:
        json.dump(status, f, indent=2)
    print(f"  wrote {os.path.relpath(os.path.join(a.outdir, 'slo_report.md'))} and slo_status.json\n")
    return status


if __name__ == "__main__":
    main()
