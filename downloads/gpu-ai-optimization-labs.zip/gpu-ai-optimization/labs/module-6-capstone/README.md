# Module 6 Lab · The Capstone: Prove It in Production

**Time:** ~60 minutes (plus the write-up) · **Runs on:** any laptop (Python 3.9+, no installs, offline) · **Optional:** a real vLLM server on an NVIDIA GPU

An optimization nobody trusts never ships. In this lab you turn one optimization into **evidence**: a production-style load test, an error-budget decision, a canary verdict, an energy number, and a one-page report you can put in your portfolio and tell in an interview.

| Script | Question it answers |
|---|---|
| `mock_server.py` | A simulated LLM server (continuous batching, KV cache, prefix cache, load shedding) with an OpenAI-style `POST /v1/completions` and Prometheus `GET /metrics`. Profiles: `baseline` (FP16), `optimized` (FP8), `int4`. |
| `loadtest.py` | Where is my breaking point? Ramps concurrency with a real prompt **and** output length mix; finds the highest concurrency that meets p95 TTFT; reports tokens/s per GPU and error rate. Works against real vLLM too. |
| `slo_report.py` | How much error budget is left this month, how fast is it burning, and may we ship? |
| `canary.py` | Does the new build pass every guardrail (latency, errors, capacity, quality, budget)? PROMOTE or ROLL BACK. |
| `power.py` | Tokens per joule, and which power cap saves the most energy for the least speed. |
| `run_capstone.py` | Everything above in one command: starts and stops the servers, writes every report. |
| `CAPSTONE.md` | The template you fill in: optimization report, three resume bullets, a two-minute interview story. |

> **About the simulator.** `mock_server.py` simulates one GPU running an 8B-class model with **illustrative** parameters. It behaves like the real thing (prefill competes with decode, the KV cache fills, queues build, prefix-cache hits skip work), but its numbers are not a benchmark of any real GPU. Real FP8 gains vary by GPU, model and engine. The **method** is what transfers: run the same `loadtest.py` against a real server (Optional GPU track) and every report works unchanged.

---

## Stage 1 · Set up and start the server (5 min)

```bash
# macOS / Linux
cd labs/module-6-capstone
python3 -m venv .venv && source .venv/bin/activate
python3 mock_server.py --profile baseline          # terminal 1: leave it running
```
```powershell
# Windows PowerShell
cd labs\module-6-capstone
py -m venv .venv; .venv\Scripts\Activate.ps1
py mock_server.py --profile baseline               # terminal 1: leave it running
```

You should see:
```
mock LLM server · profile=baseline (FP16 weights + FP16 KV cache) · speed=20.0x · prefix cache on
  max_seqs=64  kv_capacity=60,000 tokens  step=9.0 ms + 0.18 ms/seq
  listening on http://127.0.0.1:8000  (POST /v1/completions, GET /metrics)  Ctrl+C to stop
```

Open a **second terminal** in the same folder (activate the venv there too). Everything below runs in terminal 2. Peek at the server's metrics, the same kind vLLM exposes: `curl -s localhost:8000/metrics` (Windows: `curl.exe -s localhost:8000/metrics`).

`--speed 20` runs simulated time 20x faster than real time. Every latency the server reports is in **model time**, so your numbers match the ones below on any laptop. Stop the server with **Ctrl+C**; it prints `server stopped · served N requests, M errors`.

## Stage 2 · Load test like production (15 min)

First, the classic mistake: one short prompt, replayed.

```bash
python3 loadtest.py --label naive --mix data/traffic_naive.json
```
```
  BREAKING POINT 64 users (p95 TTFT <= 1000 ms): 3,076 output tok/s per GPU, errors 0.0%
```

Now the real mix (`data/traffic_mix.json`: 55% chat, 30% long RAG prompts, 15% code with long answers, each with a shared system prompt):

```bash
python3 loadtest.py --label baseline
```
```
  users  reqs  p50 TTFT  p95 TTFT  p95 e2e  tok/s/GPU  errors  cache  SLO
      1    60      41ms     174ms     8.8s        106    0.0%    36%  ok
      8    60      50ms     365ms    11.6s        634    0.0%    38%  ok
     12    60      52ms     827ms    13.1s        830    0.0%    38%  ok
     16    60      78ms    1014ms    13.7s        985    0.0%    38%  BREAKS
     24    72      80ms    1488ms    15.7s      1,206    0.0%    40%  BREAKS
     32    96    1202ms    3347ms    16.1s      1,242    0.0%    41%  BREAKS
     48   144    3035ms    4895ms    20.8s      1,364   17.4%    43%  BREAKS
  BREAKING POINT 12 users (p95 TTFT <= 1000 ms): 830 output tok/s per GPU, errors 0.0%
```
(some levels omitted here). Read it like an SRE:

- The naive test said **64 users and 3,076 tok/s**. The real mix says **12 users and 830 tok/s**: the naive test was about **3.7x too optimistic**. Long prompts (prefill) and long answers (decode) are the load.
- p95 TTFT stays flat, then **bends up** between 12 and 16 users. Past 32 users, requests queue for seconds; at 48 the server starts shedding load (17.4% errors).
- Throughput keeps rising after the SLO breaks. **Capacity is the highest load that still meets the SLO**, not the highest tokens/s.

Now turn off the help from the prefix cache (a unique first word in every prompt):

```bash
python3 loadtest.py --label baseline-nocache --cache-bust
```
```
  BREAKING POINT 8 users (p95 TTFT <= 1000 ms): 592 output tok/s per GPU, errors 0.0%
```

Cache hits were carrying a third of your capacity (12 → 8 users). If a deploy changes the system prompt, the cache goes cold and that capacity disappears. Plan capacity on the cache-busted number, or at least know both.

**Do:** open `reports/loadtest_baseline.md`. Write down: breaking point, tokens/s per GPU there, error rate there, and the cache-busted breaking point.

## Stage 3 · SLOs and error budgets (10 min)

`data/requests_30d.csv` is 30 days of hourly counts for this endpoint, with one bad deploy and one latency regression in it.

```bash
python3 slo_report.py
```
```
  availability (request succeeds) target 99.50%  delivered 99.713%  budget left  42.7%   burn now 1h 0.3x  6h 0.4x  3d 0.4x
    this month: page (14.4x over 1 h) first fired at 2026-09-09T14:00, active for 3 h
  latency (TTFT <= 1 s)           target 95.00%  delivered 97.297%  budget left  45.9%   burn now 1h 0.5x  6h 0.5x  3d 0.5x
    this month: ticket (1.0x over 72 h) first fired at 2026-09-21T16:00, active for 8 h

  DECISION: SHIP · every SLO has at least 25% of its budget left and nothing is burning fast. ...
```

- The bad deploy burned the budget at 30x for three hours: the fast-burn rule (14.4x over 1 h, from the Google SRE workbook for a 30-day SLO) pages someone. The latency regression burned slowly (4x): a ticket, not a page.
- 42.7% of the availability budget is left, so you may **spend some of it on change**: ship the optimization, through a canary.

Same month, stricter promise:
```bash
python3 slo_report.py --availability 99.9
```
```
  availability (request succeeds) target 99.90%  delivered 99.713%  budget left -186.7%   burn now 1h 1.6x  6h 1.9x  3d 2.0x
  DECISION: FREEZE · availability (request succeeds): budget under 25% or burning fast. Ship only reliability fixes ...
```
The target is a business decision. It decides whether speed work or stability work comes next.

## Stage 4 · Change one thing, ship it safely (15 min)

Stop the server (Ctrl+C) and start the **one change**: FP8 weights and FP8 KV cache.

```bash
python3 mock_server.py --profile optimized          # terminal 1
python3 loadtest.py --label optimized               # terminal 2
```
```
     12    60      37ms     580ms     9.2s      1,181    0.0%    38%  ok
     16    60      54ms     711ms     9.6s      1,408    0.0%    38%  ok
     24    72      56ms    1042ms    10.9s      1,737    0.0%    40%  BREAKS
  BREAKING POINT 16 users (p95 TTFT <= 1000 ms): 1,408 output tok/s per GPU, errors 0.0%
```

Faster is not the same as safe to ship. Run the canary analysis: the same comparison a rollout tool runs at every traffic step.

```bash
python3 canary.py --baseline reports/loadtest_baseline.csv --candidate reports/loadtest_optimized.csv --build fp8
```
```
CANARY ANALYSIS  candidate build 'fp8' vs baseline, at 12 concurrent users
  p95 TTFT                       827 ms     580 ms  <= 1000 ms and <= +10%     pass
  error rate                       0.0%       0.0%  <= +0.5 pts                pass
  output tok/s per GPU              830      1,181  >= 95% of baseline         pass
  eval accuracy                   84.0%      83.7%  drop <= 1.0 pt             pass
  worst category (chat)           86.0%      85.3%  drop <= 5 pts              pass
  error budget                                SHIP  decision is SHIP           pass
  VERDICT: PROMOTE  (p95 TTFT -30%, tokens/s per GPU +42%, quality -0.3 pt)
```

Now a tempting change that should **not** ship: INT4 weights. Stop the server, start `--profile int4`, load test it, judge it:

```bash
python3 mock_server.py --profile int4               # terminal 1
python3 loadtest.py --label int4                    # terminal 2
python3 canary.py --baseline reports/loadtest_baseline.csv --candidate reports/loadtest_int4.csv --build int4
```
```
  output tok/s per GPU              830      1,125  >= 95% of baseline         pass
  eval accuracy                   84.0%      79.3%  drop <= 1.0 pt             FAIL
  worst category (code)           74.0%      62.0%  drop <= 5 pts              FAIL
  VERDICT: ROLL BACK
```
Faster (+36% tokens/s at 12 users) and wrong more often, mostly on code. Without a quality guardrail, this ships. The eval is `data/eval_results.csv`: 300 graded items for each build.

## Stage 5 · Performance per watt (5 min)

```bash
python3 power.py          # reads reports/loadtest_baseline.csv and reports/loadtest_optimized.csv
```
```
  baseline      12 users      830 tok/s   1.27 tokens/J     219 Wh per 1M output tokens
  optimized     16 users    1,408 tok/s   2.15 tokens/J     129 Wh per 1M output tokens
  -> optimized vs baseline: +70% tokens per joule, -41% energy per token
  RECOMMENDATION: cap at 500 W: power -24%, speed -4%, tokens per joule +27% (lowest cap keeping >= 95% of throughput)
```
- Same board power, more tokens: quantization cuts **energy** per token, not only cost.
- The power-cap sweep uses `data/power_curve.json`, an **illustrative** curve with a typical shape. A modest cap often saves a lot of power for a small speed loss, because decode is memory-bound. Verify on your own hardware before you believe it (Optional GPU track).

## The whole capstone in one command

```bash
python3 run_capstone.py --self-test     # ~40 s smoke test of the whole pipeline; ends with SELF-TEST PASSED
python3 run_capstone.py                 # everything (about 5 minutes); starts and stops its own servers
```
`run_capstone.py` starts a fresh mock server for each test on a free port, runs it, stops it cleanly, then writes `reports/capstone_summary.md`:

```
  naive              breaking point  64 users    3,076 tok/s/GPU  p95 TTFT    19 ms  errors 0.0%
  baseline           breaking point  12 users      830 tok/s/GPU  p95 TTFT   827 ms  errors 0.0%
  baseline-nocache   breaking point   8 users      592 tok/s/GPU  p95 TTFT   548 ms  errors 0.0%
  optimized          breaking point  16 users    1,408 tok/s/GPU  p95 TTFT   711 ms  errors 0.0%
  optimized-nocache  breaking point  12 users    1,080 tok/s/GPU  p95 TTFT   773 ms  errors 0.0%
  int4               breaking point  16 users    1,280 tok/s/GPU  p95 TTFT   971 ms  errors 0.0%
  Baseline -> FP8 at the SLO: 12 -> 16 users, 830 -> 1,408 tok/s per GPU (+70%)
  error budget: SHIP   canary fp8: PROMOTE   canary int4: ROLL BACK
```

Numbers are reproducible: the load test sends the same request shapes every run, and the simulator orders arrivals deterministically (the `X-Loadtest-*` headers; real servers ignore them). If you re-run a test against a server that is already warm, level 1 can differ by a few ms because the shared system prompts are already cached. On Windows the simulation may run slower in wall-clock time; the reported numbers do not change.

## Write the capstone (the real deliverable)

Open `CAPSTONE.md`. It has the template and a fully worked example built from the numbers above. Replace them with yours.

---

## Optional GPU track: the same test against real vLLM

On a Linux machine with an NVIDIA GPU:

```bash
pip install vllm
vllm serve <model-you-have-access-to> --port 8000            # OpenAI-compatible server
python3 loadtest.py --url http://localhost:8000 --label vllm-fp16 --stream --levels 1,2,4,8,16,32,64
vllm serve <same-model> --port 8000 --quantization fp8 --kv-cache-dtype fp8   # the one change (FP8 GPUs, e.g. Hopper/Ada)
python3 loadtest.py --url http://localhost:8000 --label vllm-fp8 --stream --levels 1,2,4,8,16,32,64
python3 canary.py --baseline reports/loadtest_vllm-fp16.csv --candidate reports/loadtest_vllm-fp8.csv --build fp8
curl -s localhost:8000/metrics | grep -E "vllm:num_requests_(running|waiting)|vllm:kv_cache_usage_perc"
```
- Use `--stream`: a non-streaming response does not reveal TTFT, so without it the report uses end-to-end latency as an upper bound and labels it `e2e (non-streaming upper bound)`.
- The client sends `ignore_eos: true` (a vLLM option) so each request generates exactly the output length the mix asked for. Without it, real models stop early and the test under-loads decode.
- Use your own eval for the quality guardrail (for example, a few hundred graded prompts from your product). Add a column per build to `data/eval_results.csv`.
- Power: run `python3 power.py --live 60` during a load test to sample `power.draw`, SM clock, temperature and throttle reasons. Then sweep caps with `sudo nvidia-smi -i 0 -pl <watts>`, re-run the load test at your breaking point, and replace the rows in `data/power_curve.json` with what you measured. Metric names vary across vLLM versions; check your `/metrics` output.

## Deliverable (portfolio)

Commit to your course repo:

1. `reports/` from this lab: the load tests, `slo_report.md`, both `canary_*.md`, `power.md`, `capstone_summary.md`
2. `CAPSTONE.md`, filled in with **your** numbers (simulated or real; say which)
3. The `FINDINGS.md` from every module, linked from one top-level `README.md` that says in three lines who you are, what you built, and the best number you have

**Resume line you can now defend:** _Load tested an LLM endpoint with a production prompt/output mix, found the p95 TTFT breaking point, and shipped an FP8 change through a guarded canary: +70% tokens/s per GPU at the same p95 TTFT target, with a 0.3-point quality cost._

## Interview check

- How would you load test an LLM endpoint? (real prompt and output mix; ramp concurrency; p95 TTFT knee; cache on and off; tokens/s per GPU and errors at the knee)
- How do you roll out a quantized model without hurting users? (eval first; shadow; canary steps with written guardrails including quality; watch budget burn; fast rollback)
- What is an error budget and how does it change what you ship? (1 - SLO; budget left = ship through a canary; budget gone = reliability work; alert on burn rate, not single errors)
- Walk me through a performance improvement you made. (the `CAPSTONE.md` story: baseline, bottleneck, one change, result with numbers, how you shipped it safely)
