#!/usr/bin/env python3
"""
Module 6 · A simulated LLM server you can load test on a laptop.

It speaks a small, OpenAI-style API so the same load tester works against it
and against a real vLLM server:

  POST /v1/completions   {"prompt": "...", "max_tokens": 200, "stream": false}
  GET  /metrics          Prometheus text format (running, waiting, KV usage, tokens)
  GET  /health           "ok"

Inside, it simulates ONE GPU running continuous batching, the way vLLM does:

  * a step loop. Each step: every running sequence decodes one token, and any
    leftover token budget is spent prefilling new prompts (chunked prefill).
  * step time = base + per_seq * decoding_seqs + per_kv * context_tokens
              + per_prefill_token * prefill_tokens
  * a max running batch (max_seqs) and a KV-cache capacity in tokens.
    Requests that do not fit WAIT in a queue. If the KV cache fills up during
    decode, the newest sequence is preempted and recomputed later.
  * optional prefix caching: prompt blocks of 16 tokens that were seen before
    are not prefilled again (this is why cache hits can hide real capacity).
  * load shedding: a request that waits longer than --queue-timeout-ms gets 503.

Tokens are counted as whitespace-separated words. The parameters are
ILLUSTRATIVE: shaped like an 8B model on one GPU with a modest KV-cache budget.
They are chosen to behave like the real thing, not to benchmark any real GPU.

Profiles:
  baseline   FP16 weights and KV cache
  optimized  FP8 weights + FP8 KV cache: faster steps, ~2x KV capacity
  int4       INT4 weight-only: fastest at small batch, no prefill gain, quality risk

Time: the simulation keeps its own "model clock". --speed 20 (the default) runs it
20x faster than real time; every latency it reports is in model time, so results do not
depend on how fast your laptop is.

Usage:
  python3 mock_server.py --profile baseline --port 8000
  python3 mock_server.py --profile optimized --port 8001 --speed 10
  python3 mock_server.py --list-profiles

Stop it with Ctrl+C. Only the Python standard library is used.
"""
import argparse, asyncio, collections, json, signal, sys, time

PROFILES = {
    # all times in model milliseconds; kv_capacity in tokens
    "baseline": dict(desc="FP16 weights + FP16 KV cache",
                     step_base_ms=9.0, per_seq_ms=0.18, per_kv_token_ms=0.00004,
                     prefill_ms_per_token=0.040, max_seqs=64, max_batched_tokens=2048,
                     kv_capacity=60000, watts_idle=90, watts_busy=650),
    "optimized": dict(desc="FP8 weights + FP8 KV cache (quantized)",
                      step_base_ms=6.5, per_seq_ms=0.13, per_kv_token_ms=0.00002,
                      prefill_ms_per_token=0.028, max_seqs=128, max_batched_tokens=2048,
                      kv_capacity=120000, watts_idle=90, watts_busy=620),
    "int4": dict(desc="INT4 weight-only (W4A16): fast small-batch decode, FP16 KV cache",
                 step_base_ms=5.0, per_seq_ms=0.20, per_kv_token_ms=0.00004,
                 prefill_ms_per_token=0.040, max_seqs=64, max_batched_tokens=2048,
                 kv_capacity=80000, watts_idle=90, watts_busy=600),
}
BLOCK = 16          # prefix-cache block size in tokens (vLLM's default block size is 16)
WORDS = ("the of and to in is that for it with as on was be at by this an are from or "
         "model token cache batch latency request user answer data value").split()


class Seq:
    __slots__ = ("rid", "prompt_len", "max_tokens", "to_prefill", "generated", "kv", "arrival",
                 "admitted", "first_token", "done", "fut", "stream_q", "cached", "words", "preempted", "seq")

    def __init__(self, rid, words, max_tokens, arrival, stream):
        self.rid = rid; self.words = words; self.prompt_len = max(1, len(words))
        self.max_tokens = max(1, max_tokens); self.to_prefill = self.prompt_len
        self.generated = 0; self.kv = 0; self.arrival = arrival; self.admitted = None
        self.first_token = None; self.done = None; self.cached = 0; self.preempted = 0; self.seq = 0
        self.fut = asyncio.get_running_loop().create_future()
        self.stream_q = asyncio.Queue() if stream else None


class Engine:
    def __init__(self, profile, speed, prefix_cache, queue_timeout_ms):
        self.p = PROFILES[profile]; self.name = profile; self.speed = speed
        self.prefix_cache = prefix_cache; self.queue_timeout_ms = queue_timeout_ms
        self.clock = 0.0                       # model time, ms
        self.waiting = collections.deque(); self.running = []
        self.kv_used = 0
        self.cache = collections.OrderedDict()  # block hash -> None (LRU)
        self.cache_blocks = self.p["kv_capacity"] // BLOCK
        self.wake = asyncio.Event(); self.next_id = 0
        self.c = collections.Counter()         # counters for /metrics
        self.busy_ms = 0.0
        self.inbox = []                        # arrivals since the last step
        self.ls = None                         # lockstep state (see _barrier)
        self.arrived = asyncio.Event()
        self.lockstep_timeouts = 0

    # ---- prefix cache ----
    def _block_hashes(self, words):
        hs, h = [], 0
        for i in range(0, len(words) - len(words) % BLOCK, BLOCK):
            h = hash((h, tuple(words[i:i + BLOCK]))); hs.append(h)
        return hs

    def _lookup_and_insert(self, words):
        if not self.prefix_cache:
            return 0
        hit, missed = 0, False
        for h in self._block_hashes(words):
            if not missed and h in self.cache:
                self.cache.move_to_end(h); hit += BLOCK
            else:
                missed = True
                self.cache[h] = None
                if len(self.cache) > self.cache_blocks:
                    self.cache.popitem(last=False)
        return min(hit, len(words) - 1)        # always compute at least one token

    # ---- API ----
    def submit(self, words, max_tokens, stream=False, lockstep=None):
        s = Seq(self.next_id, words, max_tokens, self.clock, stream)
        self.next_id += 1; self.c["requests_total"] += 1
        if lockstep:
            ls = self.ls
            if ls is None or ls["level"] != lockstep["level"]:
                ls = self.ls = {"level": lockstep["level"], "total": lockstep["total"], "conc": lockstep["conc"],
                                "max_seq": -1, "arrived": 0, "awaiting": 0}
            ls["arrived"] += 1; ls["max_seq"] = max(ls["max_seq"], lockstep["seq"])
            ls["awaiting"] = max(0, ls["awaiting"] - 1)
            s.seq = lockstep["seq"]
        self.inbox.append(s)
        self.wake.set(); self.arrived.set()
        return s

    async def _barrier(self, grace_s=2.0):
        """Lockstep mode, used only when the lab's load tester sends X-Loadtest-* headers.
        In a closed-loop test every finished request is followed at once by that user's next
        request. Real networks add random microseconds that would reorder arrivals between runs.
        Here the simulator pauses (in real time; model time does not move) until those follow-up
        requests have arrived, then admits them in sequence order. Result: identical numbers on
        every run and every laptop. Real servers ignore the headers."""
        ls = self.ls
        if ls is None:
            return
        deadline = time.perf_counter() + grace_s
        while True:
            unsent = ls["total"] - ls["arrived"]      # requests of this level not yet received
            starting = ls["arrived"] < min(ls["conc"], ls["total"])
            if not starting and min(ls["awaiting"], unsent) <= 0:
                return
            left = deadline - time.perf_counter()
            if left <= 0:
                self.lockstep_timeouts += 1
                ls["awaiting"] = 0
                return
            self.arrived.clear()
            try:
                await asyncio.wait_for(self.arrived.wait(), left)
            except asyncio.TimeoutError:
                pass

    # ---- scheduler ----
    def _admit(self):
        p = self.p
        while self.waiting:
            s = self.waiting[0]
            if self.clock - s.arrival > self.queue_timeout_ms and s.first_token is None:
                self.waiting.popleft(); self.c["rejected_total"] += 1
                self._finish(s, error="queue timeout: server overloaded (load shed)")
                continue
            if len(self.running) >= p["max_seqs"]:
                break
            need = s.prompt_len + s.generated
            if self.kv_used + need > p["kv_capacity"]:
                if not self.running and need > p["kv_capacity"]:
                    self.waiting.popleft()
                    self._finish(s, error="prompt longer than KV cache capacity")
                    continue
                break
            self.waiting.popleft()
            if s.admitted is None:
                s.admitted = self.clock
                s.cached = self._lookup_and_insert(s.words)
                self.c["prefix_cache_queries"] += s.prompt_len
                self.c["prefix_cache_hits"] += s.cached
                s.to_prefill = s.prompt_len - s.cached
            s.kv = need; self.kv_used += need
            self.running.append(s)

    def _preempt_newest(self):
        s = self.running.pop()
        self.kv_used -= s.kv; s.kv = 0
        s.to_prefill = s.prompt_len + s.generated     # recompute preemption
        s.preempted += 1; self.c["preemptions_total"] += 1
        self.waiting.appendleft(s)

    async def run(self):
        p = self.p
        while True:
            if not self.running and not self.waiting and not self.inbox:
                self.wake.clear(); await self.wake.wait()
            await self._barrier()
            if self.inbox:
                self.inbox.sort(key=lambda x: (x.seq, x.rid))
                self.waiting.extend(self.inbox); self.inbox = []
            shed_before = self.c["rejected_total"]
            self._admit()
            if self.ls is not None and self.c["rejected_total"] != shed_before:
                continue                                 # a shed request's user will retry; wait for it
            if not self.running:
                await asyncio.sleep(0.001); self.clock += 1.0; continue
            decoding = [s for s in self.running if s.to_prefill == 0]
            while decoding and self.kv_used + len(decoding) > p["kv_capacity"] and len(self.running) > 1:
                self._preempt_newest()
                decoding = [s for s in self.running if s.to_prefill == 0]
            budget = p["max_batched_tokens"] - len(decoding)
            chunks = []
            for s in self.running:
                if s.to_prefill > 0 and budget > 0:
                    n = min(s.to_prefill, budget); chunks.append((s, n)); budget -= n
            ctx = sum(s.prompt_len + s.generated for s in decoding)
            n_pre = sum(n for _, n in chunks)
            step = (p["step_base_ms"] + p["per_seq_ms"] * len(decoding)
                    + p["per_kv_token_ms"] * ctx + p["prefill_ms_per_token"] * n_pre)
            await asyncio.sleep(step / 1000.0 / self.speed)
            self.clock += step; self.busy_ms += step
            self.c["prompt_tokens_total"] += n_pre
            for s in decoding:
                self._emit(s)
            for s, n in chunks:
                s.to_prefill -= n
                if s.to_prefill == 0:
                    self._emit(s)              # finishing prefill produces the first token
            for s in [s for s in self.running if s.generated >= s.max_tokens]:
                self.running.remove(s); self.kv_used -= s.kv; s.kv = 0
                self._finish(s)

    def _emit(self, s):
        if s.first_token is None:
            s.first_token = self.clock
        s.generated += 1; s.kv += 1; self.kv_used += 1
        self.c["generation_tokens_total"] += 1
        if s.stream_q is not None:
            s.stream_q.put_nowait(WORDS[(s.rid + s.generated) % len(WORDS)])

    def _finish(self, s, error=None):
        s.done = self.clock
        if self.ls is not None:
            self.ls["awaiting"] += 1           # its user will send a follow-up (if any work is left)
        if error:
            self.c["errors_total"] += 1
        else:
            self.c["success_total"] += 1
        if s.stream_q is not None:
            s.stream_q.put_nowait(None)
        if not s.fut.done():
            s.fut.set_result(error)

    def timing(self, s):
        return {"arrival_ms": round(s.arrival, 3), "finish_ms": round(s.done, 3),
                "ttft_ms": round(s.first_token - s.arrival, 3) if s.first_token is not None else None,
                "total_ms": round(s.done - s.arrival, 3),
                "queue_ms": round((s.admitted if s.admitted is not None else s.done) - s.arrival, 3),
                "cached_tokens": s.cached, "preemptions": s.preempted,
                "speed": self.speed, "profile": self.name}

    def metrics(self):
        p = self.p
        watts = p["watts_idle"] + (p["watts_busy"] - p["watts_idle"]) * (1.0 if self.running else 0.0)
        m = [("num_requests_running", "gauge", len(self.running)),
             ("num_requests_waiting", "gauge", len(self.waiting)),
             ("kv_cache_usage_perc", "gauge", round(self.kv_used / p["kv_capacity"], 4)),
             ("prompt_tokens_total", "counter", self.c["prompt_tokens_total"]),
             ("generation_tokens_total", "counter", self.c["generation_tokens_total"]),
             ("prefix_cache_queries_total", "counter", self.c["prefix_cache_queries"]),
             ("prefix_cache_hits_total", "counter", self.c["prefix_cache_hits"]),
             ("num_preemptions_total", "counter", self.c["preemptions_total"]),
             ("request_success_total", "counter", self.c["success_total"]),
             ("request_errors_total", "counter", self.c["errors_total"]),
             ("model_clock_seconds", "counter", round(self.clock / 1000, 3)),
             ("simulated_power_watts", "gauge", watts)]
        out = []
        for name, kind, val in m:
            out.append(f"# TYPE mock_llm:{name} {kind}")
            out.append(f'mock_llm:{name}{{profile="{self.name}"}} {val}')
        return "\n".join(out) + "\n"


# ---- minimal HTTP/1.1 server (keep-alive, Content-Length bodies, chunked SSE) ----
REASON = {200: "OK", 400: "Bad Request", 404: "Not Found", 503: "Service Unavailable"}


async def send(writer, code, body, ctype="application/json"):
    data = body.encode() if isinstance(body, str) else body
    head = (f"HTTP/1.1 {code} {REASON.get(code, 'OK')}\r\nContent-Type: {ctype}\r\n"
            f"Content-Length: {len(data)}\r\nConnection: keep-alive\r\n\r\n")
    writer.write(head.encode() + data)
    await writer.drain()


async def handle(engine, reader, writer):
    try:
        while True:
            line = await reader.readline()
            if not line:
                break
            parts = line.decode("latin-1").split()
            if len(parts) < 2:
                break
            method, path = parts[0], parts[1].split("?")[0]
            headers = {}
            while True:
                h = await reader.readline()
                if h in (b"\r\n", b"\n", b""):
                    break
                k, _, v = h.decode("latin-1").partition(":")
                headers[k.strip().lower()] = v.strip()
            n = int(headers.get("content-length", "0") or 0)
            body = await reader.readexactly(n) if n else b""
            if method == "GET" and path == "/health":
                await send(writer, 200, "ok", "text/plain")
            elif method == "GET" and path == "/metrics":
                await send(writer, 200, engine.metrics(), "text/plain; version=0.0.4")
            elif method == "GET" and path == "/v1/models":
                await send(writer, 200, json.dumps({"object": "list", "data": [{"id": f"mock-8b-{engine.name}", "object": "model"}]}))
            elif method == "POST" and path == "/v1/completions":
                await completions(engine, writer, body, headers)
            else:
                await send(writer, 404, json.dumps({"error": {"message": f"no route {method} {path}"}}))
            if headers.get("connection", "").lower() == "close":
                break
    except (asyncio.IncompleteReadError, ConnectionError):
        pass
    finally:
        try:
            writer.close()
        except Exception:
            pass


async def completions(engine, writer, body, headers):
    try:
        req = json.loads(body or b"{}")
        prompt = req.get("prompt", "")
        if isinstance(prompt, list):
            prompt = " ".join(map(str, prompt))
        words = str(prompt).split()
        max_tokens = int(req.get("max_tokens", 16))
        stream = bool(req.get("stream", False))
    except (ValueError, TypeError) as e:
        await send(writer, 400, json.dumps({"error": {"message": f"bad request: {e}"}}))
        return
    lockstep = None
    if "x-loadtest-level" in headers:
        try:
            lockstep = {"level": headers["x-loadtest-level"], "seq": int(headers["x-loadtest-seq"]),
                        "total": int(headers["x-loadtest-total"]), "conc": int(headers["x-loadtest-concurrency"])}
        except (KeyError, ValueError):
            lockstep = None
    s = engine.submit(words, max_tokens, stream, lockstep)
    model = f"mock-8b-{engine.name}"
    if stream:
        writer.write(b"HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\n"
                     b"Transfer-Encoding: chunked\r\nConnection: keep-alive\r\n\r\n")

        def chunk(obj):
            data = ("data: " + (obj if isinstance(obj, str) else json.dumps(obj)) + "\n\n").encode()
            writer.write(f"{len(data):X}\r\n".encode() + data + b"\r\n")
        while True:
            tok = await s.stream_q.get()
            if tok is None:
                break
            chunk({"id": f"cmpl-{s.rid}", "object": "text_completion", "model": model,
                   "choices": [{"index": 0, "text": " " + tok, "finish_reason": None}]})
            await writer.drain()
        err = await s.fut
        final = {"id": f"cmpl-{s.rid}", "object": "text_completion", "model": model,
                 "choices": [{"index": 0, "text": "", "finish_reason": "length" if not err else "error"}],
                 "usage": {"prompt_tokens": s.prompt_len, "completion_tokens": s.generated,
                           "total_tokens": s.prompt_len + s.generated,
                           "prompt_tokens_details": {"cached_tokens": s.cached}},
                 "x_sim": engine.timing(s)}
        if err:
            final["error"] = {"message": err}
        chunk(final); chunk("[DONE]")
        writer.write(b"0\r\n\r\n"); await writer.drain()
        return
    err = await s.fut
    if err:
        await send(writer, 503, json.dumps({"error": {"message": err, "type": "overloaded"},
                                            "x_sim": engine.timing(s)}))
        return
    text = " ".join(WORDS[(s.rid + i) % len(WORDS)] for i in range(s.generated))
    await send(writer, 200, json.dumps({
        "id": f"cmpl-{s.rid}", "object": "text_completion", "model": model,
        "choices": [{"index": 0, "text": text, "finish_reason": "length"}],
        "usage": {"prompt_tokens": s.prompt_len, "completion_tokens": s.generated,
                  "total_tokens": s.prompt_len + s.generated,
                  "prompt_tokens_details": {"cached_tokens": s.cached}},
        "x_sim": engine.timing(s)}))


async def serve(a):
    engine = Engine(a.profile, a.speed, not a.no_prefix_cache, a.queue_timeout_ms)
    server = await asyncio.start_server(lambda r, w: handle(engine, r, w), a.host, a.port, backlog=512)
    loop_task = asyncio.ensure_future(engine.run())
    p = PROFILES[a.profile]
    print(f"mock LLM server · profile={a.profile} ({p['desc']}) · speed={a.speed}x · "
          f"prefix cache {'on' if not a.no_prefix_cache else 'off'}", flush=True)
    print(f"  max_seqs={p['max_seqs']}  kv_capacity={p['kv_capacity']:,} tokens  "
          f"step={p['step_base_ms']} ms + {p['per_seq_ms']} ms/seq", flush=True)
    print(f"  listening on http://{a.host}:{a.port}  (POST /v1/completions, GET /metrics)  Ctrl+C to stop", flush=True)
    stop = asyncio.Event()
    for sig in (getattr(signal, "SIGINT", None), getattr(signal, "SIGTERM", None)):
        if sig is None:
            continue
        try:
            asyncio.get_running_loop().add_signal_handler(sig, stop.set)
        except (NotImplementedError, RuntimeError):
            pass                                    # Windows: Ctrl+C raises KeyboardInterrupt instead
    try:
        await stop.wait()
    finally:
        server.close(); loop_task.cancel()
        try:
            await server.wait_closed()
        except Exception:
            pass
        print(f"server stopped · served {engine.c['success_total']} requests, "
              f"{engine.c['errors_total']} errors", flush=True)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--profile", default="baseline", choices=PROFILES)
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--speed", type=float, default=20.0, help="simulated time runs this many times faster than real time")
    ap.add_argument("--no-prefix-cache", action="store_true", help="disable prefix caching on the server")
    ap.add_argument("--queue-timeout-ms", type=float, default=5000, help="shed requests that wait longer than this (model ms)")
    ap.add_argument("--list-profiles", action="store_true")
    a = ap.parse_args()
    if a.list_profiles:
        for k, v in PROFILES.items():
            print(f"{k:10s} {v['desc']}: step {v['step_base_ms']} ms + {v['per_seq_ms']} ms/seq, "
                  f"prefill {v['prefill_ms_per_token']} ms/token, max_seqs {v['max_seqs']}, KV {v['kv_capacity']:,} tokens")
        return
    try:
        asyncio.run(serve(a))
    except KeyboardInterrupt:
        print("server stopped (Ctrl+C)", flush=True)


if __name__ == "__main__":
    main()
