# Capstone · Optimization report

> **How to use this file.** Part A is the template. Part B is a fully worked example built from this lab's real output (`python3 run_capstone.py`). Copy Part A into your portfolio repo and fill it with **your** numbers. If your numbers come from the simulator, say so ("in a simulated serving environment"). If they come from a real GPU, say which GPU, model and engine. Never present simulated results as production results; interviewers will ask, and the honest answer is a strong answer.

---

## Part A · Template

### 1. Context (3 lines)
- **Service:** what it does, who uses it, traffic mix (share of chat / long-context / code, typical prompt and output lengths).
- **Setup:** model, precision, GPU(s), serving engine, key settings (max batch, KV cache budget, prefix caching).
- **Targets (SLOs):** success rate ___ %, p95 TTFT < ___ ms, over ___ days.

### 2. Baseline (from the load test)
| Measure | Value | Source |
|---|---:|---|
| Breaking point (max concurrency meeting p95 TTFT target) | | `reports/loadtest_<baseline>.md` |
| Output tokens/s per GPU at the breaking point | | same |
| p95 TTFT / error rate at the breaking point | | same |
| Breaking point with the cache busted | | `loadtest_<baseline>-nocache.md` |
| What a naive one-prompt test would have claimed | | `loadtest_naive.md` |
| Error budget left this month | | `reports/slo_report.md` |

### 3. Bottleneck (what limits you, and the evidence)
One paragraph. Name ONE limit (compute, memory bandwidth, KV-cache capacity, queueing, prefill interference, network) and the numbers that prove it.

### 4. The one change
What you changed, why you expected it to help (tie it to the bottleneck), and what you deliberately did **not** change.

### 5. Result (same test, same mix, same seed)
| Measure | Before | After | Change |
|---|---:|---:|---:|
| Breaking point | | | |
| Output tokens/s per GPU at the breaking point | | | |
| p95 TTFT at the old breaking point | | | |
| Quality (eval accuracy) | | | |
| Energy per 1M output tokens | | | |

### 6. Risks and rollback plan
- Risks you checked, and the guardrail that catches each one.
- Rollout steps (shadow → canary % → full), what is checked at each step, who or what decides.
- Rollback: how fast, by what mechanism (feature flag, traffic shift), and the trigger.

### 7. What next
The next bottleneck, and the next one change you would test.

### 8. Three resume bullets
Verb + what + how much + how measured. One idea per bullet.

### 9. The two-minute story (STAR)
Situation (2 sentences) · Task (1) · Action (4–5, including how you shipped it safely) · Result (numbers) · what you learned (1).

---

## Part B · Worked example (this lab's real numbers, simulated environment)

### 1. Context
- **Service:** an LLM endpoint serving 55% chat, 30% retrieval-augmented (RAG) questions with long documents, 15% code generation. Mean prompt 2,086 tokens, mean output 311 tokens (`data/traffic_mix.json`). Every class repeats a shared system prompt.
- **Setup:** an 8B-class model on one GPU in a simulated continuous-batching server (`mock_server.py --profile baseline`): FP16 weights and KV cache, max 64 running sequences, 60,000-token KV-cache budget, prefix caching on.
- **Targets:** 99.5% of requests succeed; p95 TTFT under 1 s (95% of requests get a first token within 1 s); 30-day window.

### 2. Baseline
| Measure | Value |
|---|---:|
| Breaking point | **12 concurrent users** |
| Output tokens/s per GPU there | **830** |
| p95 TTFT / error rate there | 827 ms / 0.0% |
| Breaking point with the cache busted | 8 users (592 tok/s) |
| What a one-prompt test claimed | 64 users (3,076 tok/s): 3.7x too optimistic |
| Error budget left this month | availability 42.7%, latency 45.9% → **SHIP** |

### 3. Bottleneck
Up to 12 users, p95 TTFT stays under 830 ms. From 12 to 24 users it bends up (827 → 1,488 ms) while median time per output token rises from 13.9 to 18.1 ms: long RAG prompts are being prefilled in the same steps as everyone else's decode, so new requests wait behind them. At 32 users the median request waits 1.2 s for its first token: about 32 sequences of ~2,400 tokens each need more KV cache than the 60,000-token budget, so requests queue for memory. Decode is memory-bound, so the limit is **bytes**: bytes of weights read per step, and bytes of KV cache per token.

### 4. The one change
FP8 weights and FP8 KV cache (`--profile optimized`). Half the bytes per weight should make every decode step faster, and half the bytes per KV token roughly doubles how many sequences fit. Not changed: the model, the traffic mix, the seed, the batch limits in the engine config, the SLO.

### 5. Result
| Measure | Before | After | Change |
|---|---:|---:|---:|
| Breaking point | 12 users | 16 users | +33% |
| Output tokens/s per GPU at the breaking point | 830 | 1,408 | **+70%** |
| p95 TTFT at 12 users | 827 ms | 580 ms | -30% |
| Breaking point, cache busted | 8 users | 12 users | +50% |
| Eval accuracy (300 items) | 84.0% | 83.7% | -0.3 pt |
| Energy per 1M output tokens (same 655 W board power assumed) | 219 Wh | 129 Wh | -41% |

Canary analysis at 12 users (`reports/canary_fp8.md`): every guardrail passed → **PROMOTE**.
Rejected alternative: INT4 weights were 36% faster at 12 users (1,125 vs 830 tok/s) but lost 4.7 points of accuracy, 12 points on code → **ROLL BACK** (`reports/canary_int4.md`).

### 6. Risks and rollback plan
- **Quality on rare prompts.** The eval has 300 items; FP8 flipped 2 answers to wrong and 1 to right. Guardrails: overall drop ≤ 1 pt and any category ≤ 5 pts, re-checked at every rollout step.
- **Latency regression under real traffic.** Guardrail: p95 TTFT ≤ 1 s and no more than 10% worse than baseline; error rate no more than 0.5 pts higher.
- **Rollout:** shadow traffic first (copy requests, compare outputs, users see nothing), then 1% → 5% → 25% → 50% → 100%, holding each step long enough to collect a meaningful sample of requests.
- **Rollback:** a feature flag shifts traffic back to the FP16 deployment, which stays warm for 24 hours. Trigger: any guardrail fails, or the error budget starts burning faster than 6x over 6 hours.
- **Budget:** 42.7% of the availability budget is left, so this change is allowed to spend some of it. With a 99.9% target the same month would be FREEZE, and this would wait.

### 7. What next
- Plan capacity on the cache-busted number (12 users after FP8), because a new system prompt makes the cache cold.
- Test a 500 W power cap at the new breaking point. The illustrative curve suggests -24% power for -4% speed; verify with `nvidia-smi -pl` on real hardware.
- The next bottleneck is prefill interference at 24 users: test a smaller prefill chunk (token budget per step) as the next single change.

### 8. Three resume bullets
- Built a production-style load test for an LLM endpoint (real prompt and output length mix, concurrency ramp, cache on and off) and found its breaking point at 12 concurrent users under a 1 s p95 TTFT target, 3.7x below what a single-prompt test claimed.
- Raised output tokens/s per GPU at the latency target by 70% (830 → 1,408) by moving to FP8 weights and KV cache, shipped through a canary with latency, error, quality (-0.3 pt) and error-budget guardrails.
- Blocked an INT4 rollout that was 36% faster but 4.7 points less accurate (12 points on code) by adding per-category quality checks to the canary rules.

_(Simulated environment: say so on your resume, or replace these with numbers from a real GPU.)_

### 9. The two-minute story
**Situation.** We served an 8B model for chat, RAG and code from one GPU. Our load test replayed one short prompt and said we could handle 64 concurrent users. We kept missing our latency target well before that.

**Task.** Find the real capacity, and raise it without hurting reliability or answer quality.

**Action.** First I rebuilt the load test with our real mix of prompt and output lengths and ramped concurrency step by step. The real breaking point for p95 time to first token under one second was 12 users, not 64, and only 8 when the prefix cache was cold. The curve showed why: long RAG prompts were prefilled alongside everyone's decode, and past about 30 users the KV cache was full and requests queued. Decode is memory-bound, so I changed one thing: FP8 weights and FP8 KV cache. Before shipping, I checked the error budget (43% left, so we could spend some on change) and ran a canary analysis with written guardrails: p95 TTFT, error rate, capacity, and a 300-item quality eval, overall and per category.

**Result.** At the same latency target, throughput per GPU went from 830 to 1,408 tokens per second, plus 70%, and capacity from 12 to 16 users, for a 0.3-point accuracy cost. The same guardrails rejected an INT4 build that was faster but lost 12 points on code.

**What I learned.** Capacity is the highest load that still meets the SLO, measured with real traffic, and an optimization only counts once it passes the same guardrails as any other change.
