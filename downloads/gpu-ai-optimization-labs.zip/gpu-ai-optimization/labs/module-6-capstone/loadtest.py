#!/usr/bin/env python3
"""
Module 6 · Stage 2 — Load test like production.

Most LLM load tests replay one short prompt. That hides the two things that
drive cost and latency: long prompts (prefill, TTFT) and long answers (decode
time, which is most of the GPU time you pay for). This tool:

  1. samples requests from a realistic traffic mix (data/traffic_mix.json),
     prompt AND output lengths, seeded so every run sends the same requests;
  2. ramps concurrency step by step (1, 2, 4, 8, 12, 16, 24, 32, ...): N users,
     each sending its next request as soon as the last one finishes;
  3. reports, per level: p50/p95 TTFT, p95 end-to-end latency, output
     tokens/s (per GPU), and error rate;
  4. finds the KNEE: the highest concurrency that still meets your p95 TTFT
     target with an error rate under --max-error-rate.

Works against the lab's mock_server.py and against a real OpenAI-compatible
server such as vLLM (POST /v1/completions). Timing:
  * mock server: it returns exact timings in model time (field "x_sim");
  * real server, --stream: TTFT = time to the first streamed token;
  * real server, no --stream: TTFT is not observable, so the report uses
    end-to-end latency as an upper bound and says so ("ttft_source").

Cache hits hide real capacity: --cache-bust puts a unique word at the start of
every prompt so prefix caching cannot help. Run with and without it.

Usage:
  python3 loadtest.py --url http://127.0.0.1:8000 --label baseline
  python3 loadtest.py --url http://127.0.0.1:8000 --label baseline-nocache --cache-bust
  python3 loadtest.py --url http://127.0.0.1:8000 --label naive --mix data/traffic_naive.json
  python3 loadtest.py --url http://localhost:8000 --label vllm --stream --model <name>   # real vLLM

Writes reports/loadtest_<label>.md and reports/loadtest_<label>.csv.
Only the Python standard library is used.
"""
import argparse, csv, http.client, json, math, os, random, statistics, sys, threading, time
from urllib.parse import urlparse

HERE = os.path.dirname(os.path.abspath(__file__))
VOCAB = ("the a of and to in is that for it with as on was be at by this an are from or have not "
         "but what all were when we there can your which their said if do will each about how up out "
         "them then she many some so these would other into has more her two like him see time could "
         "no make than first been its who now people my made over did down only way find use may water "
         "long little very after words called just where most know get through back much before go good "
         "new write our used me man too any day same right look think also around another came come work "
         "three word must because does part even place well such here take why help put different away "
         "again off went old number great tell men say small every found still between name should home "
         "big give air line set own under read last never us left end along while might next sound below "
         "saw something thought both few those always show large often together asked house world going "
         "want school important until form food keep children feet land side without boy once animal life "
         "enough took sometimes four head above kind began almost live page got earth need far hand high").split()
CSV_FIELDS = ["label", "concurrency", "requests", "ok", "errors", "error_rate", "p50_ttft_ms", "p95_ttft_ms",
              "p95_e2e_ms", "p50_tpot_ms", "output_tok_s", "output_tok_s_per_gpu", "req_s", "mean_prompt_tokens",
              "mean_output_tokens", "cache_hit_rate", "meets_slo", "ttft_source"]


def pct(xs, q):
    """nearest-rank percentile (what most dashboards show)"""
    if not xs:
        return float("nan")
    s = sorted(xs)
    return s[min(len(s) - 1, max(0, math.ceil(q / 100 * len(s)) - 1))]


def lognormal(rng, spec):
    if spec["median"] == spec["p90"]:
        v = spec["median"]
    else:
        sigma = math.log(spec["p90"] / spec["median"]) / 1.2816   # z(0.90)
        v = math.exp(rng.gauss(math.log(spec["median"]), sigma))
    return int(min(spec["max"], max(spec["min"], round(v))))


class Mix:
    def __init__(self, path):
        self.cfg = json.load(open(path))
        self.classes = self.cfg["classes"]
        self.weights = [c["weight"] for c in self.classes]
        self.prefix = {}
        self.nonce = random.Random("nonce")   # separate RNG: busting the cache must not change which requests are sent
        for c in self.classes:
            r = random.Random("prefix-" + c["name"])
            self.prefix[c["name"]] = [r.choice(VOCAB) for _ in range(c.get("shared_prefix_tokens", 0))]

    def sample(self, rng, words_rng, cache_bust):
        """rng picks the class and lengths (the SHAPE); words_rng picks the unique words (the CONTENT)"""
        c = rng.choices(self.classes, self.weights)[0]
        n_in = lognormal(rng, c["prompt_tokens"]); n_out = lognormal(rng, c["output_tokens"])
        if c.get("identical_prompt"):
            body = [VOCAB[i % len(VOCAB)] for i in range(n_in)]
        else:
            body = [words_rng.choice(VOCAB) for _ in range(n_in)]
        words = self.prefix[c["name"]] + body
        if cache_bust:   # a unique first word breaks every prefix-cache hit
            words = [f"nonce{self.nonce.randrange(10**9)}"] + words
        return {"cls": c["name"], "prompt": " ".join(words), "max_tokens": n_out}


class Client:
    """one keep-alive connection per simulated user"""

    def __init__(self, url, timeout):
        u = urlparse(url)
        self.host, self.port = u.hostname, u.port or (443 if u.scheme == "https" else 80)
        self.https = u.scheme == "https"; self.base = u.path.rstrip("/"); self.timeout = timeout
        self.conn = None

    def _conn(self):
        if self.conn is None:
            cls = http.client.HTTPSConnection if self.https else http.client.HTTPConnection
            self.conn = cls(self.host, self.port, timeout=self.timeout)
        return self.conn

    def close(self):
        if self.conn is not None:
            self.conn.close(); self.conn = None

    def get(self, path):
        c = self._conn(); c.request("GET", self.base + path); r = c.getresponse()
        return r.status, r.read().decode()

    def complete(self, payload, stream, headers=None):
        """returns a result dict; never raises"""
        t0 = time.perf_counter(); first = None
        res = {"ok": False, "status": 0, "ttft_ms": None, "e2e_ms": None, "prompt_tokens": 0,
               "completion_tokens": 0, "cached": 0, "start": None, "end": None, "src": "wall"}
        try:
            c = self._conn()
            body = json.dumps(dict(payload, stream=stream, **({"stream_options": {"include_usage": True}} if stream else {})))
            c.request("POST", self.base + "/v1/completions", body=body,
                      headers=dict({"Content-Type": "application/json"}, **(headers or {})))
            r = c.getresponse(); res["status"] = r.status
            if not stream:
                data = json.loads(r.read() or b"{}")
                final = data
            else:
                final, chunks = {}, 0
                while True:
                    line = r.readline()
                    if not line:
                        break
                    line = line.strip()
                    if not line.startswith(b"data:"):
                        continue
                    msg = line[5:].strip()
                    if msg == b"[DONE]":
                        r.read(); break
                    obj = json.loads(msg)
                    ch = obj.get("choices") or []
                    if ch and ch[0].get("text") and first is None:
                        first = time.perf_counter()
                    if ch and ch[0].get("text"):
                        chunks += 1
                    if obj.get("usage"):
                        final = obj
                    if obj.get("error"):
                        final = obj; res["status"] = 503
                if not final.get("usage"):
                    final["usage"] = {"completion_tokens": chunks}
            t1 = time.perf_counter()
            u = final.get("usage") or {}
            res["prompt_tokens"] = u.get("prompt_tokens", 0) or 0
            res["completion_tokens"] = u.get("completion_tokens", 0) or 0
            res["cached"] = ((u.get("prompt_tokens_details") or {}).get("cached_tokens") or 0)
            res["ok"] = res["status"] == 200 and not final.get("error")
            sim = final.get("x_sim")
            if sim:   # the mock server reports exact timings in model time
                res.update(ttft_ms=sim["ttft_ms"], e2e_ms=sim["total_ms"], start=sim["arrival_ms"],
                           end=sim["finish_ms"], src="server")
            else:
                res["e2e_ms"] = (t1 - t0) * 1000; res["start"] = t0 * 1000; res["end"] = t1 * 1000
                if first is not None:
                    res["ttft_ms"] = (first - t0) * 1000; res["src"] = "stream"
                else:
                    res["ttft_ms"] = res["e2e_ms"]; res["src"] = "e2e (non-streaming upper bound)"
        except Exception as e:  # connection refused, timeout, bad JSON...
            res["error"] = f"{type(e).__name__}: {e}"
            res["end"] = time.perf_counter() * 1000; res["start"] = t0 * 1000
            self.close()
        return res


def run_level(url, mix, conc, n_requests, seed, timeout, stream, model, cache_bust):
    # Same SHAPE at every level and every run: classes and lengths come from one fixed seeded
    # stream, so levels differ only in concurrency. Fresh WORDS per level and per run: replaying
    # identical prompts would warm the server's prefix cache and make later runs look faster.
    # (The shared prefixes still repeat, exactly as system prompts do in production.)
    rng = random.Random(seed)
    run_salt = os.urandom(8).hex()   # new words on every run, so a re-run cannot hit a warm cache
    words_rng = random.Random(f"words-{run_salt}-{conc}")
    mix.nonce = random.Random(f"nonce-{run_salt}-{conc}")
    specs = [mix.sample(rng, words_rng, cache_bust) for _ in range(n_requests)]
    results, lock, idx = [], threading.Lock(), [0]
    level_id = f"{os.getpid()}-{time.time():.6f}-{conc}"

    def user():
        cl = Client(url, timeout)
        while True:
            with lock:
                if idx[0] >= len(specs):
                    break
                sp = specs[idx[0]]; seq = idx[0]; idx[0] += 1
            payload = {"prompt": sp["prompt"], "max_tokens": sp["max_tokens"], "temperature": 0,
                       "ignore_eos": True}   # vLLM extension: generate exactly max_tokens, like the mix says
            if model:
                payload["model"] = model
            # X-Loadtest-* lets the lab's simulator replay arrivals in a fixed order (exactly
            # reproducible numbers). Real servers ignore unknown headers.
            hdr = {"X-Loadtest-Level": level_id, "X-Loadtest-Seq": str(seq),
                   "X-Loadtest-Total": str(len(specs)), "X-Loadtest-Concurrency": str(min(conc, len(specs)))}
            r = cl.complete(payload, stream, hdr); r["cls"] = sp["cls"]
            with lock:
                results.append(r)
        cl.close()

    ts = [threading.Thread(target=user, daemon=True) for _ in range(conc)]
    for t in ts:
        t.start()
    for t in ts:
        t.join()
    return results


def summarize(label, conc, rs, slo_ms, max_err, gpus):
    ok = [r for r in rs if r["ok"]]
    errs = len(rs) - len(ok)
    span_ms = (max(r["end"] for r in rs) - min(r["start"] for r in rs)) if rs else 0
    out_tok = sum(r["completion_tokens"] for r in ok)
    # Throughput over the STEADY window: from the first request until the last one is sent.
    # Until then every user is busy; after it the level drains and fewer users remain.
    # Tokens of each request are spread evenly over its lifetime and clipped to the window.
    t0 = min(r["start"] for r in rs) if rs else 0
    t1 = max(r["start"] for r in rs) if rs else 0
    if t1 - t0 > 0.2 * span_ms:
        win_tok = 0.0
        for r in ok:
            life = max(1e-9, r["end"] - r["start"])
            win_tok += r["completion_tokens"] * max(0.0, min(r["end"], t1) - max(r["start"], t0)) / life
        tps = win_tok / ((t1 - t0) / 1000)
    else:
        tps = out_tok / (span_ms / 1000) if span_ms > 0 else 0.0
    tpots = [(r["e2e_ms"] - r["ttft_ms"]) / (r["completion_tokens"] - 1) for r in ok
             if r["completion_tokens"] > 1 and r["ttft_ms"] is not None]
    ttfts = [r["ttft_ms"] for r in ok if r["ttft_ms"] is not None]
    ptoks = sum(r["prompt_tokens"] for r in ok)
    row = {"label": label, "concurrency": conc, "requests": len(rs), "ok": len(ok), "errors": errs,
           "error_rate": round(errs / len(rs), 4) if rs else 0.0,
           "p50_ttft_ms": round(pct(ttfts, 50), 1), "p95_ttft_ms": round(pct(ttfts, 95), 1),
           "p95_e2e_ms": round(pct([r["e2e_ms"] for r in ok], 95), 1),
           "p50_tpot_ms": round(statistics.median(tpots), 2) if tpots else float("nan"),
           "output_tok_s": round(tps, 1), "output_tok_s_per_gpu": round(tps / gpus, 1),
           "req_s": round(len(ok) / (span_ms / 1000), 2) if span_ms > 0 else 0.0,
           "mean_prompt_tokens": round(ptoks / len(ok)) if ok else 0,
           "mean_output_tokens": round(out_tok / len(ok)) if ok else 0,
           "cache_hit_rate": round(sum(r["cached"] for r in ok) / ptoks, 3) if ptoks else 0.0,
           "ttft_source": ok[0]["src"] if ok else (rs[0].get("error", "n/a") if rs else "n/a")}
    p95 = row["p95_ttft_ms"]
    row["meets_slo"] = bool(ok) and p95 == p95 and p95 <= slo_ms and row["error_rate"] <= max_err
    return row


def find_knee(rows):
    """highest concurrency that meets the SLO, counting up from the lowest level until the first miss"""
    knee = None
    for r in rows:
        if r["meets_slo"]:
            knee = r
        else:
            break
    return knee


def write_reports(rows, knee, a, mix_name, outdir):
    os.makedirs(outdir, exist_ok=True)
    base = os.path.join(outdir, f"loadtest_{a.label}")
    with open(base + ".csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=CSV_FIELDS); w.writeheader(); w.writerows(rows)
    md = [f"# Load test · {a.label}", "",
          f"Target: `{a.url}` · mix: `{mix_name}` · seed {a.seed} · cache-bust: {'yes' if a.cache_bust else 'no'} · "
          f"SLO: p95 TTFT <= {a.slo_ttft_ms:.0f} ms and error rate <= {a.max_error_rate:.1%} · GPUs: {a.gpus}", "",
          "| Concurrency | Requests | p50 TTFT | p95 TTFT | p95 end-to-end | p50 TPOT | Output tok/s/GPU | Error rate | Cache hits | Meets SLO |",
          "|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|"]
    for r in rows:
        md.append(f"| {r['concurrency']} | {r['requests']} | {r['p50_ttft_ms']:.0f} ms | {r['p95_ttft_ms']:.0f} ms | "
                  f"{r['p95_e2e_ms']/1000:.1f} s | {r['p50_tpot_ms']:.1f} ms | {r['output_tok_s_per_gpu']:,.0f} | "
                  f"{r['error_rate']:.1%} | {r['cache_hit_rate']:.0%} | {'yes' if r['meets_slo'] else '**no**'} |")
    md.append("")
    if knee:
        md += [f"**Breaking point:** max concurrency that meets the SLO = **{knee['concurrency']}** "
               f"(p95 TTFT {knee['p95_ttft_ms']:.0f} ms, {knee['output_tok_s_per_gpu']:,.0f} output tok/s per GPU, "
               f"error rate {knee['error_rate']:.1%})."]
    else:
        md += ["**Breaking point:** not even the lowest level met the SLO."]
    md += ["", f"Timing source: {rows[0]['ttft_source'] if rows else 'n/a'}. "
           "Percentiles are nearest-rank over successful requests. Output tok/s is measured over the steady "
           "window of each level (all users busy), not the drain at the end."]
    with open(base + ".md", "w") as f:
        f.write("\n".join(md) + "\n")
    return base + ".md", base + ".csv"


def build_parser():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--url", default="http://127.0.0.1:8000")
    ap.add_argument("--label", default="run", help="name used in report filenames")
    ap.add_argument("--mix", default=os.path.join(HERE, "data", "traffic_mix.json"))
    ap.add_argument("--levels", default="1,2,4,8,12,16,24,32,48,64,96,128", help="concurrency levels to ramp through")
    ap.add_argument("--per-user", type=int, default=3, help="requests per user at each level")
    ap.add_argument("--min-requests", type=int, default=60, help="at least this many requests per level")
    ap.add_argument("--slo-ttft-ms", type=float, default=1000.0)
    ap.add_argument("--max-error-rate", type=float, default=0.01)
    ap.add_argument("--gpus", type=int, default=1, help="GPUs behind the endpoint (for tok/s per GPU)")
    ap.add_argument("--cache-bust", action="store_true", help="make every prompt unique so prefix caching cannot help")
    ap.add_argument("--stream", action="store_true", help="use streaming to measure real TTFT (real servers)")
    ap.add_argument("--model", default=None, help="model name for a real server (default: first from /v1/models)")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--timeout", type=float, default=300.0, help="per-request timeout, seconds")
    ap.add_argument("--keep-going", action="store_true", help="run every level even after the SLO is badly broken")
    ap.add_argument("--outdir", default=os.path.join(HERE, "reports"))
    return ap


def main(argv=None):
    a = build_parser().parse_args(argv)
    mix = Mix(a.mix)
    levels = [int(x) for x in a.levels.split(",") if x.strip()]
    probe = Client(a.url, 10)
    try:
        st, body = probe.get("/v1/models")
        if a.model is None and st == 200:
            data = json.loads(body).get("data") or []
            if data and not data[0]["id"].startswith("mock-"):
                a.model = data[0]["id"]
    except Exception as e:
        print(f"cannot reach {a.url}: {e}\nStart the server first, e.g.  python3 mock_server.py --profile baseline", file=sys.stderr)
        return None
    finally:
        probe.close()
    print(f"\nLOAD TEST  {a.label}  ->  {a.url}   mix={mix.cfg.get('name')}  cache-bust={'yes' if a.cache_bust else 'no'}"
          f"   SLO: p95 TTFT <= {a.slo_ttft_ms:.0f} ms, errors <= {a.max_error_rate:.0%}")
    print(f"  {'users':>5s} {'reqs':>5s} {'p50 TTFT':>9s} {'p95 TTFT':>9s} {'p95 e2e':>8s} {'tok/s/GPU':>10s} "
          f"{'errors':>7s} {'cache':>6s}  SLO")
    rows = []
    for conc in levels:
        n = max(a.min_requests, conc * a.per_user)
        rs = run_level(a.url, mix, conc, n, a.seed, a.timeout, a.stream, a.model, a.cache_bust)
        row = summarize(a.label, conc, rs, a.slo_ttft_ms, a.max_error_rate, a.gpus); rows.append(row)
        print(f"  {conc:5d} {row['requests']:5d} {row['p50_ttft_ms']:7.0f}ms {row['p95_ttft_ms']:7.0f}ms "
              f"{row['p95_e2e_ms']/1000:7.1f}s {row['output_tok_s_per_gpu']:10,.0f} {row['error_rate']:7.1%} "
              f"{row['cache_hit_rate']:6.0%}  {'ok' if row['meets_slo'] else 'BREAKS'}", flush=True)
        if row["ok"] == 0 and "Error" in str(row["ttft_source"]):
            print(f"  every request failed: {row['ttft_source']}", file=sys.stderr); break
        if not a.keep_going and (row["p95_ttft_ms"] > 4 * a.slo_ttft_ms or row["error_rate"] > 0.25):
            print("  (stopping the ramp: far past the breaking point; use --keep-going to continue)")
            break
    knee = find_knee(rows)
    md, csvp = write_reports(rows, knee, a, mix.cfg.get("name"), a.outdir)
    if knee:
        print(f"\n  BREAKING POINT {knee['concurrency']} users (p95 TTFT <= {a.slo_ttft_ms:.0f} ms): "
              f"{knee['output_tok_s_per_gpu']:,.0f} output tok/s per GPU, errors {knee['error_rate']:.1%}")
    else:
        print("\n  BREAKING POINT none: even the lowest level misses the SLO")
    print(f"  timing source: {rows[0]['ttft_source'] if rows else 'n/a'}")
    print(f"  wrote {os.path.relpath(md)} and {os.path.relpath(csvp)}\n")
    return {"rows": rows, "knee": knee, "md": md, "csv": csvp}


if __name__ == "__main__":
    sys.exit(0 if main() is not None else 1)
