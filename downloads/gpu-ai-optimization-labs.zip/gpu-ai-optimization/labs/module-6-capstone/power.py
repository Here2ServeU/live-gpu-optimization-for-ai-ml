#!/usr/bin/env python3
"""
Module 6 · Stage 5 — Performance per watt.

Data centers are increasingly limited by power (megawatts), not only by GPUs or
money. The efficiency number for that world is TOKENS PER JOULE:

  tokens per joule  = tokens per second / watts          (1 W = 1 J per second)
  energy per 1M tok = 1,000,000 / tokens_per_joule  J    (/ 3,600 for watt-hours)

This script does three things:

  1. Tokens per joule for each build, from the load test's tokens/s at its
     breaking point and a board power figure (--watts; default: the average
     draw at the default cap in data/power_curve.json). Same power, more tokens
     = more tokens per joule: quantization saves energy, not just money.
  2. A power-cap sweep for the optimized build, using data/power_curve.json:
     an ILLUSTRATIVE curve of throughput vs. power cap. A modest cap often cuts
     power a lot for a small loss of speed, because decode is memory-bound.
     It recommends the lowest cap that keeps at least --min-throughput.
  3. --live N: if this machine has nvidia-smi, samples power draw, SM clock,
     temperature and throttle reasons once per second for N seconds while you
     run a load test, so you can replace the illustrative curve with your own.

Usage:
  python3 power.py                    # baseline and optimized load tests from reports/
  python3 power.py --loadtest reports/loadtest_baseline.csv reports/loadtest_optimized.csv
  python3 power.py --loadtest reports/loadtest_optimized.csv --min-throughput 0.90
  python3 power.py --live 60          # with an NVIDIA GPU, during a load test

Writes reports/power.md. Only the Python standard library is used.
"""
import argparse, csv, json, os, shutil, subprocess, time

HERE = os.path.dirname(os.path.abspath(__file__))


def knee_row(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    k = None
    for r in rows:
        if r["meets_slo"] == "True":
            k = r
        else:
            break
    return k or rows[0]


def live(seconds):
    if not shutil.which("nvidia-smi"):
        print("\n  --live: nvidia-smi not found on this machine. Run this on a GPU host during a load test.\n")
        return
    q = "power.draw,power.limit,clocks.sm,temperature.gpu,clocks_event_reasons.active"
    print(f"\n  sampling GPU 0 for {seconds} s ({q})")
    samples = []
    for _ in range(seconds):
        res = subprocess.run(["nvidia-smi", "-i", "0", f"--query-gpu={q}", "--format=csv,noheader,nounits"],
                             capture_output=True, text=True)
        if res.returncode != 0:   # older drivers: clocks_throttle_reasons
            res = subprocess.run(["nvidia-smi", "-i", "0", "--query-gpu=" + q.replace("clocks_event_reasons", "clocks_throttle_reasons"),
                                  "--format=csv,noheader,nounits"], capture_output=True, text=True)
        try:
            pw, pl, sm, t, rs = [x.strip() for x in res.stdout.strip().split(",")]
            samples.append((float(pw), float(pl), float(sm), float(t), rs))
        except ValueError:
            pass
        time.sleep(1)
    if samples:
        n = len(samples)
        print(f"  avg power {sum(s[0] for s in samples)/n:.0f} W of {samples[-1][1]:.0f} W limit · "
              f"avg SM clock {sum(s[2] for s in samples)/n:.0f} MHz · max temp {max(s[3] for s in samples):.0f} C · "
              f"throttle reasons seen: {sorted({s[4] for s in samples})}")
        print("  tokens per joule = (tokens/s from your load test) / avg power. "
              "To sweep caps: sudo nvidia-smi -i 0 -pl <watts>, re-run, record.\n")


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--loadtest", nargs="*", help="loadtest CSVs; the last one is swept over power caps "
                    "(default: reports/loadtest_baseline.csv and reports/loadtest_optimized.csv, if present)")
    ap.add_argument("--curve", default=os.path.join(HERE, "data", "power_curve.json"))
    ap.add_argument("--watts", type=float, help="board power at full load (default: from the curve at the default cap)")
    ap.add_argument("--min-throughput", type=float, default=0.95, help="keep at least this share of uncapped tokens/s")
    ap.add_argument("--live", type=int, metavar="SECONDS", help="sample nvidia-smi power for N seconds")
    ap.add_argument("--outdir", default=os.path.join(HERE, "reports"))
    a = ap.parse_args(argv)
    if a.loadtest is None:
        a.loadtest = [] if a.live else [p for p in (os.path.join(HERE, "reports", "loadtest_baseline.csv"),
                                                   os.path.join(HERE, "reports", "loadtest_optimized.csv")) if os.path.exists(p)]
    if a.live:
        live(a.live)
        if not a.loadtest:
            return None

    curve = json.load(open(a.curve))
    default = next(r for r in curve["rows"] if r["cap_w"] == curve["default_cap_w"])
    watts = a.watts or default["avg_draw_w"]
    md = ["# Performance per watt", ""]
    builds = []
    print(f"\nPERFORMANCE PER WATT  (board power {watts:.0f} W at full load: "
          f"{'--watts' if a.watts else 'from ' + os.path.basename(a.curve)})")
    if a.loadtest:
        md += [f"Board power assumed at full load: {watts:.0f} W (same for every build; measure yours).", "",
               "| Build | Breaking point | Output tok/s | Tokens per joule | Wh per 1M output tokens |",
               "|---|---:|---:|---:|---:|"]
        for p in a.loadtest:
            k = knee_row(p)
            tps = float(k["output_tok_s_per_gpu"]); tpj = tps / watts
            wh = 1e6 / tpj / 3600
            name = k["label"]
            builds.append((name, tps, tpj, wh))
            print(f"  {name:12s} {int(k['concurrency']):3d} users  {tps:7,.0f} tok/s  {tpj:5.2f} tokens/J  {wh:6.0f} Wh per 1M output tokens")
            md.append(f"| {name} | {k['concurrency']} users | {tps:,.0f} | {tpj:.2f} | {wh:.0f} |")
        if len(builds) >= 2:
            b, c = builds[0], builds[-1]
            print(f"  -> {c[0]} vs {b[0]}: {c[2]/b[2]-1:+.0%} tokens per joule, {c[3]/b[3]-1:+.0%} energy per token")
            md += ["", f"{c[0]} vs {b[0]}: **{c[2]/b[2]-1:+.0%} tokens per joule** at the same power."]

    tps0 = builds[-1][1] if builds else 1000.0
    who = builds[-1][0] if builds else "a build at 1,000 tok/s"
    print(f"\n  POWER-CAP SWEEP for {who}  ·  {curve['gpu']}  ·  ILLUSTRATIVE curve, not a measurement")
    print(f"  {'cap':>6s} {'avg draw':>9s} {'tok/s':>8s} {'tokens/J':>9s} {'vs default':>11s}")
    md += ["", f"## Power-cap sweep · {who} · ILLUSTRATIVE curve ({os.path.basename(a.curve)})", "",
           "| Power cap | Avg draw | Output tok/s | Tokens per joule | Power vs default | Speed vs default | Tokens/J vs default |",
           "|---:|---:|---:|---:|---:|---:|---:|"]
    base_tpj = tps0 * default["relative_throughput"] / default["avg_draw_w"]
    best = default
    for r in sorted(curve["rows"], key=lambda r: -r["cap_w"]):
        tps = tps0 * r["relative_throughput"]; tpj = tps / r["avg_draw_w"]
        if r["relative_throughput"] >= a.min_throughput and r["cap_w"] < best["cap_w"]:
            best = r
        print(f"  {r['cap_w']:5d}W {r['avg_draw_w']:8d}W {tps:8,.0f} {tpj:9.2f} {tpj/base_tpj-1:+10.0%}")
        md.append(f"| {r['cap_w']} W | {r['avg_draw_w']} W | {tps:,.0f} | {tpj:.2f} | "
                  f"{r['avg_draw_w']/default['avg_draw_w']-1:+.0%} | {r['relative_throughput']-1:+.0%} | {tpj/base_tpj-1:+.0%} |")
    dp = best["avg_draw_w"] / default["avg_draw_w"] - 1; ds = best["relative_throughput"] - 1
    dtj = (tps0 * best["relative_throughput"] / best["avg_draw_w"]) / base_tpj - 1
    rec = (f"cap at {best['cap_w']} W: power {dp:+.0%}, speed {ds:+.0%}, tokens per joule {dtj:+.0%} "
           f"(lowest cap keeping >= {a.min_throughput:.0%} of throughput)")
    print(f"\n  RECOMMENDATION: {rec}")
    print(f"  Verify on your hardware: sudo nvidia-smi -i 0 -pl {best['cap_w']}, re-run the load test at the knee,")
    print("  and watch power.draw, clocks_event_reasons and inlet temperature. Then re-check the SLO.")
    md += ["", f"**Recommendation:** {rec}.", "",
           f"Verify on real hardware: `sudo nvidia-smi -i 0 -pl {best['cap_w']}`, re-run the load test at the breaking point, "
           "and watch power draw, throttle reasons and inlet temperature. A cap that saves power but breaks the SLO is not a saving."]
    os.makedirs(a.outdir, exist_ok=True)
    out = os.path.join(a.outdir, "power.md")
    with open(out, "w") as f:
        f.write("\n".join(md) + "\n")
    print(f"  wrote {os.path.relpath(out)}\n")
    return {"builds": builds, "best": best, "watts": watts, "rec": rec}


if __name__ == "__main__":
    main()
