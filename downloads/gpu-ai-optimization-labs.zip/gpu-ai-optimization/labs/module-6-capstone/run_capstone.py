#!/usr/bin/env python3
"""
Module 6 · The whole capstone in one command.

Starts the simulated server in the background (a fresh one for every test, so
no test inherits a warm cache), runs every load test, stops the server cleanly,
then runs the SLO report, both canary decisions and the power analysis.

  1. naive        one short prompt, replayed     (baseline server)   the classic mistake
  2. baseline     production mix, cache on       (baseline server)
  3. baseline-nocache   production mix, cache busted   (baseline server)
  4. optimized    production mix, cache on       (FP8 server)        the one change
  5. optimized-nocache  production mix, cache busted   (FP8 server)
  6. int4         production mix, cache on       (INT4 server)       a tempting change
  then: slo_report.py, canary.py (fp8 and int4), power.py, reports/capstone_summary.md

Usage:
  python3 run_capstone.py              # everything, about 3-4 minutes on a laptop
  python3 run_capstone.py --self-test  # a 30-second smoke test of the whole pipeline
  python3 run_capstone.py --only baseline,optimized

Only the Python standard library is used.
"""
import argparse, os, socket, subprocess, sys, time, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import loadtest, slo_report, canary, power  # noqa: E402

TESTS = [  # label, server profile, extra loadtest args
    ("naive", "baseline", ["--mix", os.path.join(HERE, "data", "traffic_naive.json")]),
    ("baseline", "baseline", []),
    ("baseline-nocache", "baseline", ["--cache-bust"]),
    ("optimized", "optimized", []),
    ("optimized-nocache", "optimized", ["--cache-bust"]),
    ("int4", "int4", []),
]


def free_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class Server:
    """the mock server as a background process; always stopped, even on errors"""

    def __init__(self, profile, speed, logdir):
        self.port = free_port()
        self.log = open(os.path.join(logdir, f".server_{profile}.log"), "w")
        self.proc = subprocess.Popen([sys.executable, os.path.join(HERE, "mock_server.py"), "--profile", profile,
                                      "--port", str(self.port), "--speed", str(speed)],
                                     stdout=self.log, stderr=subprocess.STDOUT)
        self.url = f"http://127.0.0.1:{self.port}"
        for _ in range(100):
            try:
                urllib.request.urlopen(self.url + "/health", timeout=1).read(); return
            except Exception:
                if self.proc.poll() is not None:
                    break
                time.sleep(0.1)
        self.stop()
        raise RuntimeError(f"mock server ({profile}) did not start; see {self.log.name}")

    def stop(self):
        if self.proc.poll() is None:
            self.proc.terminate()                  # SIGTERM on macOS/Linux; TerminateProcess on Windows
            try:
                self.proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.proc.kill(); self.proc.wait()
        self.log.close()
        last = open(self.log.name).read().strip().splitlines()
        return last[-1] if last else ""

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.stop()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--self-test", action="store_true", help="fast smoke test: fewer levels and requests")
    ap.add_argument("--only", help="comma-separated test labels to run (default: all)")
    ap.add_argument("--speed", type=float, default=20.0)
    a = ap.parse_args()
    os.makedirs(os.path.join(HERE, "reports"), exist_ok=True)
    if not os.path.exists(os.path.join(HERE, "data", "requests_30d.csv")):
        subprocess.run([sys.executable, os.path.join(HERE, "data", "make_data.py")], check=True)

    outdir = os.path.join(HERE, "reports", "self-test") if a.self_test else os.path.join(HERE, "reports")
    extra = ["--levels", "1,4,8,16", "--min-requests", "20", "--per-user", "2"] if a.self_test else []
    tests = [t for t in TESTS if not a.only or t[0] in a.only.split(",")]
    if a.self_test:
        tests = [t for t in tests if t[0] in ("baseline", "optimized", "int4")]
    os.makedirs(outdir, exist_ok=True)
    t_start = time.time(); results = {}
    for label, profile, args in tests:
        with Server(profile, a.speed, outdir) as srv:
            print(f"--- {label}: started mock server profile={profile} on port {srv.port}")
            res = loadtest.main(["--url", srv.url, "--label", label, "--outdir", outdir] + args + extra)
            msg = srv.stop()
            print(f"--- {label}: {msg}")
        if res is None:
            raise SystemExit(f"load test '{label}' failed")
        results[label] = res

    slo = slo_report.main(["--outdir", outdir])
    can = {}
    lt = lambda n: os.path.join(outdir, f"loadtest_{n}.csv")
    for build, cand in (("fp8", "optimized"), ("int4", "int4")):
        if "baseline" in results and cand in results:
            can[build] = canary.main(["--baseline", lt("baseline"), "--candidate", lt(cand), "--build", build,
                                      "--slo-status", os.path.join(outdir, "slo_status.json"), "--outdir", outdir])
    pw = None
    if "baseline" in results and "optimized" in results:
        pw = power.main(["--loadtest", lt("baseline"), lt("optimized"), "--outdir", outdir])

    # ---- one-page summary for CAPSTONE.md ----
    def k(label):
        r = results.get(label)
        return r["knee"] if r else None
    md = ["# Capstone summary (generated by run_capstone.py)", "",
          "| Test | Breaking point (p95 TTFT <= 1 s) | Output tok/s per GPU there | p95 TTFT there | Error rate there |",
          "|---|---:|---:|---:|---:|"]
    print("\nCAPSTONE SUMMARY")
    for label, *_ in tests:
        kn = k(label)
        if kn:
            md.append(f"| {label} | {kn['concurrency']} users | {kn['output_tok_s_per_gpu']:,.0f} | "
                      f"{kn['p95_ttft_ms']:.0f} ms | {kn['error_rate']:.1%} |")
            print(f"  {label:18s} breaking point {kn['concurrency']:3d} users  {kn['output_tok_s_per_gpu']:7,.0f} tok/s/GPU"
                  f"  p95 TTFT {kn['p95_ttft_ms']:5.0f} ms  errors {kn['error_rate']:.1%}")
        else:
            md.append(f"| {label} | below lowest level | | | |")
    b, o = k("baseline"), k("optimized")
    if b and o:
        line = (f"Baseline -> FP8 at the SLO: {b['concurrency']} -> {o['concurrency']} users, "
                f"{b['output_tok_s_per_gpu']:,.0f} -> {o['output_tok_s_per_gpu']:,.0f} tok/s per GPU "
                f"({o['output_tok_s_per_gpu']/b['output_tok_s_per_gpu']-1:+.0%})")
        md += ["", line]; print("  " + line)
    md += ["", f"Error budget decision: **{slo['decision']}**"]
    for build, c in can.items():
        md.append(f"Canary `{build}`: **{c['verdict']}**" + (f" ({'; '.join(c['reasons'])})" if c["reasons"] else ""))
    if pw:
        md.append(f"Power: {pw['rec']}")
    with open(os.path.join(outdir, "capstone_summary.md"), "w") as f:
        f.write("\n".join(md) + "\n")
    print(f"  error budget: {slo['decision']}   " + "   ".join(f"canary {b_}: {c['verdict']}" for b_, c in can.items()))
    print(f"\n  all reports in {os.path.relpath(outdir)}/  ·  finished in {time.time() - t_start:.0f} s")
    if a.self_test:
        ok = (results["baseline"]["knee"] is not None and can.get("fp8", {}).get("verdict") == "PROMOTE"
              and can.get("int4", {}).get("verdict") == "ROLL BACK")
        print("  SELF-TEST " + ("PASSED" if ok else "FAILED"))
        sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
