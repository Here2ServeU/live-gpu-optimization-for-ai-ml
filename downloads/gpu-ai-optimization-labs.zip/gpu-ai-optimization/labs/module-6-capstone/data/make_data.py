#!/usr/bin/env python3
"""
Module 6 · Generate the lab's sample data (seeded, so everyone gets the same files).

  data/requests_30d.csv   30 days of hourly production counts for one LLM endpoint:
                          requests, errors, requests slower than 1 s to first token,
                          and p95 queue time. Includes one bad deploy (an error spike)
                          and one latency regression, like a real month.
  data/eval_results.csv   a 300-item quality eval, graded right/wrong for three builds
                          of the same model: baseline (FP16), fp8, and int4.

Usage:
  python3 data/make_data.py          # rewrites both files (they are committed already)

Only the Python standard library is used.
"""
import csv, math, os, random

HERE = os.path.dirname(os.path.abspath(__file__))


def requests_30d(path):
    rng = random.Random(6)
    rows = []
    for h in range(30 * 24):
        day, hour = divmod(h, 24)
        diurnal = 0.35 + 0.65 * max(0.0, math.sin((hour - 6) / 24 * 2 * math.pi)) ** 1.2
        weekly = 0.75 if day % 7 in (5, 6) else 1.0
        reqs = int(60000 * diurnal * weekly * rng.uniform(0.92, 1.08))
        err = rng.uniform(0.0014, 0.0026)            # normal background failures
        slow = rng.uniform(0.018, 0.030)             # normal share of requests with TTFT > 1 s
        queue_p95 = rng.uniform(80, 160) * (1 + diurnal)
        note = ""
        if day == 8 and hour in (14, 15, 16):        # bad deploy: config error, rolled back after 3 h
            err, note = 0.15, "bad deploy (rolled back)"
        if day == 20 and 9 <= hour <= 18:            # latency regression: a batching setting changed
            slow, queue_p95, note = 0.20, queue_p95 * 4, "latency regression (max batch tokens lowered)"
        rows.append({"hour": f"2026-09-{day + 1:02d}T{hour:02d}:00", "requests": reqs,
                     "errors": int(reqs * err), "slow_ttft": int(reqs * slow),
                     "queue_p95_ms": int(queue_p95), "note": note})
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    return len(rows)


def eval_results(path):
    rng = random.Random(62)
    rows = []
    cats = [("chat", 150, 0.88), ("rag", 100, 0.85), ("code", 50, 0.80)]
    flips = {  # (P[right -> wrong], P[wrong -> right]) relative to the baseline build
        "fp8": {"chat": (0.015, 0.02), "rag": (0.02, 0.02), "code": (0.03, 0.03)},
        "int4": {"chat": (0.04, 0.02), "rag": (0.06, 0.02), "code": (0.16, 0.02)},
    }
    i = 0
    for cat, n, acc in cats:
        for _ in range(n):
            i += 1
            base = rng.random() < acc
            row = {"item": f"q{i:03d}", "category": cat, "baseline": int(base)}
            for build, f in flips.items():
                down, up = f[cat]
                r = rng.random()
                row[build] = int((base and r >= down) or (not base and r < up))
            rows.append(row)
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    return len(rows)


if __name__ == "__main__":
    n1 = requests_30d(os.path.join(HERE, "requests_30d.csv"))
    n2 = eval_results(os.path.join(HERE, "eval_results.csv"))
    print(f"wrote data/requests_30d.csv ({n1} hours) and data/eval_results.csv ({n2} items)")
