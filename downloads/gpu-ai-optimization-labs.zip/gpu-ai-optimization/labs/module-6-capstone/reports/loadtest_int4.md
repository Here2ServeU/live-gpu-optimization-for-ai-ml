# Load test · int4

Target: `http://127.0.0.1:52997` · mix: `production-mix` · seed 42 · cache-bust: no · SLO: p95 TTFT <= 1000 ms and error rate <= 1.0% · GPUs: 1

| Concurrency | Requests | p50 TTFT | p95 TTFT | p95 end-to-end | p50 TPOT | Output tok/s/GPU | Error rate | Cache hits | Meets SLO |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|
| 1 | 60 | 37 ms | 166 ms | 5.0 s | 5.3 ms | 183 | 0.0% | 36% | yes |
| 2 | 60 | 38 ms | 172 ms | 5.3 s | 5.6 ms | 338 | 0.0% | 38% | yes |
| 4 | 60 | 40 ms | 185 ms | 5.9 s | 6.6 ms | 585 | 0.0% | 38% | yes |
| 8 | 60 | 46 ms | 349 ms | 7.9 s | 8.3 ms | 913 | 0.0% | 38% | yes |
| 12 | 60 | 48 ms | 792 ms | 9.5 s | 10.1 ms | 1,125 | 0.0% | 38% | yes |
| 16 | 60 | 74 ms | 971 ms | 10.2 s | 11.7 ms | 1,280 | 0.0% | 38% | yes |
| 24 | 72 | 76 ms | 1426 ms | 12.4 s | 14.6 ms | 1,478 | 0.0% | 40% | **no** |
| 32 | 96 | 91 ms | 1793 ms | 14.0 s | 18.1 ms | 1,618 | 0.0% | 41% | **no** |
| 48 | 144 | 1795 ms | 3675 ms | 16.7 s | 22.1 ms | 1,628 | 4.2% | 42% | **no** |
| 64 | 192 | 4116 ms | 4881 ms | 16.6 s | 22.2 ms | 1,680 | 13.0% | 41% | **no** |

**Breaking point:** max concurrency that meets the SLO = **16** (p95 TTFT 971 ms, 1,280 output tok/s per GPU, error rate 0.0%).

Timing source: server. Percentiles are nearest-rank over successful requests. Output tok/s is measured over the steady window of each level (all users busy), not the drain at the end.
