# SLO and error-budget report

Source: `data/requests_30d.csv` · 720 hours · window: 30 days

| SLO | Target | Delivered | Budget (bad requests allowed) | Spent | Budget left | Burn 1 h / 6 h / 3 d |
|---|---:|---:|---:|---:|---:|---|
| availability (request succeeds) | 99.50% | 99.713% | 109,644 | 62,880 | **42.7%** | 0.3x / 0.4x / 0.4x |
| latency (TTFT <= 1 s) | 95.00% | 97.297% | 1,096,437 | 592,634 | **45.9%** | 0.5x / 0.5x / 0.5x |

### Alerts this month (multi-window burn rate, SRE workbook thresholds for a 30-day SLO)

- **availability (request succeeds):** page (14.4x over 1 h) first fired at 2026-09-09T14:00, active for 3 h; page (6.0x over 6 h) first fired at 2026-09-09T15:00, active for 7 h; ticket (1.0x over 72 h) first fired at 2026-09-09T14:00, active for 8 h
- **latency (TTFT <= 1 s):** ticket (1.0x over 72 h) first fired at 2026-09-21T16:00, active for 8 h

Incidents in the log: bad deploy (rolled back), latency regression (max batch tokens lowered).

## Decision: **SHIP**

every SLO has at least 25% of its budget left and nothing is burning fast. Optimizations may ship, through a canary with automatic rollback.
