# Canary analysis · build `int4`

Baseline `loadtest_baseline.csv` vs candidate `loadtest_int4.csv` at **12** concurrent users; quality from `eval_results.csv` (300 items).

| Guardrail | Baseline | Candidate | Rule | Result |
|---|---:|---:|---|:---:|
| p95 TTFT | 827 ms | 792 ms | <= 1000 ms and <= +10% | pass |
| error rate | 0.0% | 0.0% | <= +0.5 pts | pass |
| output tok/s per GPU | 830 | 1,125 | >= 95% of baseline | pass |
| eval accuracy | 84.0% | 79.3% | drop <= 1.0 pt | **FAIL** |
| worst category (code) | 74.0% | 62.0% | drop <= 5 pts | **FAIL** |
| error budget |  | SHIP | decision is SHIP | pass |

Eval detail: 15 answers went right to wrong and 1 wrong to right.

## Verdict: **ROLL BACK**

- eval accuracy: 79.3% vs 84.0% (rule: drop <= 1.0 pt)
- worst category (code): 62.0% vs 74.0% (rule: drop <= 5 pts)
