# Performance per watt

Board power assumed at full load: 655 W (same for every build; measure yours).

| Build | Breaking point | Output tok/s | Tokens per joule | Wh per 1M output tokens |
|---|---:|---:|---:|---:|
| baseline | 12 users | 830 | 1.27 | 219 |
| optimized | 16 users | 1,408 | 2.15 | 129 |

optimized vs baseline: **+70% tokens per joule** at the same power.

## Power-cap sweep · optimized · ILLUSTRATIVE curve (power_curve.json)

| Power cap | Avg draw | Output tok/s | Tokens per joule | Power vs default | Speed vs default | Tokens/J vs default |
|---:|---:|---:|---:|---:|---:|---:|
| 700 W | 655 W | 1,408 | 2.15 | +0% | +0% | +0% |
| 600 W | 590 W | 1,380 | 2.34 | -10% | -2% | +9% |
| 500 W | 495 W | 1,352 | 2.73 | -24% | -4% | +27% |
| 400 W | 398 W | 1,183 | 2.97 | -39% | -16% | +38% |
| 300 W | 299 W | 929 | 3.11 | -54% | -34% | +45% |

**Recommendation:** cap at 500 W: power -24%, speed -4%, tokens per joule +27% (lowest cap keeping >= 95% of throughput).

Verify on real hardware: `sudo nvidia-smi -i 0 -pl 500`, re-run the load test at the breaking point, and watch power draw, throttle reasons and inlet temperature. A cap that saves power but breaks the SLO is not a saving.
