# Load test · baseline

Target: `http://127.0.0.1:49757` · mix: `production-mix` · seed 42 · cache-bust: no · SLO: p95 TTFT <= 1000 ms and error rate <= 1.0% · GPUs: 1

| Concurrency | Requests | p50 TTFT | p95 TTFT | p95 end-to-end | p50 TPOT | Output tok/s/GPU | Error rate | Cache hits | Meets SLO |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|
| 1 | 60 | 41 ms | 174 ms | 8.8 s | 9.2 ms | 106 | 0.0% | 36% | yes |
| 2 | 60 | 42 ms | 180 ms | 9.0 s | 9.6 ms | 202 | 0.0% | 38% | yes |
| 4 | 60 | 44 ms | 197 ms | 9.5 s | 10.5 ms | 371 | 0.0% | 38% | yes |
| 8 | 60 | 50 ms | 365 ms | 11.6 s | 12.2 ms | 634 | 0.0% | 38% | yes |
| 12 | 60 | 52 ms | 827 ms | 13.1 s | 13.9 ms | 830 | 0.0% | 38% | yes |
| 16 | 60 | 78 ms | 1014 ms | 13.7 s | 15.4 ms | 985 | 0.0% | 38% | **no** |
| 24 | 72 | 80 ms | 1488 ms | 15.7 s | 18.1 ms | 1,206 | 0.0% | 40% | **no** |
| 32 | 96 | 1202 ms | 3347 ms | 16.1 s | 20.8 ms | 1,242 | 0.0% | 41% | **no** |
| 48 | 144 | 3035 ms | 4895 ms | 20.8 s | 20.6 ms | 1,364 | 17.4% | 43% | **no** |

**Breaking point:** max concurrency that meets the SLO = **12** (p95 TTFT 827 ms, 830 output tok/s per GPU, error rate 0.0%).

Timing source: server. Percentiles are nearest-rank over successful requests. Output tok/s is measured over the steady window of each level (all users busy), not the drain at the end.
