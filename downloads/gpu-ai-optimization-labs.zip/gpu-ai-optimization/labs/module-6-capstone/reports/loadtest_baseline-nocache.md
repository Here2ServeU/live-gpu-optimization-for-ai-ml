# Load test · baseline-nocache

Target: `http://127.0.0.1:58645` · mix: `production-mix` · seed 42 · cache-bust: yes · SLO: p95 TTFT <= 1000 ms and error rate <= 1.0% · GPUs: 1

| Concurrency | Requests | p50 TTFT | p95 TTFT | p95 end-to-end | p50 TPOT | Output tok/s/GPU | Error rate | Cache hits | Meets SLO |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|
| 1 | 60 | 75 ms | 199 ms | 8.8 s | 9.2 ms | 105 | 0.0% | 0% | yes |
| 2 | 60 | 77 ms | 238 ms | 9.1 s | 9.7 ms | 198 | 0.0% | 0% | yes |
| 4 | 60 | 77 ms | 273 ms | 9.9 s | 10.9 ms | 357 | 0.0% | 0% | yes |
| 8 | 60 | 87 ms | 548 ms | 12.3 s | 12.8 ms | 592 | 0.0% | 0% | yes |
| 12 | 60 | 93 ms | 1102 ms | 14.3 s | 15.1 ms | 758 | 0.0% | 0% | **no** |
| 16 | 60 | 120 ms | 1476 ms | 14.9 s | 16.6 ms | 884 | 0.0% | 0% | **no** |
| 24 | 72 | 154 ms | 2234 ms | 17.4 s | 20.4 ms | 1,049 | 0.0% | 0% | **no** |
| 32 | 96 | 1637 ms | 4266 ms | 18.1 s | 23.7 ms | 1,074 | 0.0% | 0% | **no** |

**Breaking point:** max concurrency that meets the SLO = **8** (p95 TTFT 548 ms, 592 output tok/s per GPU, error rate 0.0%).

Timing source: server. Percentiles are nearest-rank over successful requests. Output tok/s is measured over the steady window of each level (all users busy), not the drain at the end.
