# Load test · optimized-nocache

Target: `http://127.0.0.1:44275` · mix: `production-mix` · seed 42 · cache-bust: yes · SLO: p95 TTFT <= 1000 ms and error rate <= 1.0% · GPUs: 1

| Concurrency | Requests | p50 TTFT | p95 TTFT | p95 end-to-end | p50 TPOT | Output tok/s/GPU | Error rate | Cache hits | Meets SLO |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|
| 1 | 60 | 53 ms | 140 ms | 6.3 s | 6.7 ms | 146 | 0.0% | 0% | yes |
| 2 | 60 | 54 ms | 167 ms | 6.5 s | 7.0 ms | 276 | 0.0% | 0% | yes |
| 4 | 60 | 54 ms | 192 ms | 7.1 s | 7.7 ms | 501 | 0.0% | 0% | yes |
| 8 | 60 | 61 ms | 384 ms | 8.7 s | 9.1 ms | 838 | 0.0% | 0% | yes |
| 12 | 60 | 65 ms | 773 ms | 10.0 s | 10.6 ms | 1,080 | 0.0% | 0% | yes |
| 16 | 60 | 84 ms | 1035 ms | 10.4 s | 11.6 ms | 1,264 | 0.0% | 0% | **no** |
| 24 | 72 | 108 ms | 1565 ms | 12.1 s | 14.1 ms | 1,508 | 0.0% | 0% | **no** |
| 32 | 96 | 117 ms | 2036 ms | 13.5 s | 17.2 ms | 1,682 | 0.0% | 0% | **no** |
| 48 | 144 | 108 ms | 2932 ms | 14.4 s | 22.8 ms | 1,902 | 0.0% | 0% | **no** |
| 64 | 192 | 1380 ms | 3564 ms | 20.2 s | 27.2 ms | 1,900 | 3.1% | 0% | **no** |
| 96 | 288 | 4318 ms | 5042 ms | 19.5 s | 27.4 ms | 2,021 | 23.6% | 0% | **no** |

**Breaking point:** max concurrency that meets the SLO = **12** (p95 TTFT 773 ms, 1,080 output tok/s per GPU, error rate 0.0%).

Timing source: server. Percentiles are nearest-rank over successful requests. Output tok/s is measured over the steady window of each level (all users busy), not the drain at the end.
