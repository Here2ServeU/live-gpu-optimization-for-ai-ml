# Load test · optimized

Target: `http://127.0.0.1:35195` · mix: `production-mix` · seed 42 · cache-bust: no · SLO: p95 TTFT <= 1000 ms and error rate <= 1.0% · GPUs: 1

| Concurrency | Requests | p50 TTFT | p95 TTFT | p95 end-to-end | p50 TPOT | Output tok/s/GPU | Error rate | Cache hits | Meets SLO |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|
| 1 | 60 | 29 ms | 122 ms | 6.3 s | 6.7 ms | 147 | 0.0% | 36% | yes |
| 2 | 60 | 29 ms | 127 ms | 6.5 s | 6.9 ms | 282 | 0.0% | 38% | yes |
| 4 | 60 | 31 ms | 138 ms | 6.8 s | 7.5 ms | 521 | 0.0% | 38% | yes |
| 8 | 60 | 35 ms | 256 ms | 8.2 s | 8.6 ms | 897 | 0.0% | 38% | yes |
| 12 | 60 | 37 ms | 580 ms | 9.2 s | 9.8 ms | 1,181 | 0.0% | 38% | yes |
| 16 | 60 | 54 ms | 711 ms | 9.6 s | 10.7 ms | 1,408 | 0.0% | 38% | yes |
| 24 | 72 | 56 ms | 1042 ms | 10.9 s | 12.6 ms | 1,737 | 0.0% | 40% | **no** |
| 32 | 96 | 66 ms | 1308 ms | 11.3 s | 14.8 ms | 1,984 | 0.0% | 41% | **no** |
| 48 | 144 | 68 ms | 1862 ms | 13.7 s | 19.0 ms | 2,315 | 0.0% | 42% | **no** |
| 64 | 192 | 1145 ms | 2452 ms | 16.7 s | 22.6 ms | 2,334 | 0.0% | 41% | **no** |
| 96 | 288 | 4231 ms | 4901 ms | 17.4 s | 23.8 ms | 2,428 | 13.5% | 39% | **no** |

**Breaking point:** max concurrency that meets the SLO = **16** (p95 TTFT 711 ms, 1,408 output tok/s per GPU, error rate 0.0%).

Timing source: server. Percentiles are nearest-rank over successful requests. Output tok/s is measured over the steady window of each level (all users busy), not the drain at the end.
