# Canary analysis · build `fp8`

Baseline `loadtest_baseline.csv` vs candidate `loadtest_optimized.csv` at **12** concurrent users; quality from `eval_results.csv` (300 items).

| Guardrail | Baseline | Candidate | Rule | Result |
|---|---:|---:|---|:---:|
| p95 TTFT | 827 ms | 580 ms | <= 1000 ms and <= +10% | pass |
| error rate | 0.0% | 0.0% | <= +0.5 pts | pass |
| output tok/s per GPU | 830 | 1,181 | >= 95% of baseline | pass |
| eval accuracy | 84.0% | 83.7% | drop <= 1.0 pt | pass |
| worst category (chat) | 86.0% | 85.3% | drop <= 5 pts | pass |
| error budget |  | SHIP | decision is SHIP | pass |

Eval detail: 2 answers went right to wrong and 1 wrong to right.

## Verdict: **PROMOTE**

Roll out in steps (1% → 5% → 25% → 50% → 100%), re-checking these guardrails at each step, with automatic rollback.
