# Load test · naive

Target: `http://127.0.0.1:41993` · mix: `naive-one-prompt` · seed 42 · cache-bust: no · SLO: p95 TTFT <= 1000 ms and error rate <= 1.0% · GPUs: 1

| Concurrency | Requests | p50 TTFT | p95 TTFT | p95 end-to-end | p50 TPOT | Output tok/s/GPU | Error rate | Cache hits | Meets SLO |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|
| 1 | 60 | 9 ms | 9 ms | 0.5 s | 9.2 ms | 109 | 0.0% | 94% | yes |
| 2 | 60 | 9 ms | 9 ms | 0.5 s | 9.4 ms | 214 | 0.0% | 96% | yes |
| 4 | 60 | 10 ms | 10 ms | 0.5 s | 9.7 ms | 411 | 0.0% | 96% | yes |
| 8 | 60 | 10 ms | 10 ms | 0.5 s | 10.5 ms | 764 | 0.0% | 96% | yes |
| 12 | 60 | 11 ms | 11 ms | 0.6 s | 11.2 ms | 1,070 | 0.0% | 96% | yes |
| 16 | 60 | 12 ms | 12 ms | 0.6 s | 12.0 ms | 1,339 | 0.0% | 96% | yes |
| 24 | 72 | 13 ms | 13 ms | 0.7 s | 13.4 ms | 1,787 | 0.0% | 96% | yes |
| 32 | 96 | 14 ms | 14 ms | 0.7 s | 14.9 ms | 2,147 | 0.0% | 96% | yes |
| 48 | 144 | 17 ms | 17 ms | 0.9 s | 17.9 ms | 2,688 | 0.0% | 96% | yes |
| 64 | 192 | 19 ms | 19 ms | 1.0 s | 20.8 ms | 3,076 | 0.0% | 96% | yes |
| 96 | 288 | 19 ms | 1060 ms | 2.1 s | 20.8 ms | 3,332 | 0.0% | 96% | **no** |
| 128 | 384 | 1060 ms | 1060 ms | 2.1 s | 20.8 ms | 3,460 | 0.0% | 96% | **no** |

**Breaking point:** max concurrency that meets the SLO = **64** (p95 TTFT 19 ms, 3,076 output tok/s per GPU, error rate 0.0%).

Timing source: server. Percentiles are nearest-rank over successful requests. Output tok/s is measured over the steady window of each level (all users busy), not the drain at the end.
