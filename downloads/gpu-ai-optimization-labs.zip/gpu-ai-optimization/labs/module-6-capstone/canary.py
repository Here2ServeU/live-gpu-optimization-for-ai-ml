#!/usr/bin/env python3
"""
Module 6 · Stage 4 — Ship optimizations safely: the canary decision.

A canary sends a small share of real traffic to the new build (say 1%, then 5%,
25%, 50%, 100%) and, at every step, compares it with the baseline on rules that
were written down BEFORE the rollout. If any rule fails, traffic goes back to
the baseline automatically. This script is that comparison, run offline on
your lab results:

  speed      the candidate's p95 TTFT must meet the SLO and not regress more
             than 10% against the baseline, at the same concurrency
  errors     error rate no more than 0.5 points above the baseline
  capacity   output tokens/s at least 95% of the baseline
  quality    eval accuracy no more than 1.0 point below the baseline overall,
             and no more than 5 points below in any one category
  budget     the error-budget decision from slo_report.py must be SHIP

All rules must pass to PROMOTE. Otherwise: ROLL BACK, with the reasons.

Usage:
  python3 canary.py --baseline reports/loadtest_baseline.csv --candidate reports/loadtest_optimized.csv
  python3 canary.py ... --build int4         # judge the INT4 build's eval scores instead of FP8
  python3 canary.py ... --at 16              # compare at a different concurrency

--at defaults to the baseline's breaking point: the busiest level production
runs at today. Writes reports/canary_<build>.md.
Only the Python standard library is used.
"""
import argparse, csv, json, os

HERE = os.path.dirname(os.path.abspath(__file__))


def load_lt(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        r["concurrency"] = int(r["concurrency"])
        for k in ("p95_ttft_ms", "error_rate", "output_tok_s_per_gpu", "p95_e2e_ms"):
            r[k] = float(r[k])
        r["meets_slo"] = r["meets_slo"] == "True"
    return rows


def knee(rows):
    k = None
    for r in rows:
        if r["meets_slo"]:
            k = r
        else:
            break
    return k


def accuracy(rows, col, cat=None):
    sel = [r for r in rows if cat is None or r["category"] == cat]
    return 100.0 * sum(int(r[col]) for r in sel) / len(sel)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--baseline", default=os.path.join(HERE, "reports", "loadtest_baseline.csv"))
    ap.add_argument("--candidate", default=os.path.join(HERE, "reports", "loadtest_optimized.csv"))
    ap.add_argument("--eval", default=os.path.join(HERE, "data", "eval_results.csv"))
    ap.add_argument("--build", default="fp8", help="which eval column is the candidate (fp8 or int4)")
    ap.add_argument("--slo-status", default=os.path.join(HERE, "reports", "slo_status.json"))
    ap.add_argument("--at", type=int, help="concurrency to compare at (default: baseline breaking point)")
    ap.add_argument("--slo-ttft-ms", type=float, default=1000.0)
    ap.add_argument("--max-ttft-regression", type=float, default=0.10)
    ap.add_argument("--max-error-increase", type=float, default=0.005)
    ap.add_argument("--min-capacity", type=float, default=0.95)
    ap.add_argument("--max-quality-drop", type=float, default=1.0, help="points of accuracy, overall")
    ap.add_argument("--max-category-drop", type=float, default=5.0, help="points of accuracy, any category")
    ap.add_argument("--outdir", default=os.path.join(HERE, "reports"))
    a = ap.parse_args(argv)

    base, cand = load_lt(a.baseline), load_lt(a.candidate)
    at = a.at or (knee(base) or base[0])["concurrency"]
    b = next((r for r in base if r["concurrency"] == at), None)
    c = next((r for r in cand if r["concurrency"] == at), None)
    if not b or not c:
        raise SystemExit(f"both load tests need a row at concurrency {at}")
    with open(a.eval, newline="") as f:
        ev = list(csv.DictReader(f))
    if a.build not in ev[0]:
        raise SystemExit(f"no eval column '{a.build}' in {a.eval} (have: {', '.join(list(ev[0])[2:])})")
    q_base, q_cand = accuracy(ev, "baseline"), accuracy(ev, a.build)
    cats = sorted({r["category"] for r in ev})
    cat_drop = {k: accuracy(ev, "baseline", k) - accuracy(ev, a.build, k) for k in cats}
    worst_cat = max(cat_drop, key=cat_drop.get)
    flips_down = sum(1 for r in ev if r["baseline"] == "1" and r[a.build] == "0")
    flips_up = sum(1 for r in ev if r["baseline"] == "0" and r[a.build] == "1")
    budget = "unknown (run slo_report.py first)"
    budget_ok = None
    if os.path.exists(a.slo_status):
        budget = json.load(open(a.slo_status))["decision"]; budget_ok = budget == "SHIP"

    checks = [
        ("p95 TTFT", f"{b['p95_ttft_ms']:.0f} ms", f"{c['p95_ttft_ms']:.0f} ms",
         f"<= {a.slo_ttft_ms:.0f} ms and <= +{a.max_ttft_regression:.0%}",
         c["p95_ttft_ms"] <= a.slo_ttft_ms and c["p95_ttft_ms"] <= b["p95_ttft_ms"] * (1 + a.max_ttft_regression)),
        ("error rate", f"{b['error_rate']:.1%}", f"{c['error_rate']:.1%}", f"<= +{a.max_error_increase*100:.1f} pts",
         c["error_rate"] <= b["error_rate"] + a.max_error_increase),
        ("output tok/s per GPU", f"{b['output_tok_s_per_gpu']:,.0f}", f"{c['output_tok_s_per_gpu']:,.0f}",
         f">= {a.min_capacity:.0%} of baseline", c["output_tok_s_per_gpu"] >= a.min_capacity * b["output_tok_s_per_gpu"]),
        ("eval accuracy", f"{q_base:.1f}%", f"{q_cand:.1f}%", f"drop <= {a.max_quality_drop:.1f} pt",
         q_base - q_cand <= a.max_quality_drop),
        (f"worst category ({worst_cat})", f"{accuracy(ev, 'baseline', worst_cat):.1f}%",
         f"{accuracy(ev, a.build, worst_cat):.1f}%", f"drop <= {a.max_category_drop:.0f} pts",
         cat_drop[worst_cat] <= a.max_category_drop),
        ("error budget", "", budget, "decision is SHIP", bool(budget_ok)),
    ]
    verdict = "PROMOTE" if all(ok for *_, ok in checks) else "ROLL BACK"

    print(f"\nCANARY ANALYSIS  candidate build '{a.build}' vs baseline, at {at} concurrent users")
    print(f"  {'guardrail':26s} {'baseline':>10s} {'candidate':>10s}  {'rule':26s} result")
    for name, bv, cv, rule, ok in checks:
        print(f"  {name:26s} {bv:>10s} {cv:>10s}  {rule:26s} {'pass' if ok else 'FAIL'}")
    print(f"  eval detail: {flips_down} answers went right->wrong, {flips_up} wrong->right, out of {len(ev)}")
    reasons = [f"{n}: {cv} vs {bv} (rule: {rule})" for n, bv, cv, rule, ok in checks if not ok]
    if verdict == "PROMOTE":
        gain = c["output_tok_s_per_gpu"] / b["output_tok_s_per_gpu"] - 1
        ttft = c["p95_ttft_ms"] / b["p95_ttft_ms"] - 1
        print(f"\n  VERDICT: PROMOTE  (p95 TTFT {ttft:+.0%}, tokens/s per GPU {gain:+.0%}, quality {q_cand - q_base:+.1f} pt)")
        print("  Next: 1% -> 5% -> 25% -> 50% -> 100% of traffic, same guardrails at every step, "
              "automatic rollback on any failure.")
    else:
        print("\n  VERDICT: ROLL BACK")
        for r in reasons:
            print(f"    - {r}")
    md = [f"# Canary analysis · build `{a.build}`", "",
          f"Baseline `{os.path.basename(a.baseline)}` vs candidate `{os.path.basename(a.candidate)}` at **{at}** concurrent users; "
          f"quality from `{os.path.basename(a.eval)}` ({len(ev)} items).", "",
          "| Guardrail | Baseline | Candidate | Rule | Result |", "|---|---:|---:|---|:---:|"]
    md += [f"| {n} | {bv} | {cv} | {rule} | {'pass' if ok else '**FAIL**'} |" for n, bv, cv, rule, ok in checks]
    md += ["", f"Eval detail: {flips_down} answers went right to wrong and {flips_up} wrong to right.", "",
           f"## Verdict: **{verdict}**", ""]
    md += ([f"- {r}" for r in reasons] if reasons else
           ["Roll out in steps (1% → 5% → 25% → 50% → 100%), re-checking these guardrails at each step, with automatic rollback."])
    os.makedirs(a.outdir, exist_ok=True)
    out = os.path.join(a.outdir, f"canary_{a.build}.md")
    with open(out, "w") as f:
        f.write("\n".join(md) + "\n")
    print(f"  wrote {os.path.relpath(out)}\n")
    return {"verdict": verdict, "at": at, "reasons": reasons, "baseline": b, "candidate": c,
            "q_base": q_base, "q_cand": q_cand}


if __name__ == "__main__":
    main()
