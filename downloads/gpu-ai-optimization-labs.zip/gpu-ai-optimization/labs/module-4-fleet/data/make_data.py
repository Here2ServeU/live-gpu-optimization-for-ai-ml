#!/usr/bin/env python3
"""
Module 4 · sample data generator (deterministic).

Writes the three files the lab reads:

  data/gpus.json        GPU catalog: Module 1's spec-sheet figures and example prices,
                        plus the MIG profiles NVIDIA documents for A100/H100/H200 class GPUs.
  data/workloads.json   Four workloads a platform team typically serves, with what each
                        one runs on today ("current").
  data/traffic_24h.csv  One day of requests per second, minute by minute, for chat-8b:
                        quiet night, a morning ramp, a lunch dip, and a sudden spike at 14:00.

Run from the lab folder:  python3 data/make_data.py
The committed files were produced by exactly this script (seed 4).
"""
import csv, json, math, os, random

HERE = os.path.dirname(os.path.abspath(__file__))

# ---- GPUs: same figures and EXAMPLE prices as Module 1 --------------------------------
# MIG profiles: (name, compute slices of 7, memory GB, memory slices of 8, max instances per GPU)
# Bandwidth of a slice is approximated as (memory slices / 8) of the full GPU.
GPUS = {
    "_note": ("Spec-sheet figures (dense, no sparsity). Prices are EXAMPLE on-demand $/GPU-hour for the lab only; "
              "replace them with your own. MIG rows: compute slices out of 7, memory slices out of 8, and how many "
              "identical instances fit on one GPU (that sets the price of one slice when you pack it fully)."),
    "L4":        {"memory_gb": 24,  "bandwidth_gbs": 300,  "fp16_tflops": 121, "price_hr": 0.80, "fp8": True,  "nvlink": False, "mig": []},
    "A10G":      {"memory_gb": 24,  "bandwidth_gbs": 600,  "fp16_tflops": 125, "price_hr": 1.20, "fp8": False, "nvlink": False, "mig": []},
    "L40S":      {"memory_gb": 48,  "bandwidth_gbs": 864,  "fp16_tflops": 362, "price_hr": 1.80, "fp8": True,  "nvlink": False, "mig": []},
    "A100-80GB": {"memory_gb": 80,  "bandwidth_gbs": 2039, "fp16_tflops": 312, "price_hr": 3.00, "fp8": False, "nvlink": True,
                  "mig": [["1g.10gb", 1, 10, 1, 7], ["2g.20gb", 2, 20, 2, 3], ["3g.40gb", 3, 40, 4, 2],
                          ["4g.40gb", 4, 40, 4, 1], ["7g.80gb", 7, 80, 8, 1]]},
    "H100-SXM":  {"memory_gb": 80,  "bandwidth_gbs": 3350, "fp16_tflops": 989, "price_hr": 4.50, "fp8": True, "nvlink": True,
                  "mig": [["1g.10gb", 1, 10, 1, 7], ["1g.20gb", 1, 20, 2, 4], ["2g.20gb", 2, 20, 2, 3],
                          ["3g.40gb", 3, 40, 4, 2], ["4g.40gb", 4, 40, 4, 1], ["7g.80gb", 7, 80, 8, 1]]},
    "H200":      {"memory_gb": 141, "bandwidth_gbs": 4800, "fp16_tflops": 989, "price_hr": 6.00, "fp8": True, "nvlink": True,
                  "mig": [["1g.18gb", 1, 18, 1, 7], ["1g.35gb", 1, 35, 2, 4], ["2g.35gb", 2, 35, 2, 3],
                          ["3g.71gb", 3, 71, 4, 2], ["4g.71gb", 4, 71, 4, 1], ["7g.141gb", 7, 141, 8, 1]]},
}

# ---- Workloads -----------------------------------------------------------------------
# kv: layers, kv_heads, head_dim (Llama-3-style grouped-query attention).
# avg_seq_tokens: average tokens held in the KV cache per in-flight request (prompt + output so far).
# peak_output_tok_s: output tokens per second the whole service must produce at its busiest hour.
# tpot_slo_ms: the slowest acceptable gap between output tokens for each user.
# min_replicas: never fewer than this (2 = survive losing one replica).
WORKLOADS = {
    "_note": "Illustrative workloads. 'current' is what the team runs today; the planner checks it.",
    "chat-70b": {"kind": "decoder", "params": 70.6e9, "precision": "bf16",
                 "layers": 80, "kv_heads": 8, "head_dim": 128,
                 "avg_seq_tokens": 3000, "max_context": 8192,
                 "peak_output_tok_s": 1500, "tpot_slo_ms": 50, "p95_ttft_slo_ms": 2000, "min_replicas": 1,
                 "current": {"gpu": "H100-SXM", "tp": 8, "replicas": 1}},
    "chat-8b":  {"kind": "decoder", "params": 8.0e9, "precision": "bf16",
                 "layers": 32, "kv_heads": 8, "head_dim": 128,
                 "avg_seq_tokens": 2500, "max_context": 8192,
                 "peak_output_tok_s": 2400, "tpot_slo_ms": 40, "p95_ttft_slo_ms": 1500, "min_replicas": 2,
                 "current": {"gpu": "H100-SXM", "tp": 1, "replicas": 2}},
    "summarizer-7b": {"kind": "decoder", "params": 7.2e9, "precision": "bf16",
                 "layers": 32, "kv_heads": 8, "head_dim": 128,
                 "avg_seq_tokens": 4000, "max_context": 16384,
                 "peak_output_tok_s": 3000, "tpot_slo_ms": 100, "p95_ttft_slo_ms": 30000, "min_replicas": 1,
                 "current": {"gpu": "A100-80GB", "tp": 1, "replicas": 2}},
    "embed-large": {"kind": "encoder", "params": 0.335e9, "precision": "fp16",
                 "peak_tokens_s": 20000, "p95_ttft_slo_ms": 200, "min_replicas": 1,
                 "current": {"gpu": "A100-80GB", "tp": 1, "replicas": 1}},
}


def traffic(seed=4):
    """Requests/second for chat-8b, one value per minute of one day."""
    rnd = random.Random(seed)
    rows = []
    for m in range(24 * 60):
        h = m / 60
        if h < 6:
            base = 3.0
        elif h < 7:
            base = 3.0 + (h - 6) * 2.0                       # early risers
        elif h < 10:
            base = 5.0 + 27.0 * (h - 7) / 3                  # the morning ramp: 5 -> 32 req/s in 3 hours
        elif h < 12:
            base = 32.0
        elif h < 13:
            base = 26.0                                      # lunch dip
        elif h < 18:
            base = 30.0
        elif h < 22:
            base = 30.0 - 22.0 * (h - 18) / 4                # evening wind-down
        else:
            base = 8.0 - 5.0 * (h - 22) / 2
        if 14 * 60 <= m < 14 * 60 + 25:                      # sudden spike: a launch email goes out at 14:00
            base *= 1.6 if m < 14 * 60 + 15 else 1.3
        rps = max(0.5, base * (1 + rnd.gauss(0, 0.05)))
        rows.append({"minute": m, "time": f"{m // 60:02d}:{m % 60:02d}", "rps": round(rps, 2)})
    return rows


def main():
    with open(os.path.join(HERE, "gpus.json"), "w") as f:
        json.dump(GPUS, f, indent=1)
        f.write("\n")
    with open(os.path.join(HERE, "workloads.json"), "w") as f:
        json.dump(WORKLOADS, f, indent=1)
        f.write("\n")
    rows = traffic()
    with open(os.path.join(HERE, "traffic_24h.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    print("wrote data/gpus.json, data/workloads.json, data/traffic_24h.csv "
          f"({len(rows)} minutes, peak {max(r['rps'] for r in rows):.1f} req/s)")


if __name__ == "__main__":
    main()
