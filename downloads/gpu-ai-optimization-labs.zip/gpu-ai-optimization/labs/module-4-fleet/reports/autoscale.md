# Autoscaling replay

Trace `data/traffic_24h.csv`: peak 54.0 req/s. 5 req/s per replica at SLO, cold start 5 min, p95 TTFT SLO 1.5 s, $3.00/GPU-hour (example).

| Policy | SLO-violation minutes | Worst p95 TTFT (est.) | Peak queue (requests) | Spike reaction | GPU-hours | Cost/day |
|---|---:|---:|---:|---:|---:|---:|
| static | 22 | 66.8 s | 2,981 | never | 216.0 | $648.00 |
| cpu | 5 | 5.3 s | 237 | 7 min | 146.5 | $439.60 |
| queue | 5 | 69.5 s | 2,755 | 0 min | 127.0 | $381.10 |
| queue+ | 3 | 5.3 s | 237 | 0 min | 155.7 | $467.05 |

## Change one thing

- cpu -> queue: SLO minutes 5 -> 5 (+0), GPU-hours 146.5 -> 127.0 (-13.3%)
- queue -> queue+: SLO minutes 5 -> 3 (-2), GPU-hours 127.0 -> 155.7 (+22.6%)
- static -> queue+: SLO minutes 22 -> 3 (-19), GPU-hours 216.0 -> 155.7 (-27.9%)

## CPU target sensitivity

A few points of CPU target swing the cpu policy from waste to outage; the number has no user meaning.

| CPU target | SLO-violation minutes | GPU-hours |
|---:|---:|---:|
| 33% | 0 | 191.1 |
| 34% | 0 | 165.5 |
| 35% | 5 | 146.5 |
| 36% | 39 | 131.8 |
| 37% | 85 | 121.6 |

## Ready replicas at the top of each hour (and at the spike)

| Time | req/s | static | cpu | queue | queue+ |
|---|---:|---:|---:|---:|---:|
| 00:00 | 3.0 | 9 | 2 | 2 | 3 |
| 01:00 | 2.9 | 9 | 2 | 2 | 3 |
| 02:00 | 3.0 | 9 | 2 | 2 | 3 |
| 03:00 | 3.0 | 9 | 2 | 2 | 3 |
| 04:00 | 2.9 | 9 | 2 | 2 | 3 |
| 05:00 | 2.9 | 9 | 2 | 2 | 3 |
| 06:00 | 2.9 | 9 | 2 | 2 | 3 |
| 07:00 | 4.8 | 9 | 2 | 2 | 3 |
| 08:00 | 14.0 | 9 | 3 | 4 | 5 |
| 09:00 | 21.9 | 9 | 7 | 7 | 8 |
| 10:00 | 29.4 | 9 | 10 | 8 | 10 |
| 11:00 | 34.3 | 9 | 10 | 9 | 10 |
| 12:00 | 26.4 | 9 | 9 | 9 | 10 |
| 13:00 | 28.5 | 9 | 8 | 7 | 8 |
| 14:00 | 47.1 | 9 | 10 | 8 | 10 |
| 14:05 | 46.5 | 9 | 10 | 20 | 13 |
| 14:10 | 49.9 | 9 | 10 | 14 | 20 |
| 15:00 | 30.6 | 9 | 11 | 8 | 10 |
| 16:00 | 30.6 | 9 | 12 | 9 | 10 |
| 17:00 | 29.0 | 9 | 9 | 8 | 9 |
| 18:00 | 29.5 | 9 | 10 | 8 | 9 |
| 19:00 | 25.0 | 9 | 8 | 7 | 8 |
| 20:00 | 19.4 | 9 | 7 | 6 | 7 |
| 21:00 | 14.0 | 9 | 7 | 4 | 5 |
| 22:00 | 7.8 | 9 | 5 | 3 | 4 |
| 23:00 | 5.3 | 9 | 4 | 2 | 3 |

> The model is a sketch: confirm per-replica capacity with a load test (Module 6) and cold start with coldstart.py on your own image and weights.
