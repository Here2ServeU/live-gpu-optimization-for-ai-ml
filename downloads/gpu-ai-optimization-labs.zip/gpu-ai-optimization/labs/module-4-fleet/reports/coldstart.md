# Cold start breakdown

16 GB of weights, 12 GB image (slim: 5 GB). Registry 0.1 GB/s, object storage 0.2 GB/s, NVMe 2.0 GB/s, host-to-GPU 12.0 GB/s. All assumptions: measure yours.

| Scenario | node | image | weights download | load | warmup | ready | Total (s) | Minutes |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| baseline | 0 | 120 | 80 | 8 | 60 | 5 | 273 | 4.5 |
| + weights on local NVMe | 0 | 120 | 0 | 8 | 60 | 5 | 193 | 3.2 |
| + slim image | 0 | 50 | 0 | 8 | 60 | 5 | 123 | 2.0 |
| + compile cache | 0 | 50 | 0 | 8 | 15 | 5 | 78 | 1.3 |
| warm pool (running) | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0.0 |

- Biggest piece of the baseline: **image** (120 s, 44%).
- All three fixes: 273 s -> 78 s (-71%).
- Feed the simulator: `--cold-start 5` before, `--cold-start 2` after.
- Cold start is a design choice: pay in GPU idle time (warm pool) or in user wait (scale from cold).
