# Autoscaling replay

Trace `data/traffic_24h.csv`: peak 54.0 req/s. 5 req/s per replica at SLO, cold start 5 min, p95 TTFT SLO 1.5 s, $3.00/GPU-hour (example).

| Policy | SLO-violation minutes | Worst p95 TTFT (est.) | Peak queue (requests) | Spike reaction | GPU-hours | Cost/day |
|---|---:|---:|---:|---:|---:|---:|
| queue+ | 3 | 5.3 s | 237 | 0 min | 155.7 | $467.05 |

## Ready replicas at the top of each hour (and at the spike)

| Time | req/s | queue+ |
|---|---:|---:|
| 00:00 | 3.0 | 3 |
| 01:00 | 2.9 | 3 |
| 02:00 | 3.0 | 3 |
| 03:00 | 3.0 | 3 |
| 04:00 | 2.9 | 3 |
| 05:00 | 2.9 | 3 |
| 06:00 | 2.9 | 3 |
| 07:00 | 4.8 | 3 |
| 08:00 | 14.0 | 5 |
| 09:00 | 21.9 | 8 |
| 10:00 | 29.4 | 10 |
| 11:00 | 34.3 | 10 |
| 12:00 | 26.4 | 10 |
| 13:00 | 28.5 | 8 |
| 14:00 | 47.1 | 10 |
| 14:05 | 46.5 | 13 |
| 14:10 | 49.9 | 20 |
| 15:00 | 30.6 | 10 |
| 16:00 | 30.6 | 10 |
| 17:00 | 29.0 | 9 |
| 18:00 | 29.5 | 9 |
| 19:00 | 25.0 | 8 |
| 20:00 | 19.4 | 7 |
| 21:00 | 14.0 | 5 |
| 22:00 | 7.8 | 4 |
| 23:00 | 5.3 | 3 |

> The model is a sketch: confirm per-replica capacity with a load test (Module 6) and cold start with coldstart.py on your own image and weights.
