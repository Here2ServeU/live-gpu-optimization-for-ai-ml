# Cold start breakdown

141 GB of weights, 12 GB image (slim: 5 GB). Registry 0.1 GB/s, object storage 0.2 GB/s, NVMe 2.0 GB/s, host-to-GPU 12.0 GB/s. All assumptions: measure yours.

| Scenario | node | image | weights download | load | warmup | ready | Total (s) | Minutes |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| baseline | 0 | 120 | 705 | 70 | 60 | 5 | 960 | 16.0 |
| + weights on local NVMe | 0 | 120 | 0 | 70 | 60 | 5 | 256 | 4.3 |
| + slim image | 0 | 50 | 0 | 70 | 60 | 5 | 186 | 3.1 |
| + compile cache | 0 | 50 | 0 | 70 | 15 | 5 | 140 | 2.3 |
| warm pool (running) | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0.0 |

- Biggest piece of the baseline: **weights** (705 s, 73%).
- All three fixes: 960 s -> 140 s (-85%).
- Feed the simulator: `--cold-start 17` before, `--cold-start 3` after.
- Cold start is a design choice: pay in GPU idle time (warm pool) or in user wait (scale from cold).
