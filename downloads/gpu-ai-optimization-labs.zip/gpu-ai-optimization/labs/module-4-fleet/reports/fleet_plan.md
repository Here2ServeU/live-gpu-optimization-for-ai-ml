# Fleet plan

Assumptions: memory util 0.9, bandwidth efficiency 0.7, compute efficiency 0.5 (encoders 0.4); MIG on. Prices are examples. A planning ceiling, not a benchmark: confirm the winner with a load test.

## chat-70b

70.6B, bf16, peak 1,500 tokens/s, TPOT SLO 50 ms, min replicas 1.

| Option (one replica) | Fleet uses | Batch | Limited by | Tokens/s per replica | Peak load | $/hour | $/1M tokens (full replica) |
|---|---:|---:|---|---:|---:|---:|---:|
| H200 TP2 | 2 GPUs | 111 | memory | 2,682 | 56% | $12.00 | $1.243 |
| A100-80GB TP4 | 4 GPUs | 117 | TPOT SLO | 2,346 | 64% | $12.00 | $1.421 |
| H100-SXM TP4 | 4 GPUs | 143 | memory | 4,284 | 35% | $18.00 | $1.167 |
| H200 TP4 | 4 GPUs | 256 | memory | 7,882 | 19% | $24.00 | $0.846 |
| A100-80GB TP8 | 8 GPUs | 256 | TPOT SLO | 6,697 | 22% | $24.00 | $0.996 |

**Current:** 1 x H100-SXM TP8, $36.00/hour, peak load 14%.
- over-provisioned: at peak it uses only 14% of the capacity it pays for
- today's fleet costs 3.0x the cheapest fit (1 x H200 TP2)
- TP8 is more parallelism than the SLO needs; TP2 meets it

## chat-8b

8B, bf16, peak 2,400 tokens/s, TPOT SLO 40 ms, min replicas 2.

| Option (one replica) | Fleet uses | Batch | Limited by | Tokens/s per replica | Peak load | $/hour | $/1M tokens (full replica) |
|---|---:|---:|---|---:|---:|---:|---:|
| H100-SXM 3g.40gb | 2 slices | 56 | memory | 1,911 | 63% | $4.50 | $0.327 |
| H200 1g.35gb | 3 slices | 42 | memory | 1,185 | 67% | $4.50 | $0.352 |
| A100-80GB 3g.40gb | 3 slices | 38 | TPOT SLO | 953 | 84% | $4.50 | $0.437 |
| H200 3g.71gb | 2 slices | 141 | memory | 3,808 | 32% | $6.00 | $0.219 |
| A100-80GB | 2 GPUs | 125 | TPOT SLO | 3,132 | 38% | $6.00 | $0.266 |

**Current:** 2 x H100-SXM, $9.00/hour, peak load 22%.
- over-provisioned: at peak it uses only 22% of the capacity it pays for
- today's fleet costs 2.0x the cheapest fit (2 x H100-SXM 3g.40gb)
- small model: pack it into MIG 3g.40gb slices, not whole GPUs; spread replicas across nodes

## summarizer-7b

7.2B, bf16, peak 3,000 tokens/s, TPOT SLO 100 ms, min replicas 1.

| Option (one replica) | Fleet uses | Batch | Limited by | Tokens/s per replica | Peak load | $/hour | $/1M tokens (full replica) |
|---|---:|---:|---|---:|---:|---:|---:|
| H100-SXM | 1 GPU | 107 | memory | 3,559 | 84% | $4.50 | $0.351 |
| H200 | 1 GPU | 211 | memory | 5,671 | 53% | $6.00 | $0.294 |
| H200 3g.71gb | 2 slices | 91 | memory | 2,461 | 61% | $6.00 | $0.339 |
| A100-80GB TP2 | 2 GPUs | 241 | memory | 4,399 | 68% | $6.00 | $0.379 |
| A100-80GB | 2 GPUs | 107 | memory | 2,166 | 69% | $6.00 | $0.385 |

**Current:** 2 x A100-80GB, $6.00/hour, peak load 69%.
- today's fleet costs 1.3x the cheapest fit (1 x H100-SXM)

## embed-large

0.335B, fp16, peak 20,000 tokens/s, encoder.

| Option (one replica) | Fleet uses | Batch | Limited by | Tokens/s per replica | Peak load | $/hour | $/1M tokens (full replica) |
|---|---:|---:|---|---:|---:|---:|---:|
| A100-80GB 1g.10gb | 1 slice | - | compute | 26,610 | 75% | $0.43 | $0.004 |
| H100-SXM 1g.10gb | 1 slice | - | compute | 84,350 | 24% | $0.64 | $0.002 |
| L4 | 1 GPU | - | compute | 72,239 | 28% | $0.80 | $0.003 |
| H200 1g.18gb | 1 slice | - | compute | 84,350 | 24% | $0.86 | $0.003 |
| A100-80GB 2g.20gb | 1 slice | - | compute | 53,220 | 38% | $1.00 | $0.005 |

**Current:** 1 x A100-80GB, $3.00/hour, peak load 11%.
- over-provisioned: at peak it uses only 11% of the capacity it pays for
- today's fleet costs 7.0x the cheapest fit (1 x A100-80GB 1g.10gb)
- small model: pack it into MIG 1g.10gb slices, not whole GPUs

## Fleet summary

| Workload | Today | $/hr | Planned | $/hr | Change |
|---|---|---:|---|---:|---:|
| chat-70b | 1 x H100-SXM TP8 | $36.00 | 1 x H200 TP2 | $12.00 | -67% |
| chat-8b | 2 x H100-SXM | $9.00 | 2 x H100-SXM 3g.40gb | $4.50 | -50% |
| summarizer-7b | 2 x A100-80GB | $6.00 | 1 x H100-SXM | $4.50 | -25% |
| embed-large | 1 x A100-80GB | $3.00 | 1 x A100-80GB 1g.10gb | $0.43 | -86% |
| **Total** | | **$54.00** | | **$21.43** | **-60%** |

Savings at peak sizing: $23,777.14 per month (730 hours). Autoscaling (Stage 3) removes more by not running peak capacity all day.

> Re-run this every quarter: prices, models and traffic all move.
