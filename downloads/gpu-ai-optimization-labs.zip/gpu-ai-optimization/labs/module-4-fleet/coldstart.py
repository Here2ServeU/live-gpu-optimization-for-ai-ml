#!/usr/bin/env python3
"""
Module 4 · Stage 4 — Where does a cold start go?

A new inference replica is not useful until five things have happened, one after another:

  0. a GPU node exists           (only if the cluster autoscaler must add one: often minutes)
  1. the container image is pulled and unpacked     image GB / registry bandwidth
  2. the weights are on the node                   weights GB / object-storage bandwidth
  3. the weights are loaded into GPU memory        weights GB / min(local read, host-to-GPU)
  4. the engine warms up                           CUDA graph capture, compilation, a test request
  5. the readiness probe passes                    on average half a probe period

This script adds them up for your numbers, then applies the usual fixes one at a time,
cumulatively, so you can see which fix buys the most:

  cache weights on local NVMe (or a nearby volume)  -> step 2 disappears; step 3 reads from NVMe
  slim image, pre-pulled on GPU nodes               -> step 1 shrinks
  compile cache + warm-up before readiness          -> step 4 shrinks
  warm pool                                         -> the user waits for none of it (you pay for idle GPUs)

Every bandwidth here is an assumption with a flag. Measure yours: time `docker pull`,
time a weights download, and read the engine's own startup log.

Usage:
  python3 coldstart.py                          # 8B model, 16 GB of BF16 weights
  python3 coldstart.py --weights-gb 141         # 70B model: the weights dominate
  python3 coldstart.py --new-node               # include adding a GPU node
"""
import argparse, math, os


def breakdown(a, weights_cached=False, image_gb=None, compile_s=None, warm=False):
    image_gb = a.image_gb if image_gb is None else image_gb
    compile_s = a.compile_s if compile_s is None else compile_s
    if warm:
        return {"node": 0, "image": 0, "download": 0, "load": 0, "warmup": 0, "ready": 0}
    load_src = a.nvme_gbs if weights_cached else a.local_gbs
    return {
        "node": a.node_s if a.new_node else 0,
        "image": image_gb / a.registry_gbs,
        "download": 0 if weights_cached else a.weights_gb / a.object_gbs,
        "load": a.weights_gb / min(load_src, a.pcie_gbs) / a.format_factor,
        "warmup": compile_s,
        "ready": a.probe_s / 2,
    }


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--image-gb", type=float, default=12, help="inference image size (CUDA + PyTorch + engine)")
    ap.add_argument("--slim-image-gb", type=float, default=5, help="image after trimming build tools and extras")
    ap.add_argument("--weights-gb", type=float, default=16, help="model weights (8B BF16 = 16 GB)")
    ap.add_argument("--registry-gbs", type=float, default=0.10, help="effective pull + unpack GB/s")
    ap.add_argument("--object-gbs", type=float, default=0.20, help="object storage download GB/s")
    ap.add_argument("--local-gbs", type=float, default=2.0, help="read from local disk after download GB/s")
    ap.add_argument("--nvme-gbs", type=float, default=2.0, help="read from a local NVMe weights cache GB/s")
    ap.add_argument("--pcie-gbs", type=float, default=12.0, help="effective host-to-GPU copy GB/s")
    ap.add_argument("--format-factor", type=float, default=1.0,
                    help="1.0 for safetensors (memory-mapped); try 0.4 for pickled .bin checkpoints")
    ap.add_argument("--compile-s", type=float, default=60, help="warm-up: CUDA graphs, compilation, first request")
    ap.add_argument("--cached-compile-s", type=float, default=15, help="warm-up with a compile cache")
    ap.add_argument("--probe-s", type=float, default=10, help="readiness probe period")
    ap.add_argument("--new-node", action="store_true", help="the cluster must add a GPU node first")
    ap.add_argument("--node-s", type=float, default=240, help="time to add a GPU node (cloud + driver + device plugin)")
    ap.add_argument("--out", default=os.path.join("reports", "coldstart.md"))
    a = ap.parse_args()

    steps = [
        ("baseline", breakdown(a)),
        ("+ weights on local NVMe", breakdown(a, weights_cached=True)),
        ("+ slim image", breakdown(a, weights_cached=True, image_gb=a.slim_image_gb)),
        ("+ compile cache", breakdown(a, weights_cached=True, image_gb=a.slim_image_gb,
                                                        compile_s=a.cached_compile_s)),
        ("warm pool (running)", breakdown(a, warm=True)),
    ]
    cols = ["node", "image", "download", "load", "warmup", "ready"]
    print(f"\nCold start for {a.weights_gb:g} GB of weights, {a.image_gb:g} GB image"
          + (", new GPU node" if a.new_node else "") + "  (seconds)")
    label = {"download": "weights"}   # the weights download
    print(f"  {'scenario':23s}" + "".join(f"{label.get(c, c):>8s}" for c in cols) + f"{'total':>7s}{'min':>6s}")
    md = ["# Cold start breakdown", "",
          f"{a.weights_gb:g} GB of weights, {a.image_gb:g} GB image (slim: {a.slim_image_gb:g} GB). "
          f"Registry {a.registry_gbs} GB/s, object storage {a.object_gbs} GB/s, NVMe {a.nvme_gbs} GB/s, "
          f"host-to-GPU {a.pcie_gbs} GB/s. All assumptions: measure yours." + (" Includes adding a GPU node." if a.new_node else ""), "",
          "| Scenario | " + " | ".join({"download": "weights download"}.get(c, c) for c in cols) + " | Total (s) | Minutes |", "|---|" + "---:|" * (len(cols) + 2)]
    base = sum(steps[0][1].values())
    for name, b in steps:
        tot = sum(b.values())
        print(f"  {name:23s}" + "".join(f"{b[c]:8.0f}" for c in cols) + f"{tot:7.0f}{tot/60:6.1f}")
        md.append(f"| {name} | " + " | ".join(f"{b[c]:.0f}" for c in cols) + f" | {tot:.0f} | {tot/60:.1f} |")
    b0 = steps[0][1]
    biggest = max(b0, key=b0.get)
    fixed = sum(steps[3][1].values())
    print(f"\n  biggest piece of the baseline: {label.get(biggest, biggest)} ({b0[biggest]:.0f} s, {b0[biggest]/base:.0%})")
    print(f"  all three fixes: {base:.0f} s -> {fixed:.0f} s ({fixed/base-1:+.0%})")
    print(f"  for autoscale_sim.py: --cold-start {math.ceil(base/60)} before, --cold-start {math.ceil(fixed/60)} after")
    print("  a warm pool hides all of it, at the price of GPUs that wait.\n")
    md += ["", f"- Biggest piece of the baseline: **{label.get(biggest, biggest)}** ({b0[biggest]:.0f} s, {b0[biggest]/base:.0%}).",
           f"- All three fixes: {base:.0f} s -> {fixed:.0f} s ({fixed/base-1:+.0%}).",
           f"- Feed the simulator: `--cold-start {math.ceil(base/60)}` before, `--cold-start {math.ceil(fixed/60)}` after.",
           "- Cold start is a design choice: pay in GPU idle time (warm pool) or in user wait (scale from cold)."]
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    with open(a.out, "w") as f:
        f.write("\n".join(md) + "\n")
    print(f"wrote {a.out}\n")


if __name__ == "__main__":
    main()
