#!/usr/bin/env python3
"""
Module 4 · Stage 2 — The fleet planner: right-size the GPU for every workload.

For each workload it asks four questions, in order, for every GPU, tensor-parallel
(TP) size and MIG slice in data/gpus.json:

  1. Does it FIT?      usable memory  = GPU memory x 0.90 - 1.5 GB per GPU (runtime, activations)
                       it must hold the weights + the KV cache for at least one request at max context.
  2. How big a batch?  the largest batch that (a) fits in KV-cache memory and (b) still meets the
                       per-user speed SLO (time per output token, TPOT). Capped at 256 sequences.
  3. How fast?         decode is memory-bound, so one step reads the weights once plus each request's
                       KV cache:  step time = bytes read / (bandwidth x efficiency)
                       (or the compute time, if that is larger). Tokens/s = batch / step time.
  4. What does it cost? replicas = ceil(peak tokens/s / tokens/s per replica), at least min_replicas.
                       $/hour = replicas x GPUs per replica x price. $/1M tokens at peak load.

Assumptions (say them out loud in an interview; change them with flags):
  * memory-bandwidth efficiency 0.70 of spec, compute efficiency 0.50 (0.40 for encoders)
  * tensor parallel costs 10% over NVLink, 30% over PCIe; TP sizes 1, 2, 4, 8
  * a MIG slice gets (memory slices / 8) of the bandwidth and (compute slices / 7) of the FLOPs;
    its price is the GPU price / instances per GPU (you pack the GPU with identical slices)
  * MIG slices are never used for tensor parallel (MIG instances do not talk to each other)
  * prices are EXAMPLE on-demand prices. Use yours. Prefill and queueing are not modeled here;
    the autoscaler (Stage 3) and a real load test (Module 6) cover them.

This is a planning ceiling, not a benchmark. Its job is to rank options and catch waste.

Usage:
  python3 fleet_planner.py                       # all workloads, writes reports/fleet_plan.md
  python3 fleet_planner.py --workload chat-8b    # one workload, every option
  python3 fleet_planner.py --no-mig              # what you would buy without GPU sharing
  python3 fleet_planner.py --workload chat-8b --no-mig --tpot-ms 80   # a looser SLO changes the GPU
"""
import argparse, json, math, os

HERE = os.path.dirname(os.path.abspath(__file__))
BYTES = {"fp32": 4, "bf16": 2, "fp16": 2, "fp8": 1, "int8": 1, "int4": 0.5}
GB = 1e9


def load(name):
    d = json.load(open(os.path.join(HERE, "data", name)))
    d.pop("_note", None)
    return d


def options(gpus, use_mig=True):
    """Every way to build one replica: (label, gpu name, tp, mem GB, bw GB/s, TFLOPS per unit, $/hr per unit)."""
    out = []
    for name, g in gpus.items():
        for tp in (1, 2, 4, 8):
            out.append({"label": name if tp == 1 else f"{name} TP{tp}", "gpu": name, "tp": tp, "mig": None,
                        "mem": g["memory_gb"], "bw": g["bandwidth_gbs"], "tflops": g["fp16_tflops"],
                        "price": g["price_hr"], "nvlink": g["nvlink"]})
        if use_mig:
            for prof, cs, mem, ms, inst in g["mig"]:
                if cs == 7:          # 7g = the whole GPU; already covered above
                    continue
                out.append({"label": f"{name} {prof}", "gpu": name, "tp": 1, "mig": prof,
                            "mem": mem, "bw": g["bandwidth_gbs"] * ms / 8, "tflops": g["fp16_tflops"] * cs / 7,
                            "price": g["price_hr"] / inst, "nvlink": False})
    return out


def eff_mem(o, a):
    return a.mem_eff * (1.0 if o["tp"] == 1 else (0.9 if o["nvlink"] else 0.7))


def plan_decoder(w, o, a, replicas=None):
    """Return a dict describing the best replica on option o, or None + reason."""
    tp = o["tp"]
    weights = w["params"] * BYTES[w["precision"]] / GB                              # GB
    kv_tok = 2 * w["layers"] * w["kv_heads"] * w["head_dim"] * 2 / GB               # GB per token (16-bit KV)
    kv_seq = kv_tok * w["avg_seq_tokens"]
    usable = (o["mem"] * a.mem_util - 1.5) * tp
    free = usable - weights
    if free < kv_tok * w["max_context"]:
        return None, "does not fit" if free < 0 else "no room for KV cache"
    bw = o["bw"] * tp * eff_mem(o, a)                                                # GB/s
    flops = o["tflops"] * 1e12 * tp * a.compute_eff
    tpot = w["tpot_slo_ms"] / 1000

    def step(b):
        return max((weights + b * kv_seq) / bw, 2 * w["params"] * b / flops)

    b_mem = int(free // kv_seq)
    b_slo = int(min((tpot * bw - weights) / kv_seq, tpot * flops / (2 * w["params"])))
    if b_slo < 1:
        return None, f"too slow: {step(1)*1000:.0f} ms/token at batch 1 > {w['tpot_slo_ms']} ms SLO"
    b = max(1, min(b_mem, b_slo, 256))
    per_rep = b / step(b)
    need = w["peak_output_tok_s"]
    n = replicas or max(w["min_replicas"], math.ceil(need / per_rep))
    cost_hr = n * tp * o["price"]
    return {"label": o["label"], "gpus": n * tp, "replicas": n, "batch": b,
            "bound": "memory" if b_mem <= b_slo else "TPOT SLO",
            "step_ms": step(b) * 1000, "tok_s_replica": per_rep, "capacity": n * per_rep,
            "load": need / (n * per_rep), "cost_hr": cost_hr,
            "usd_per_1m_capacity": tp * o["price"] / (per_rep * 3600) * 1e6,
            "usd_per_1m_peak": cost_hr / (need * 3600) * 1e6,
            "weights_share": weights / (o["mem"] * tp), "mig": o["mig"], "tp": tp}, ""


def plan_encoder(w, o, a, replicas=None):
    weights = w["params"] * BYTES[w["precision"]] / GB
    if o["tp"] > 1:
        return None, "no TP for a small encoder"
    if weights + 2.0 > o["mem"] * a.mem_util:
        return None, "does not fit"
    per_rep = o["tflops"] * 1e12 * a.encoder_eff / (2 * w["params"])
    need = w["peak_tokens_s"]
    n = replicas or max(w["min_replicas"], math.ceil(need / per_rep))
    cost_hr = n * o["price"]
    return {"label": o["label"], "gpus": n, "replicas": n, "batch": "-", "bound": "compute",
            "step_ms": 0, "tok_s_replica": per_rep, "capacity": n * per_rep, "load": need / (n * per_rep),
            "cost_hr": cost_hr, "usd_per_1m_capacity": o["price"] / (per_rep * 3600) * 1e6,
            "usd_per_1m_peak": cost_hr / (need * 3600) * 1e6,
            "weights_share": weights / o["mem"], "mig": o["mig"], "tp": 1}, ""


def plan(w, opts, a):
    fn = plan_decoder if w["kind"] == "decoder" else plan_encoder
    ok, bad = [], []
    for o in opts:
        r, why = fn(w, o, a)
        (ok.append(r) if r else bad.append((o["label"], why)))
    ok.sort(key=lambda r: (r["cost_hr"], r["usd_per_1m_capacity"]))
    cur = w["current"]
    co = next(o for o in opts if o["gpu"] == cur["gpu"] and o["tp"] == cur["tp"] and o["mig"] is None)
    current, why = fn(w, co, a, replicas=cur["replicas"])
    return ok, bad, current, why


def flags(name, w, cur, best):
    out = []
    if cur is None or best is None:
        return out
    if cur["load"] < 0.5:
        out.append(f"over-provisioned: at peak it uses only {cur['load']:.0%} of the capacity it pays for")
    if cur["cost_hr"] >= 1.3 * best["cost_hr"]:
        out.append(f"today's fleet costs {cur['cost_hr']/best['cost_hr']:.1f}x the cheapest fit ({fleet(best)})")
    if best["mig"]:
        out.append(f"small model: pack it into MIG {best['mig']} slices, not whole GPUs"
                   + ("; spread replicas across nodes" if best["replicas"] > 1 else ""))
    if cur["tp"] > 1 and best["tp"] < cur["tp"]:
        out.append(f"TP{cur['tp']} is more parallelism than the SLO needs; TP{best['tp']} meets it")
    return out


def units(r):
    return f"{r['gpus']} slice" + ("s" if r["gpus"] > 1 else "") if r["mig"] else f"{r['gpus']} GPU" + ("s" if r["gpus"] > 1 else "")


def fleet(r):
    return f"{r['replicas']} x {r['label']}"


def money(x):
    return f"${x:,.2f}"


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--workload", help="plan one workload and print every option")
    ap.add_argument("--no-mig", action="store_true", help="whole GPUs only")
    ap.add_argument("--tpot-ms", type=float, help="override the TPOT SLO (with --workload) to see the SLO pick the GPU")
    ap.add_argument("--mem-util", type=float, default=0.90, help="share of GPU memory the server may use (vLLM default 0.9)")
    ap.add_argument("--mem-eff", type=float, default=0.70, help="share of spec bandwidth real kernels reach")
    ap.add_argument("--compute-eff", type=float, default=0.50)
    ap.add_argument("--encoder-eff", type=float, default=0.40)
    ap.add_argument("--top", type=int, default=5)
    ap.add_argument("--out", default=os.path.join("reports", "fleet_plan.md"))
    a = ap.parse_args()

    gpus, wl = load("gpus.json"), load("workloads.json")
    opts = options(gpus, use_mig=not a.no_mig)
    names = [a.workload] if a.workload else list(wl)
    if a.tpot_ms:
        if not a.workload:
            ap.error("--tpot-ms needs --workload")
        wl[a.workload]["tpot_slo_ms"] = a.tpot_ms
    top = 99 if a.workload else a.top

    md = ["# Fleet plan", "",
          f"Assumptions: memory util {a.mem_util}, bandwidth efficiency {a.mem_eff}, compute efficiency {a.compute_eff} "
          f"(encoders {a.encoder_eff}); MIG {'off' if a.no_mig else 'on'}. Prices are examples. "
          "A planning ceiling, not a benchmark: confirm the winner with a load test.", ""]
    tot_cur = tot_new = 0.0
    summary = []
    for name in names:
        w = wl[name]
        ok, bad, cur, cur_why = plan(w, opts, a)
        best = ok[0] if ok else None
        demand = w.get("peak_output_tok_s") or w.get("peak_tokens_s")
        print(f"\n{name}  ({w['params']/1e9:g}B {w['precision']}, peak {demand:,} tok/s"
              + (f", TPOT SLO {w['tpot_slo_ms']} ms)" if w["kind"] == "decoder" else ", encoder)"))
        print(f"  {'option (one replica)':24s} {'uses':>9s} {'batch':>5s} {'limit':>8s} {'tok/s/rep':>9s} {'load':>5s} "
              f"{'$/hr':>7s} {'$/1M cap':>8s}")
        md += [f"## {name}", "",
               f"{w['params']/1e9:g}B, {w['precision']}, peak {demand:,} tokens/s"
               + (f", TPOT SLO {w['tpot_slo_ms']} ms, min replicas {w['min_replicas']}." if w["kind"] == "decoder" else ", encoder."), "",
               "| Option (one replica) | Fleet uses | Batch | Limited by | Tokens/s per replica | Peak load | $/hour | $/1M tokens (full replica) |",
               "|---|---:|---:|---|---:|---:|---:|---:|"]
        for r in ok[:top]:
            print(f"  {r['label']:24s} {units(r):>9s} {str(r['batch']):>5s} {r['bound']:>8s} {r['tok_s_replica']:9,.0f} "
                  f"{r['load']:5.0%} {r['cost_hr']:7.2f} {r['usd_per_1m_capacity']:8.3f}")
            md.append(f"| {r['label']} | {units(r)} | {r['batch']} | {r['bound']} | {r['tok_s_replica']:,.0f} | "
                      f"{r['load']:.0%} | {money(r['cost_hr'])} | ${r['usd_per_1m_capacity']:.3f} |")
        if a.workload and bad:
            print("  not feasible: " + "; ".join(f"{l} ({why})" for l, why in bad))
        if cur:
            print(f"  current: {fleet(cur)} = {money(cur['cost_hr'])}/hr, peak load {cur['load']:.0%}")
        else:
            print(f"  current: {w['current']} -> {cur_why}")
        fl = flags(name, w, cur, best)
        for f in fl:
            print(f"    ! {f}")
        if best and cur:
            save = 1 - best["cost_hr"] / cur["cost_hr"]
            print(f"  plan:    {fleet(best)} = {money(best['cost_hr'])}/hr  ({-save:+.0%})")
            tot_cur += cur["cost_hr"]; tot_new += best["cost_hr"]
            summary.append((name, fleet(cur), cur["cost_hr"], fleet(best), best["cost_hr"]))
        md += ["", f"**Current:** {fleet(cur)}, {money(cur['cost_hr'])}/hour, peak load {cur['load']:.0%}."
               if cur else f"**Current:** {w['current']} is not feasible ({cur_why})."]
        md += [f"- {f}" for f in fl] + [""]

    if summary:
        print(f"\nFLEET  current {money(tot_cur)}/hr -> planned {money(tot_new)}/hr  "
              f"({tot_new/tot_cur-1:+.0%}, {money((tot_cur-tot_new)*730)}/month at 730 h)")
        md += ["## Fleet summary", "", "| Workload | Today | $/hr | Planned | $/hr | Change |", "|---|---|---:|---|---:|---:|"]
        for n, c, cc, b, bc in summary:
            md.append(f"| {n} | {c} | {money(cc)} | {b} | {money(bc)} | {bc/cc-1:+.0%} |")
        md += [f"| **Total** | | **{money(tot_cur)}** | | **{money(tot_new)}** | **{tot_new/tot_cur-1:+.0%}** |", "",
               f"Savings at peak sizing: {money((tot_cur-tot_new)*730)} per month (730 hours). "
               "Autoscaling (Stage 3) removes more by not running peak capacity all day.", "",
               "> Re-run this every quarter: prices, models and traffic all move."]
    print("\nA planning ceiling, not a benchmark. Confirm the winner with a load test on your prompts.")
    if not a.workload:
        os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
        with open(a.out, "w") as f:
            f.write("\n".join(md) + "\n")
        print(f"wrote {a.out}")


if __name__ == "__main__":
    main()
