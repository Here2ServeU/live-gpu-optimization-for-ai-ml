#!/usr/bin/env python3
"""
Module 4 · Stage 3 — Autoscale on what users feel.

Replays one day of traffic (data/traffic_24h.csv, requests/second per minute: quiet night,
morning ramp, a sudden spike at 14:00) against a pool of GPU replicas, minute by minute,
under different scaling policies:

  static   a fixed fleet sized for the normal daily peak (the "just buy enough" baseline)
  cpu      Kubernetes HPA on pod CPU, target 35%. CPU in a GPU inference pod is tokenizing
           and HTTP; it tracks work SERVED, which stops rising once the GPU is full,
           so it reacts late and weakly.
  queue    KEDA on in-flight requests per replica (vLLM running + waiting), target 80% of
           what one replica can hold. Backlog shows up here first.
  queue+   same signal, plus one warm spare replica and a 15-minute scale-in cooldown.

The model, kept deliberately small:
  * a replica serves up to --capacity req/s while meeting the p95 TTFT SLO (from a load test)
  * a new replica pays for its GPU at once but serves only after --cold-start minutes
  * requests above capacity wait in a queue; estimated p95 TTFT = base TTFT + time to drain
    the queue. A minute with estimated p95 TTFT above the SLO is an SLO-violation minute.
  * in-flight requests follow Little's law: running = served rate x --service-s seconds
  * the controller re-evaluates every minute; scale-in waits for a stabilization window
    (5 minutes, the HPA default; 15 for queue+)

Deterministic: the trace is fixed and the CPU noise is seeded.

Usage:
  python3 autoscale_sim.py                     # all policies, writes reports/autoscale.md
  python3 autoscale_sim.py --cold-start 2      # what caching weights on NVMe buys you
  python3 autoscale_sim.py --policy queue+ --timeline
"""
import argparse, csv, math, os, random

HERE = os.path.dirname(os.path.abspath(__file__))


def load_trace(path):
    with open(path, newline="") as f:
        return [(int(r["minute"]), r["time"], float(r["rps"])) for r in csv.DictReader(f)]


def simulate(trace, policy, a):
    rnd = random.Random(11)
    cap = a.capacity                                   # req/s per ready replica at SLO
    per_replica_target = 0.8 * cap * a.service_s       # in-flight requests per replica the scaler aims for
    lo = a.min_replicas
    spare = a.spare if policy == "queue+" else 0
    window = a.cooldown if policy == "queue+" else 5   # scale-in stabilization, minutes
    if policy == "static":
        steady = sorted(r for _, t, r in trace if not ("14:00" <= t < "14:25"))
        n0 = math.ceil(steady[int(0.99 * len(steady))] / (0.8 * cap))
    else:
        n0 = lo + spare
    ready, booting = n0, []                            # booting: list of minute-when-ready
    queue = 0.0
    history = []                                       # desired replicas, for the stabilization window
    jump = max(range(1, len(trace)), key=lambda i: trace[i][2] - trace[i - 1][2])   # the spike starts here
    out = {"violations": 0, "gpu_min": 0, "peak_queue": 0.0, "worst_ttft": 0.0, "served": 0.0,
           "timeline": [], "reaction": None}
    for m, t, rps in trace:
        booting_now = [b for b in booting if b <= m]
        ready += len(booting_now)
        booting = [b for b in booting if b > m]
        # ---- serve this minute
        arrivals = rps * 60
        capacity = ready * cap * 60
        served = min(queue + arrivals, capacity)
        queue = queue + arrivals - served
        wait_s = queue / (ready * cap) if ready else 1e9
        ttft = a.base_ttft_s + wait_s
        out["served"] += served
        out["gpu_min"] += (ready + len(booting)) * a.gpus_per_replica
        out["peak_queue"] = max(out["peak_queue"], queue)
        out["worst_ttft"] = max(out["worst_ttft"], ttft)
        if ttft > a.slo_s:
            out["violations"] += 1
        # ---- what each policy sees
        total = ready + len(booting)
        if policy == "static":
            desired = n0
        elif policy == "cpu":
            # engine loop + HTTP keep a near-constant floor; tokenizing adds a little per request.
            # It follows work SERVED, so it stops rising once the GPU is full and the queue grows.
            cpu = 24 + 12 * (served / capacity if capacity else 1) + rnd.gauss(0, 2.5)
            ratio = cpu / a.cpu_target
            desired = total if abs(ratio - 1) < 0.1 else math.ceil(ready * ratio)   # HPA tolerance 10%
        else:
            in_flight = served / 60 * a.service_s + queue                         # running + waiting
            desired = math.ceil(in_flight / per_replica_target) + spare
        desired = max(lo + spare, min(a.max_replicas, desired))
        history.append(desired)
        if desired < total:                            # scale in only to the max of the window
            desired = max(history[-window:])
        # ---- act
        if desired > total:
            booting += [m + a.cold_start] * (desired - total)
            if m >= jump and out["reaction"] is None:
                out["reaction"] = m - jump
        elif desired < total:
            drop = total - desired
            while drop and booting:                    # cancel newest boots first
                booting.pop(); drop -= 1
            ready -= drop
        out["timeline"].append((t, rps, ready, len(booting), queue, ttft))
    out["gpu_hours"] = out["gpu_min"] / 60
    out["cost"] = out["gpu_hours"] * a.price
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--trace", default=os.path.join(HERE, "data", "traffic_24h.csv"))
    ap.add_argument("--policy", choices=["static", "cpu", "queue", "queue+"], help="run one policy")
    ap.add_argument("--capacity", type=float, default=5.0, help="req/s one replica serves within SLO (load-test it)")
    ap.add_argument("--cold-start", type=int, default=5, help="minutes from scale-up to serving (coldstart.py)")
    ap.add_argument("--service-s", type=float, default=10.0, help="seconds one request is in flight (~300 tokens)")
    ap.add_argument("--base-ttft-s", type=float, default=0.6, help="p95 TTFT with no queue")
    ap.add_argument("--slo-s", type=float, default=1.5, help="p95 TTFT SLO (chat-8b: 1500 ms)")
    ap.add_argument("--min-replicas", type=int, default=2)
    ap.add_argument("--cpu-target", type=float, default=35.0, help="HPA CPU target %% for the cpu policy")
    ap.add_argument("--spare", type=int, default=1, help="warm spare replicas for queue+")
    ap.add_argument("--cooldown", type=int, default=15, help="scale-in stabilization minutes for queue+")
    ap.add_argument("--max-replicas", type=int, default=20)
    ap.add_argument("--gpus-per-replica", type=int, default=1)
    ap.add_argument("--price", type=float, default=3.00, help="$/GPU-hour (example A100-80GB price)")
    ap.add_argument("--timeline", action="store_true", help="print replicas and queue every 30 minutes")
    ap.add_argument("--out", help="markdown report (default reports/autoscale.md, or reports/autoscale_<policy>.md)")
    a = ap.parse_args()
    if not a.out:
        a.out = os.path.join("reports", f"autoscale_{a.policy.replace('+', 'plus')}.md" if a.policy else "autoscale.md")

    trace = load_trace(a.trace)
    policies = [a.policy] if a.policy else ["static", "cpu", "queue", "queue+"]
    res = {p: simulate(trace, p, a) for p in policies}

    print(f"\n24h replay: peak {max(r for _, _, r in trace):.1f} req/s, {a.capacity:g} req/s per replica, "
          f"cold start {a.cold_start} min, p95 TTFT SLO {a.slo_s:g} s")
    hdr = (f"  {'policy':8s} {'SLO min':>7s} {'worst TTFT':>10s} {'peak queue':>10s} "
           f"{'reaction':>8s} {'GPU-hours':>9s} {'cost/day':>8s}")
    print(hdr)
    md = ["# Autoscaling replay", "",
          f"Trace `{os.path.relpath(a.trace, HERE)}`: peak {max(r for _, _, r in trace):.1f} req/s. "
          f"{a.capacity:g} req/s per replica at SLO, cold start {a.cold_start} min, p95 TTFT SLO {a.slo_s:g} s, "
          f"${a.price:.2f}/GPU-hour (example).", "",
          "| Policy | SLO-violation minutes | Worst p95 TTFT (est.) | Peak queue (requests) | Spike reaction | GPU-hours | Cost/day |",
          "|---|---:|---:|---:|---:|---:|---:|"]
    for p, r in res.items():
        react = "never" if r["reaction"] is None else f"{r['reaction']} min"
        print(f"  {p:8s} {r['violations']:7d} {r['worst_ttft']:9.1f}s {r['peak_queue']:10,.0f} "
              f"{react:>8s} {r['gpu_hours']:9.1f} {r['cost']:8.2f}")
        md.append(f"| {p} | {r['violations']} | {r['worst_ttft']:.1f} s | {r['peak_queue']:,.0f} | {react} | "
                  f"{r['gpu_hours']:.1f} | ${r['cost']:,.2f} |")
    print("  SLO min: minutes with p95 TTFT over the SLO.  reaction: minutes from the 14:00 jump")
    print("  in traffic to the first scale-up order.")

    def change(b, n):
        x, y = res[b], res[n]
        dv = y["violations"] - x["violations"]
        dg = (y["gpu_hours"] - x["gpu_hours"]) / x["gpu_hours"] * 100
        return (f"{b} -> {n}: SLO minutes {x['violations']} -> {y['violations']} ({dv:+d}), "
                f"GPU-hours {x['gpu_hours']:.1f} -> {y['gpu_hours']:.1f} ({dg:+.1f}%)")

    lines = []
    for b, n in (("cpu", "queue"), ("queue", "queue+"), ("static", "queue+")):
        if b in res and n in res:
            lines.append(change(b, n))
    if lines:
        print("\nCHANGE ONE THING")
        for l in lines:
            print("  " + l)
        md += ["", "## Change one thing", ""] + [f"- {l}" for l in lines]

    if "cpu" in res and not a.policy:
        sweep = []
        for t in (33, 34, 35, 36, 37):
            b = argparse.Namespace(**{**vars(a), "cpu_target": float(t)})
            r = simulate(trace, "cpu", b)
            sweep.append((t, r["violations"], r["gpu_hours"]))
        print("\nCPU TARGET SENSITIVITY (same day, cpu policy)")
        print("  CPU target " + "".join(f"{str(t) + '%':>7s}" for t, _, _ in sweep))
        print("  SLO min    " + "".join(f"{v:7d}" for _, v, _ in sweep))
        print("  GPU-hours  " + "".join(f"{g:7.0f}" for _, _, g in sweep))
        md += ["", "## CPU target sensitivity", "",
               "A few points of CPU target swing the cpu policy from waste to outage; the number has no user meaning.", "",
               "| CPU target | SLO-violation minutes | GPU-hours |", "|---:|---:|---:|"]
        md += [f"| {t}% | {v} | {g:.1f} |" for t, v, g in sweep]

    show = [a.policy] if a.policy else (["queue+"] if a.timeline else [])
    for p in show:
        if not a.timeline and a.policy:
            break
        print(f"\nTIMELINE ({p}, every 30 min)\n  time   req/s  ready  booting   queue  p95 TTFT")
        for t, rps, rd, bt, q, tt in res[p]["timeline"][::30]:
            print(f"  {t}  {rps:6.1f}  {rd:5d}  {bt:7d}  {q:6.0f}  {tt:7.1f}s")

    # hourly replicas per policy, for the report
    md += ["", "## Ready replicas at the top of each hour (and at the spike)", "",
           "| Time | req/s | " + " | ".join(res) + " |", "|---|---:|" + "---:|" * len(res)]
    marks = [h * 60 for h in range(24)] + [14 * 60 + 5, 14 * 60 + 10]
    for i in sorted(marks):
        t, rps = trace[i][1], trace[i][2]
        md.append(f"| {t} | {rps:.1f} | " + " | ".join(str(res[p]["timeline"][i][2]) for p in res) + " |")
    md += ["", "> The model is a sketch: confirm per-replica capacity with a load test (Module 6) "
               "and cold start with coldstart.py on your own image and weights."]
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    with open(a.out, "w") as f:
        f.write("\n".join(md) + "\n")
    print(f"\nwrote {a.out}\n")


if __name__ == "__main__":
    main()
