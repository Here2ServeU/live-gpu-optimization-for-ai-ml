#!/usr/bin/env python3
"""
Module 2 · data — build the task and train the "big model" (the teacher).

The task: classify 64-number "requests" into 10 intents. Think of it as a
stand-in for an LLM answering requests from your product. It is synthetic and
seeded, so everyone gets the same data, and it runs offline on a laptop.

Each intent has sixteen common "styles" of request and one RARE style (about 3% of
traffic). Rare styles stand in for the things quantization breaks first in real
LLMs: rare languages, unusual formats, long chains of reasoning. We keep a
separate rare-slice eval set so you can watch them.

What it writes (all under data/):
  dataset.npz   X/y for: train (20k, labelled), transfer (60k, UNlabelled
                "domain prompts" for distillation), val (3k), test (10k) and
                rare (3k, rare styles only)
  teacher.npz   the teacher: a 64-1024-1024-1024-10 MLP (~2.2M parameters)

Outliers, on purpose. Real LLMs develop a handful of hidden channels whose
activations are 10-100x larger than the rest. Those few channels are why naive
INT8 fails. We reproduce that EXACTLY and harmlessly: ReLU(k*z) = k*ReLU(z), so
multiplying a few neurons' incoming weights by k and their outgoing weights by
1/k leaves every answer unchanged, but creates outlier weights in layer 0 and
outlier activations going into layer 1. (SmoothQuant and AWQ use the same
identity in reverse, to move outliers somewhere harmless.)

Usage:
  python3 data/make_data.py            # ~20-60 s on a laptop
"""
import argparse, os, sys, time
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from common import init_mlp, train, forward, save_model, n_params  # noqa: E402

C, D, L, H = 10, 64, 12, 96          # classes, features, latent dims, warp width
COMMON, RARE_SHARE = 16, 0.03        # styles per class, share of traffic that is rare
OUTLIER_CHANNELS, OUTLIER_SCALE = 6, 100.0


def make_world(rng):
    centers = rng.normal(0, 1.0, (C, COMMON + 1, L)) * 1.2
    P = rng.normal(0, 1.0, (L, H)) / np.sqrt(L) * 1.6
    Q = rng.normal(0, 1.0, (H, D)) / np.sqrt(H) * 2.0
    return centers, P, Q


def sample(rng, world, n, rare_only=False):
    centers, P, Q = world
    y = rng.integers(0, C, n)
    if rare_only:
        style = np.full(n, COMMON)
    else:
        style = np.where(rng.random(n) < RARE_SHARE, COMMON, rng.integers(0, COMMON, n))
    z = centers[y, style] + rng.normal(0, 0.6, (n, L))
    x = np.tanh(z @ P) @ Q + rng.normal(0, 0.25, (n, D))
    return x.astype(np.float32), y.astype(np.int64), (style == COMMON)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--epochs", type=int, default=5)
    a = ap.parse_args()

    rng = np.random.default_rng(2)
    world = make_world(rng)
    sets = {}
    for name, n, rare_only in [("train", 20000, False), ("transfer", 60000, False), ("val", 3000, False),
                               ("test", 10000, False), ("rare", 3000, True)]:
        sets[name] = sample(rng, world, n, rare_only)
    mu = sets["train"][0].mean(0); sd = sets["train"][0].std(0)
    out = {}
    for name, (x, y, r) in sets.items():
        out[f"X_{name}"] = ((x - mu) / sd).astype(np.float32)
        if name != "transfer":                     # transfer prompts are unlabelled
            out[f"y_{name}"] = y
        out[f"rare_{name}"] = r
    np.savez_compressed(os.path.join(HERE, "dataset.npz"), **out)
    print(f"dataset: train {len(out['X_train'])} (rare {out['rare_train'].mean():.1%}), "
          f"transfer {len(out['X_transfer'])} unlabelled, val {len(out['X_val'])}, "
          f"test {len(out['X_test'])}, rare slice {len(out['X_rare'])}")

    # ---- train the teacher -------------------------------------------------
    trng = np.random.default_rng(0)
    model = init_mlp([D, 1024, 1024, 1024, C], trng)
    t0 = time.time()

    def log(ep):
        acc = (forward(model, out["X_val"]).argmax(1) == out["y_val"]).mean()
        print(f"  epoch {ep + 1}/{a.epochs}  val accuracy {acc:.1%}  ({time.time() - t0:.0f}s)")

    print(f"training teacher: {n_params(model):,} parameters")
    train(model, out["X_train"], out["y_train"], a.epochs, trng, lr=5e-4, log=log)

    # ---- inject outlier channels (function-preserving) ---------------------
    ch = np.sort(trng.choice(1024, OUTLIER_CHANNELS, replace=False))
    (W0, b0), (W1, b1) = model[0], model[1]
    before = forward(model, out["X_test"])
    W0[:, ch] *= OUTLIER_SCALE; b0[ch] *= OUTLIER_SCALE
    W1[ch, :] /= OUTLIER_SCALE
    after = forward(model, out["X_test"])
    print(f"injected {OUTLIER_CHANNELS} outlier channels x{OUTLIER_SCALE:.0f} into layer 0 "
          f"(max logit change {np.abs(after - before).max():.1e}: same model, new outliers)")

    acc = (after.argmax(1) == out["y_test"]).mean()
    racc = (forward(model, out["X_rare"]).argmax(1) == out["y_rare"]).mean()
    save_model(model, "teacher.npz")
    print(f"teacher: test accuracy {acc:.1%} | rare slice {racc:.1%} | saved data/teacher.npz")


if __name__ == "__main__":
    main()
