#!/usr/bin/env python3
"""
Module 2 · Stage 3 — Distillation: teach a small model to copy the big one.

The teacher is a 2.2M-parameter MLP. The student is a much smaller one. We train
the same student three ways and compare them on YOUR eval set:

  A. hard labels      2,000 human-labelled examples, one right answer each
                      (labels are expensive; this is a typical budget)
  B. soft labels      the same 2,000 examples, but the target is the teacher's full
                      probability distribution ("80% intent 3, 15% intent 7 ...").
                      Those near-misses carry information a single label throws away.
  C. soft labels +    B, plus 60k UNlabelled "domain prompts" that the teacher labels
     domain prompts   for free. In real LLM work this is the usual recipe: run the
                      big model on your own prompts and train the small one on its answers.

Temperature T > 1 softens the teacher's distribution so the small probabilities
are visible to the student (Hinton et al., 2015).

Writes data/student.npz (the best student, used by router.py) and reports/distill.md.

Usage:
  python3 distill.py                    # hidden width 256, T = 2
  python3 distill.py --hidden 64        # an even smaller student
  python3 distill.py --temperature 4
  python3 distill.py --labels 20000     # what if you had 10x more human labels?
"""
import argparse, time
import numpy as np
from common import (load_data, load_model, init_mlp, train, forward, softmax, scores, n_params,
                    save_model, time_many, write_report)


class _Stop(Exception):
    pass


def fit(student, X, Y, T, d, rng, max_epochs, patience=5):
    """Train until validation accuracy stops improving (early stopping), keep the best epoch."""
    best = {"acc": -1.0, "w": None, "bad": 0}
    # roughly the same number of samples per "check" for small and large training sets
    per_check = max(1, round(20000 / len(X)))

    def log(ep):
        if (ep + 1) % per_check:
            return
        acc = float((forward(student, d["X_val"]).argmax(1) == d["y_val"]).mean())
        if acc > best["acc"]:
            best.update(acc=acc, w=[(W.copy(), b.copy()) for W, b in student], bad=0)
        else:
            best["bad"] += 1
            if best["bad"] >= patience:
                raise _Stop
    try:
        train(student, X, Y, max_epochs, rng, lr=2e-3, T=T, log=log)
    except _Stop:
        pass
    for (W, b), (Wb, bb) in zip(student, best["w"]):
        W[...] = Wb; b[...] = bb


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--hidden", type=int, default=256, help="student hidden width (default 256)")
    ap.add_argument("--temperature", type=float, default=2.0)
    ap.add_argument("--labels", type=int, default=2000, help="human-labelled examples you have (default 2000)")
    ap.add_argument("--max-epochs", type=int, default=200)
    ap.add_argument("--out", default="distill.md")
    a = ap.parse_args()

    d = load_data()
    teacher = load_model("teacher.npz")
    t_acc, t_rare = scores(teacher, d)
    sizes = [d["X_train"].shape[1], a.hidden, 10]

    X_lab, y_lab = d["X_train"][:a.labels], d["y_train"][:a.labels]
    X_all = np.concatenate([X_lab, d["X_transfer"]])
    t0 = time.time()
    soft_lab = softmax(forward(teacher, X_lab), a.temperature)
    soft_all = softmax(forward(teacher, X_all), a.temperature)
    print(f"\nTeacher labelled {len(X_all):,} prompts in {time.time() - t0:.1f}s "
          f"(T={a.temperature}). Training students {sizes} ...")
    print("  (agrees = how often the student gives the same answer as the teacher)")

    k = f"{a.labels / 1000:g}k"
    runs = [(f"A  hard labels ({k})", X_lab, y_lab, 1.0),
            (f"B  soft labels ({k})", X_lab, soft_lab, a.temperature),
            (f"C  soft labels ({k}) + 60k prompts", X_all, soft_all, a.temperature)]
    t_pred = forward(teacher, d["X_test"]).argmax(1)
    Xb = d["X_test"][:64]
    results = []
    for name, X, Y, T in runs:
        rng = np.random.default_rng(1)
        student = init_mlp(sizes, rng)
        fit(student, X, Y, T, d, rng, a.max_epochs)
        acc, rare = scores(student, d)
        agree = float((forward(student, d["X_test"]).argmax(1) == t_pred).mean())
        results.append((name, student, acc, rare, agree))
        print(f"  {name:33s} accuracy {acc:5.1%}  rare {rare:5.1%}  agrees {agree:5.1%}")

    best = max(results, key=lambda r: r[2])
    t_ms, s_ms = time_many([lambda: forward(teacher, Xb), lambda: forward(best[1], Xb)], rounds=40)
    tp, sp = n_params(teacher), n_params(best[1])
    print(f"\n  {'':12s} {'params':>10s} {'FP32 MB':>8s} {'accuracy':>9s} {'rare':>7s} {'CPU ms (batch 64)':>18s}")
    print(f"  {'teacher':12s} {tp:10,d} {tp * 4 / 1e6:8.2f} {t_acc:9.1%} {t_rare:7.1%} {t_ms:18.2f}")
    print(f"  {'student ' + best[0][:1]:12s} {sp:10,d} {sp * 4 / 1e6:8.2f} {best[2]:9.1%} {best[3]:7.1%} {s_ms:18.2f}")
    print(f"\n  Student: {tp / sp:.0f}x smaller, {t_ms / s_ms:.0f}x faster, {best[2] / t_acc:.0%} of the teacher's accuracy.")
    print(f"  It gives up {(t_acc - best[2]) * 100:.1f} pts overall and {(t_rare - best[3]) * 100:.1f} pts on the rare slice.")
    gain = (results[2][2] - results[0][2]) * 100
    rgain = (results[2][3] - results[0][3]) * 100
    print(f"  Distillation (C) vs hard labels (A): {gain:+.1f} pts overall, {rgain:+.1f} pts rare.")
    save_model(best[1], "student.npz")
    print("  saved data/student.npz (used by router.py)")

    md = ["# Module 2 · Distillation report", "",
          f"Student {sizes} vs teacher [64, 1024, 1024, 1024, 10]. Temperature {a.temperature}. "
          f"Human labels: {a.labels:,}. Each student trains until validation accuracy stops improving.", "",
          "| Student training | Accuracy | Rare slice | Agrees with teacher | % of teacher accuracy |",
          "|---|---:|---:|---:|---:|"]
    md += [f"| {n} | {acc:.1%} | {rare:.1%} | {ag:.1%} | {acc / t_acc:.1%} |" for n, _, acc, rare, ag in results]
    md += ["", "| Model | Params | Size (FP32) | Accuracy | Rare slice | CPU ms (batch 64) |", "|---|---:|---:|---:|---:|---:|",
           f"| Teacher | {tp:,} | {tp * 4 / 1e6:.2f} MB | {t_acc:.1%} | {t_rare:.1%} | {t_ms:.2f} |",
           f"| Student ({best[0][:1]}) | {sp:,} | {sp * 4 / 1e6:.3f} MB | {best[2]:.1%} | {best[3]:.1%} | {s_ms:.2f} |", "",
           f"**{tp / sp:.0f}× smaller, {t_ms / s_ms:.0f}× faster, {best[2] / t_acc:.0%} of the teacher's accuracy.** "
           f"The rare slice loses more ({(t_rare - best[3]) * 100:.1f} pts): check it before you ship.", "",
           "Note: the student is evaluated against the same eval set as the teacher, not a generic benchmark."]
    print(f"\nwrote {write_report(a.out, md)}")


if __name__ == "__main__":
    main()
