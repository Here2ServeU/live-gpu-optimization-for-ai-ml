#!/usr/bin/env python3
"""
Module 2 · Stage 4 — Pruning: smaller on paper vs. faster in practice.

Three ways to remove weights from the teacher's two big hidden layers
(1024 x 1024 each, 97% of all weights):

  1. Unstructured   zero out the smallest individual weights (50%, 70%, 90%).
                    The matrix keeps its shape, so a dense matmul does exactly
                    the same work: smaller on paper, NOT faster on dense hardware.
  2. 2:4 sparsity   in every group of 4 weights, keep the 2 largest. NVIDIA
                    Ampere-and-later sparse tensor cores can skip the zeros
                    (often up to ~2x on the matmul itself). A CPU cannot, so here
                    we measure quality only.
  3. Structured     remove whole neurons (columns of one layer + rows of the next).
                    The matrices really get smaller, so it really gets faster.
                    Then fine-tune briefly to win back accuracy: prune, then heal.

The lesson: count milliseconds, not parameters.

Usage:
  python3 prune.py                       # all three, writes reports/prune.md
  python3 prune.py --finetune-epochs 0   # skip the healing step
"""
import argparse
import numpy as np
from common import load_data, load_model, forward, scores, n_params, train, time_many, write_report

HIDDEN = (1, 2)   # the 1024x1024 layers


def copy(model):
    return [(W.copy(), b.copy()) for W, b in model]


def unstructured(model, frac):
    m = copy(model)
    for i in HIDDEN:
        W = m[i][0]
        cut = np.quantile(np.abs(W), frac)
        W[np.abs(W) < cut] = 0.0
    return m


def two_four(model):
    """Keep the 2 largest-magnitude weights in every group of 4 consecutive inputs."""
    m = copy(model)
    for i in HIDDEN:
        W = m[i][0]                                   # (inputs, outputs)
        g = W.T.reshape(W.shape[1], -1, 4)            # groups of 4 along the input (reduction) axis
        order = np.argsort(np.abs(g), axis=-1)
        mask = np.ones_like(g, dtype=bool)
        np.put_along_axis(mask, order[..., :2], False, axis=-1)
        m[i] = ((g * mask).reshape(W.shape[1], W.shape[0]).T.copy(), m[i][1])
    return m


def structured(model, keep):
    """Remove the least important neurons from every hidden layer.
    Importance of neuron j in layer i = |incoming weights| x |outgoing weights|."""
    m = copy(model)
    for i in range(len(m) - 1):
        W, b = m[i]; Wn, bn = m[i + 1]
        imp = np.linalg.norm(W, axis=0) * np.linalg.norm(Wn, axis=1)
        k = int(round(W.shape[1] * keep))
        idx = np.sort(np.argsort(imp)[-k:])
        m[i] = (W[:, idx].copy(), b[idx].copy())
        m[i + 1] = (Wn[idx, :].copy(), bn)
    return m


def nonzeros(model):
    return int(sum((W != 0).sum() + b.size for W, b in model))


def csr_mb(model):
    """Storing only the non-zeros (CSR): 4-byte value + 4-byte column index each, plus row pointers."""
    total = 0
    for W, b in model:
        nz = int((W != 0).sum())
        total += nz * 8 + (W.shape[1] + 1) * 4 + b.size * 4
    return total / 1e6


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--finetune-epochs", type=int, default=2)
    ap.add_argument("--out", default="prune.md")
    a = ap.parse_args()

    d = load_data()
    teacher = load_model("teacher.npz")
    Xb = d["X_test"][:64]
    rows = []

    models = []

    def measure(name, m, kind):
        acc, rare = scores(m, d)
        models.append(copy(m))
        rows.append([name, kind, nonzeros(m), csr_mb(m) if kind == "unstructured" else None, acc, rare, None])

    measure("dense teacher", teacher, "dense")
    for f in (0.5, 0.7, 0.9):
        measure(f"unstructured {f:.0%}", unstructured(teacher, f), "unstructured")
    measure("2:4 semi-structured", two_four(teacher), "2:4")
    for keep in (0.5, 0.25):
        m = structured(teacher, keep)
        measure(f"structured, keep {keep:.0%} neurons", m, "structured")
        if a.finetune_epochs:
            rng = np.random.default_rng(3)
            train(m, d["X_train"], d["y_train"], a.finetune_epochs, rng, lr=5e-4)
            measure(f"  + fine-tune {a.finetune_epochs} epochs", m, "structured")

    # time every variant together, interleaved, so background load hits them all equally
    for r, ms in zip(rows, time_many([lambda m=m: forward(m, Xb) for m in models], rounds=40)):
        r[6] = ms
    base_ms = rows[0][6]; base_acc = rows[0][4]
    print(f"\n  {'variant':36s} {'non-zero':>10s} {'accuracy':>9s} {'rare':>7s} {'CPU ms':>7s} {'speed':>6s}")
    print("  " + "-" * 80)
    for name, kind, nz, csr, acc, rare, ms in rows:
        print(f"  {name:36s} {nz:10,d} {acc:9.1%} {rare:7.1%} {ms:7.2f} {base_ms / ms:5.1f}x")
    print("\n  Unstructured: the zeros are still multiplied. Same shapes, same time. Stored sparse")
    print(f"  (value + index per weight) it is {rows[1][3]:.1f} MB at 50% vs {n_params(teacher) * 4 / 1e6:.1f} MB dense.")
    print("  Smaller on paper only.")
    print("  2:4: same story on a CPU; NVIDIA Ampere+ sparse tensor cores can skip the zeros.")
    print("  Structured: smaller matrices, so really faster. Fine-tuning wins accuracy back.")
    print("  CPU ms = batch of 64, best of 40 interleaved runs. Yours will differ; ratios hold.")

    md = ["# Module 2 · Pruning report", "",
          "Pruned: the two 1024×1024 hidden layers (unstructured, 2:4) or every hidden layer's neurons (structured). "
          "CPU latency: batch of 64, best of 40 interleaved runs.", "",
          "| Variant | Non-zero params | Sparse (CSR) MB | Accuracy | Rare slice | CPU ms | Speed vs dense |",
          "|---|---:|---:|---:|---:|---:|---:|"]
    for name, kind, nz, csr, acc, rare, ms in rows:
        md.append(f"| {name.strip()} | {nz:,} | {'' if csr is None else f'{csr:.1f}'} | {acc:.1%} | {rare:.1%} | "
                  f"{ms:.2f} | {base_ms / ms:.1f}× |")
    md += ["", "**Unstructured pruning makes the model smaller on paper, not faster on dense hardware.** "
               "Structured pruning changes the shapes, so the speedup is real; fine-tuning heals the accuracy.", "",
           f"Dense FP32 is {n_params(teacher) * 4 / 1e6:.1f} MB; baseline accuracy {base_acc:.1%}."]
    print(f"\nwrote {write_report(a.out, md)}")


if __name__ == "__main__":
    main()
