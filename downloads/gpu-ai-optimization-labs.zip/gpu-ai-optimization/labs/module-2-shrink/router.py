#!/usr/bin/env python3
"""
Module 2 · Stage 5 — Model routing: small model first, escalate when unsure.

Every request goes to the small student first. If the student's confidence
(its highest softmax probability) is at least THRESHOLD, its answer ships.
Otherwise the request is escalated to the big teacher.

  * Threshold 0    -> everything stays on the student (cheapest, least accurate)
  * Threshold 1    -> everything is escalated      (teacher quality, highest cost)
  * In between     -> the business decision. We sweep it and pick it on the
                      VALIDATION set, then report on the held-out test set
                      (picking and grading on the same data flatters you).

Cost model (stated, so you can argue with it): decode is memory-bound
(Module 1), so the GPU time a request costs is roughly proportional to the bytes
of weights the model reads. A routed request always pays for the student, and
pays for the teacher too if it is escalated. We convert to dollars by assuming
the teacher in FP16 costs $0.95 per 1M tokens (Module 1's chat-assistant).

Then the "change one thing" story, one step at a time:
  1. baseline       teacher in FP16, every request
  2. one change     teacher in INT8 (per-channel)
  3. next change    + routing: INT8 student first, INT8 teacher on escalation

Usage:
  python3 router.py                    # sweep, pick a threshold, the story
  python3 router.py --max-drop 0.25    # stricter quality bar (points, on validation)
  python3 router.py --usd-per-1m 2.40  # your own baseline price
"""
import argparse
import numpy as np
from common import load_data, load_model, forward, softmax, write_report
from quantize import int_quant, quantize_model, model_bytes

THRESHOLDS = (0.0, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95, 0.98, 0.99, 1.01)


def route(student, teacher, X, thr):
    p = softmax(forward(student, X))
    keep = p.max(1) >= thr
    pred = p.argmax(1)
    if (~keep).any():
        pred[~keep] = forward(teacher, X[~keep]).argmax(1)
    return pred, keep


def evaluate(student, teacher, d, thr, s_bytes, t_bytes, base_bytes):
    out = {}
    for split in ("val", "test", "rare"):
        pred, keep = route(student, teacher, d[f"X_{split}"], thr)
        out[split] = float((pred == d[f"y_{split}"]).mean())
        if split == "test":
            y = d["y_test"]
            s_pred = forward(student, d["X_test"]).argmax(1)
            out["share"] = float(keep.mean())
            out["acc_kept"] = float((pred[keep] == y[keep]).mean()) if keep.any() else float("nan")
            out["acc_esc"] = float((pred[~keep] == y[~keep]).mean()) if (~keep).any() else float("nan")
            out["student_on_esc"] = float((s_pred[~keep] == y[~keep]).mean()) if (~keep).any() else float("nan")
            out["cost"] = (s_bytes + (1 - keep.mean()) * t_bytes) / base_bytes
        if split == "val":
            _, k = route(student, teacher, d["X_val"], thr)
            out["val_cost"] = (s_bytes + (1 - k.mean()) * t_bytes) / base_bytes
    return out


def pct(x, w):
    return f"{'-':>{w}s}" if np.isnan(x) else f"{x:{w}.1%}"


def int8(model):
    qm, n = quantize_model(model, lambda W: int_quant(W, 8, "channel"))
    return qm, model_bytes(model, 8, n, 2)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--max-drop", type=float, default=0.5, help="allowed accuracy drop vs. the teacher on validation (pts)")
    ap.add_argument("--usd-per-1m", type=float, default=0.95, help="baseline: teacher FP16 cost per 1M tokens")
    ap.add_argument("--out", default="router.md")
    a = ap.parse_args()

    d = load_data()
    teacher = load_model("teacher.npz")
    student = load_model("student.npz")
    base_bytes = model_bytes(teacher, 16, 0, 0)                  # teacher in FP16: the usual serving baseline
    teacher8, t8_bytes = int8(teacher)
    student8, s8_bytes = int8(student)

    t_val = float((forward(teacher8, d["X_val"]).argmax(1) == d["y_val"]).mean())
    print(f"\nRouting: INT8 student ({s8_bytes / 1e3:.0f} KB) first, INT8 teacher ({t8_bytes / 1e6:.2f} MB) if unsure.")
    print(f"Baseline: teacher FP16 ({base_bytes / 1e6:.2f} MB) on every request = cost 1.00 = "
          f"${a.usd_per_1m:.2f} per 1M tokens.\n")
    hdr = (f"  {'threshold':>9s} {'to student':>10s} {'accuracy':>9s} {'rare':>6s} {'acc kept':>9s} "
           f"{'acc escalated':>13s} {'cost':>6s} {'$/1M':>6s}")
    print(hdr); print("  " + "-" * (len(hdr) - 2))
    sweep = []
    for thr in THRESHOLDS:
        r = evaluate(student8, teacher8, d, thr, s8_bytes, t8_bytes, base_bytes)
        sweep.append((thr, r))
        label = "never" if thr > 1 else f"{thr:.2f}"
        print(f"  {label:>9s} {r['share']:10.1%} {r['test']:9.1%} {r['rare']:6.1%} {pct(r['acc_kept'], 9)} "
              f"{pct(r['acc_esc'], 13)} {r['cost']:6.3f} {r['cost'] * a.usd_per_1m:6.3f}")
    print("  'never' = always escalate. 'acc escalated' = teacher's accuracy on escalated ones.")

    ok = [(t, r) for t, r in sweep if r["val"] >= t_val - a.max_drop / 100]
    thr, best = min(ok, key=lambda x: x[1]["val_cost"])
    print(f"\n  Picked on VALIDATION: threshold {thr:.2f}, the cheapest setting within {a.max_drop} pt")
    print(f"  of the teacher ({best['val']:.1%} vs {t_val:.1%}).")
    print(f"  On held-out TEST, {best['share']:.0%} of requests stay on the student. On the ones it escalates,")
    print(f"  the student would be right {best['student_on_esc']:.0%} of the time; the teacher, "
          f"{best['acc_esc']:.0%}. Confidence works.")

    # the story, one change at a time
    def acc(m, split):
        return float((forward(m, d[f"X_{split}"]).argmax(1) == d[f"y_{split}"]).mean())
    teacher16 = [(W.astype(np.float16).astype(np.float32), b) for W, b in teacher]
    steps = [("1. baseline: teacher FP16, every request", acc(teacher16, "test"), acc(teacher16, "rare"), 1.0),
             ("2. one change: teacher INT8 per-channel", acc(teacher8, "test"), acc(teacher8, "rare"), t8_bytes / base_bytes),
             (f"3. + routing at {thr:.2f} (INT8 student first)", best["test"], best["rare"], best["cost"])]
    print(f"\n  {'step':48s} {'accuracy':>9s} {'rare':>6s} {'cost':>6s} {'$/1M':>6s}")
    for name, ac, ra, c in steps:
        print(f"  {name:48s} {ac:9.1%} {ra:6.1%} {c:6.3f} {c * a.usd_per_1m:6.3f}")
    b, f = steps[0], steps[-1]
    story = (f"cost {(f[3] - 1) * 100:+.0f}% (${b[3] * a.usd_per_1m:.2f} -> ${f[3] * a.usd_per_1m:.2f} per 1M tokens), "
             f"accuracy {(f[1] - b[1]) * 100:+.1f} pts, rare slice {(f[2] - b[2]) * 100:+.1f} pts")
    print(f"\n  FINDINGS.md, baseline -> step 3: cost {(f[3] - 1) * 100:+.0f}% "
          f"(${b[3] * a.usd_per_1m:.2f} -> ${f[3] * a.usd_per_1m:.2f} per 1M tokens)")
    print(f"  accuracy {(f[1] - b[1]) * 100:+.1f} pts, rare slice {(f[2] - b[2]) * 100:+.1f} pts")
    # sensitivity: our student is ~100x cheaper than the teacher; real LLM pairs are closer
    real = 8 / 70                                      # e.g. an 8B model routed to a 70B model
    real_cost = (real + (1 - best["share"])) * t8_bytes / base_bytes
    print(f"  Sanity check: if the small model cost 1/9 of the big one (8B vs 70B), the same")
    print(f"  routing would be {(real_cost - 1) * 100:+.0f}%. Escalated requests pay BOTH latencies: watch their p95.")

    md = ["# Module 2 · Routing report", "",
          f"Student INT8 ({s8_bytes / 1e3:.0f} KB) first; escalate to teacher INT8 ({t8_bytes / 1e6:.2f} MB) when the "
          "student's top softmax probability is below the threshold.", "",
          f"Cost proxy: weight bytes read per request, relative to the teacher in FP16 ({base_bytes / 1e6:.2f} MB) = 1.00 = "
          f"${a.usd_per_1m:.2f} per 1M tokens (assumed). Memory-bound decode makes bytes a fair proxy for GPU time.", "",
          "| Threshold | To student | Accuracy | Rare slice | Acc. on kept | Acc. on escalated | Relative cost | $ / 1M tokens |",
          "|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for t, r in sweep:
        md.append(f"| {'never' if t > 1 else f'{t:.2f}'} | {r['share']:.1%} | {r['test']:.1%} | {r['rare']:.1%} | "
                  f"{pct(r['acc_kept'], 1)} | {pct(r['acc_esc'], 1)} | {r['cost']:.3f} | ${r['cost'] * a.usd_per_1m:.3f} |")
    md += ["", f"**Recommended threshold: {thr:.2f}** (picked on validation, within {a.max_drop} pt of the teacher; "
               "reported on held-out test).", "",
           "## Change one thing at a time", "",
           "| Step | Accuracy | Rare slice | Relative cost | $ / 1M tokens |", "|---|---:|---:|---:|---:|"]
    md += [f"| {n} | {ac:.1%} | {ra:.1%} | {c:.3f} | ${c * a.usd_per_1m:.3f} |" for n, ac, ra, c in steps]
    md += ["", f"**For FINDINGS.md:** {story}.", "",
           f"Sanity check: with a small model at 1/9 of the big one's cost (8B vs 70B), the same routing is "
           f"{(real_cost - 1) * 100:+.0f}% vs. the baseline. This lab's student is ~100× smaller than its teacher, "
           "which flatters routing.", "",
           "Caveat: escalated requests pay for both models in latency. Watch their p95."]
    print(f"\nwrote {write_report(a.out, md)}")


if __name__ == "__main__":
    main()
