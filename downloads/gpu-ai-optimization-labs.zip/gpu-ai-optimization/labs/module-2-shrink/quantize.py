#!/usr/bin/env python3
"""
Module 2 · Stage 2 — Turn the precision dial.

Takes the FP32 teacher and stores its weights in fewer bits:
FP32 -> FP16 -> BF16 -> FP8 -> INT8 -> INT4. For every format it reports
size, compression, how far the weights moved, and accuracy on the full eval set
AND on the rare slice (where damage shows up first).

The idea in plain English
  * Quantizing = storing each weight as a small integer plus a shared SCALE
    (and, for asymmetric formats, a ZERO-POINT):   weight ~= scale * (q - zero)
  * Who shares a scale decides how well it works:
      per-tensor   one scale for the whole matrix (cheapest, fragile)
      per-channel  one scale per output channel (per neuron)
      group-wise   one scale per block of G weights inside a channel (e.g. G=128)
  * One huge weight forces a huge scale, and every normal weight sharing that
    scale gets rounded to almost nothing. This model has a few outlier channels,
    like real LLMs do, so you can watch that happen.

Then it quantizes ACTIVATIONS too (W8A8), with and without SmoothQuant-style
smoothing, and shows the speed trap: on a CPU without low-bit kernels, smaller
weights are not faster.

Usage:
  python3 quantize.py                      # all formats, writes reports/quantize.md
  python3 quantize.py --group 64           # change the INT4 group size
  python3 quantize.py --max-drop 0.5       # stricter quality bar (points)
"""
import argparse
import numpy as np
from common import load_data, load_model, forward, scores, layer_inputs, time_many, write_report


# ---- number formats (all "fake-quant": quantize, then dequantize to float32) -----
def to_bf16(x):
    """BF16 = the top 16 bits of an FP32 number (round to nearest even)."""
    u = x.astype(np.float32).view(np.uint32).astype(np.uint64)
    u = (u + 0x7FFF + ((u >> 16) & 1)) & 0xFFFF0000
    return u.astype(np.uint32).view(np.float32)


def to_fp8_e4m3(x):
    """FP8 E4M3: 1 sign, 4 exponent, 3 mantissa bits. Max 448. One FP32 scale per tensor."""
    s = np.abs(x).max() / 448.0
    a = np.abs(x) / s
    e = np.floor(np.log2(np.maximum(a, 2.0 ** -9)))
    e = np.maximum(e, -6)                          # subnormals below 2^-6
    step = 2.0 ** (e - 3)                          # 3 mantissa bits -> 8 steps per power of two
    a = np.minimum(np.round(a / step) * step, 448.0)
    return (np.sign(x) * a * s).astype(np.float32)


def int_quant(W, bits, mode, group=128):
    """Integer quantization of W (inputs x outputs). Returns (dequantized W, number of scales).
    INT8 is symmetric (zero-point 0). INT4 is asymmetric (scale + zero-point), like GPTQ/AWQ."""
    n_in, n_out = W.shape
    if mode == "tensor":
        Wg = W.reshape(1, n_in * n_out)
    elif mode == "channel":                        # one scale per output channel (column)
        Wg = W.T.reshape(n_out, 1, n_in)
    else:                                          # groups of G consecutive inputs within a channel
        g = min(group, n_in)
        Wg = W.T.reshape(n_out, n_in // g, g)
    if bits == 8:
        qmax = 127
        s = np.abs(Wg).max(axis=-1, keepdims=True) / qmax
        s[s == 0] = 1.0
        D = np.clip(np.round(Wg / s), -qmax, qmax) * s
    else:
        levels = 2 ** bits - 1
        lo, hi = Wg.min(axis=-1, keepdims=True), Wg.max(axis=-1, keepdims=True)
        s = (hi - lo) / levels
        s[s == 0] = 1.0
        z = np.round(-lo / s)
        D = (np.clip(np.round(Wg / s) + z, 0, levels) - z) * s
    n_scales = int(np.prod(s.shape))
    if mode == "tensor":
        return D.reshape(n_in, n_out).astype(np.float32), n_scales
    return D.reshape(n_out, n_in).T.astype(np.float32), n_scales


# (name, bits per weight, how to quantize, bytes of metadata per scale)
def formats(group):
    return [
        ("FP32", 32, lambda W: (W, 0), 0),
        ("FP16", 16, lambda W: (W.astype(np.float16).astype(np.float32), 0), 0),
        ("BF16", 16, lambda W: (to_bf16(W), 0), 0),
        ("FP8 E4M3 per-tensor", 8, lambda W: (to_fp8_e4m3(W), 1), 4),
        ("INT8 per-tensor", 8, lambda W: int_quant(W, 8, "tensor"), 4),
        ("INT8 per-channel", 8, lambda W: int_quant(W, 8, "channel"), 2),
        ("INT4 per-tensor", 4, lambda W: int_quant(W, 4, "tensor"), 4),
        ("INT4 per-channel", 4, lambda W: int_quant(W, 4, "channel"), 2.5),
        (f"INT4 group-{group}", 4, lambda W: int_quant(W, 4, "group", group), 2.5),
        ("INT4 group-32", 4, lambda W: int_quant(W, 4, "group", 32), 2.5),
    ]


def quantize_model(model, fn):
    out, n_scales = [], 0
    for W, b in model:
        Wq, k = fn(W)
        out.append((Wq, b)); n_scales += k
    return out, n_scales


def model_bytes(model, bits, n_scales, meta_bytes):
    """Weights at `bits`, plus scales/zero-points, plus biases (FP32 for FP32, else 16-bit)."""
    n_w = sum(W.size for W, _ in model); n_b = sum(b.size for _, b in model)
    return n_w * bits / 8 + n_scales * meta_bytes + n_b * (4 if bits == 32 else 2)


def weight_error(model, qmodel):
    num = sum(float(((Wq - W) ** 2).sum()) for (W, _), (Wq, _) in zip(model, qmodel))
    den = sum(float((W ** 2).sum()) for W, _ in model)
    return np.sqrt(num / den)


# ---- activations: W8A8 with and without smoothing -------------------------------------
def act_quantizer(model, Xcal):
    """Static per-tensor INT8 activations: one scale per layer input, from calibration data."""
    scales = [np.abs(a).max() / 127 for a in layer_inputs(model, Xcal)]
    return lambda i, h: np.clip(np.round(h / scales[i]), -127, 127) * scales[i]


def smooth(model, Xcal, alpha=0.5):
    """SmoothQuant idea: divide each activation channel j by s_j and multiply the matching
    weights by s_j. Same answers, but the outliers move from activations into weights,
    which per-channel weight quantization handles well. Here 1/s_j is folded into the
    previous layer (exact, because ReLU(z/s) = ReLU(z)/s for s > 0)."""
    m = [(W.copy(), b.copy()) for W, b in model]
    acts = layer_inputs(model, Xcal)
    for i in range(1, len(m)):
        amax = np.abs(acts[i]).max(0) + 1e-6
        wmax = np.abs(m[i][0]).max(1) + 1e-6
        s = (amax ** alpha / wmax ** (1 - alpha)).astype(np.float32)
        m[i - 1][0][:, :] /= s; m[i - 1][1][:] /= s
        m[i][0][:, :] *= s[:, None]
    return m


# ---- the speed trap ---------------------------------------------------------------------
def pack_int4(q):
    q = (q.astype(np.int16) + 8).astype(np.uint8)            # [-8, 7] -> [0, 15]
    return (q[0::2] | (q[1::2] << 4)).astype(np.uint8)


def latency_table(model, X):
    """One batch of 64 requests through the network on this CPU."""
    def fp32():
        forward(model, X)
    q8 = []
    for W, b in model:
        s = np.abs(W).max(0, keepdims=True) / 127
        q8.append((np.round(W / s).astype(np.int8), s, b))

    def int8():
        h = X
        for i, (q, s, b) in enumerate(q8):
            h = h @ (q.astype(np.float32) * s) + b         # dequantize, then FP32 matmul
            if i < len(q8) - 1:
                h = np.maximum(h, 0)
    q4 = []
    for W, b in model:
        s = np.abs(W).max(0, keepdims=True) / 7
        q4.append((pack_int4(np.clip(np.round(W / s), -8, 7)), s, b))

    def int4():
        h = X
        for i, (p, s, b) in enumerate(q4):
            q = np.empty((p.shape[0] * 2, p.shape[1]), np.float32)
            q[0::2] = (p & 15); q[1::2] = (p >> 4)          # unpack two weights per byte
            h = h @ ((q - 8) * s) + b
            if i < len(q4) - 1:
                h = np.maximum(h, 0)
    ms = time_many([fp32, int8, int4], rounds=30)
    return list(zip(["FP32", "INT8 (dequantize + FP32 matmul)", "INT4 (unpack + dequantize + FP32 matmul)"], ms))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--group", type=int, default=128, help="INT4 group size (default 128)")
    ap.add_argument("--max-drop", type=float, default=1.0, help="quality bar in accuracy points (default 1.0)")
    ap.add_argument("--out", default="quantize.md")
    a = ap.parse_args()

    d = load_data()
    model = load_model("teacher.npz")
    base_acc, base_rare = scores(model, d)
    base_bytes = model_bytes(model, 32, 0, 0)

    print(f"\nTeacher: {sum(W.size for W, _ in model) / 1e6:.2f}M weights | test {base_acc:.1%} | rare slice {base_rare:.1%}\n")
    hdr = f"  {'format':19s} {'MB':>6s} {'smaller':>7s} {'w.err':>6s} {'acc':>6s} {'rare':>6s}   {'change, pts':>12s}"
    se = 100 * np.sqrt(base_acc * (1 - base_acc) / len(d["y_test"]))
    se_r = 100 * np.sqrt(base_rare * (1 - base_rare) / len(d["y_rare"]))
    print(hdr); print("  " + "-" * (len(hdr) - 2))
    md = ["# Module 2 · Quantization report", "",
          f"Teacher: {sum(W.size for W, _ in model):,} weights. Eval: {len(d['y_test']):,} test requests "
          f"+ {len(d['y_rare']):,} rare-slice requests. Quality bar: {a.max_drop} pt.", "",
          "| Format | Bits | Size MB | × smaller | Weight error | Accuracy | Rare slice | Change (pts) | Agrees with FP32 |",
          "|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
    base_pred = forward(model, d["X_test"]).argmax(1)
    results = []
    for name, bits, fn, meta in formats(a.group):
        qm, n_scales = quantize_model(model, fn)
        size = model_bytes(model, bits, n_scales, meta)
        acc, rare = scores(qm, d)
        err = weight_error(model, qm)
        agree = float((forward(qm, d["X_test"]).argmax(1) == base_pred).mean())
        drop = (base_acc - acc) * 100
        rdrop = (base_rare - rare) * 100
        flag = "  <- moved" if max(drop, rdrop) > a.max_drop else ""
        print(f"  {name:19s} {size / 1e6:6.2f} {base_bytes / size:6.1f}x {err:6.1%} {acc:6.1%} {rare:6.1%}   "
              f"{round(-drop, 1) + 0:+5.1f} / {round(-rdrop, 1) + 0:+5.1f}{flag}")
        md.append(f"| {name} | {bits} | {size / 1e6:.2f} | {base_bytes / size:.1f}× | {err:.2%} | {acc:.1%} | {rare:.1%} | "
                  f"{round(-drop, 1) + 0:+.1f} (rare {round(-rdrop, 1) + 0:+.1f}) | {agree:.1%} |")
        results.append((name, size, drop, rdrop))

    print(f"\n  change = overall / rare slice. Noise (1 SE): +/-{se:.1f} pt overall, +/-{se_r:.1f} pt rare.")
    ok = [r for r in results if max(r[2], r[3]) <= a.max_drop]
    best = min(ok, key=lambda r: r[1])
    print(f"  Smallest within {a.max_drop} pt on BOTH slices: {best[0]} ({base_bytes / best[1]:.1f}x smaller)")

    # outliers: what they look like
    acts = layer_inputs(model, d["X_train"][:512])
    amax = np.abs(acts[1]).max(0)
    W0 = np.abs(model[0][0]).max(0)
    print(f"\n  Why per-tensor fails: layer 0's biggest weight is {W0.max() / np.median(W0):.0f}x a typical channel's max,")
    print(f"  and {int((amax > 10 * np.median(amax)).sum())} of {len(amax)} activation channels into layer 1 are >10x the median.")

    # W8A8
    Xcal = d["X_train"][:512]
    w8 = quantize_model(model, lambda W: int_quant(W, 8, "channel"))[0]
    naive = scores(w8, d, act_quantizer(model, Xcal))
    sm = smooth(model, Xcal)
    w8s = quantize_model(sm, lambda W: int_quant(W, 8, "channel"))[0]
    smoothed = scores(w8s, d, act_quantizer(sm, Xcal))
    print("\n  Weights AND activations in INT8 (W8A8, one static scale per activation tensor):")
    print(f"    W8A8 naive               acc {naive[0]:.1%}  rare {naive[1]:.1%}")
    print(f"    W8A8 SmoothQuant-style   acc {smoothed[0]:.1%}  rare {smoothed[1]:.1%}   (alpha 0.5)")

    # range
    with np.errstate(over="ignore"):
        f16 = float(np.float16(70000.0))
    print(f"\n  Range check: 70,000 in FP16 -> {f16} | in BF16 -> "
          f"{float(to_bf16(np.array([70000.0], np.float32))[0]):,.0f}  (BF16 keeps FP32's range)")

    # speed
    lat = latency_table(model, d["X_test"][:64])
    print("\n  Speed trap, batch of 64 on this CPU (numpy has no low-bit kernels):")
    for name, ms in lat:
        print(f"    {name:42s} {ms:5.2f} ms  ({ms / lat[0][1]:.1f}x FP32)")
    print("  On a GPU, decode is memory-bound (Module 1): 4x fewer bytes than FP16 can raise the")
    print("  ceiling up to ~4x, but only with kernels that read the packed format. Measure it.")

    md += ["", f"**Smallest format within {a.max_drop} pt on both slices:** {best[0]} "
               f"({base_bytes / best[1]:.1f}× smaller than FP32).", "",
           f"Noise level (1 standard error): ±{se:.1f} pt on the eval set, ±{se_r:.1f} pt on the rare slice. "
           "Differences smaller than about two standard errors are not real.", "",
           "Sizes include scales and zero-points (FP16 scale; INT4 zero-points at 4 bits) and 16-bit biases.", "",
           "## Weights and activations (W8A8)", "",
           "| Variant | Accuracy | Rare slice |", "|---|---:|---:|",
           f"| FP32 baseline | {base_acc:.1%} | {base_rare:.1%} |",
           f"| W8A8 naive (per-tensor activations) | {naive[0]:.1%} | {naive[1]:.1%} |",
           f"| W8A8 + SmoothQuant-style smoothing (α=0.5) | {smoothed[0]:.1%} | {smoothed[1]:.1%} |", "",
           "## The speed trap (CPU, batch 64, emulated)", "",
           "| Path | ms | vs FP32 |", "|---|---:|---:|"]
    md += [f"| {n} | {ms:.2f} | {ms / lat[0][1]:.1f}× |" for n, ms in lat]
    md += ["", "Low-bit weights only get faster with kernels that read the packed format (on a GPU). "
               "On a memory-bound GPU decode, the ceiling scales with bytes per weight (Module 1 `bottleneck.py`).", "",
           "## What to write in FINDINGS.md", "",
           f"- Baseline: FP32, {base_bytes / 1e6:.2f} MB, {base_acc:.1%} accuracy, {base_rare:.1%} on the rare slice.",
           f"- Chosen: {best[0]}, {best[1] / 1e6:.2f} MB ({base_bytes / best[1]:.1f}× smaller), within {a.max_drop} pt.",
           "- What broke first and why (look at INT8 per-tensor and the rare slice)."]
    print(f"\nwrote {write_report(a.out, md)}")


if __name__ == "__main__":
    main()
