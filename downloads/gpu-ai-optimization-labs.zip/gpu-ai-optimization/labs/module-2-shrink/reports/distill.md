# Module 2 · Distillation report

Student [64, 256, 10] vs teacher [64, 1024, 1024, 1024, 10]. Temperature 2.0. Human labels: 2,000. Each student trains until validation accuracy stops improving.

| Student training | Accuracy | Rare slice | Agrees with teacher | % of teacher accuracy |
|---|---:|---:|---:|---:|
| A  hard labels (2k) | 75.4% | 47.1% | 76.3% | 82.4% |
| B  soft labels (2k) | 80.1% | 59.5% | 83.2% | 87.7% |
| C  soft labels (2k) + 60k prompts | 89.9% | 83.5% | 93.7% | 98.3% |

| Model | Params | Size (FP32) | Accuracy | Rare slice | CPU ms (batch 64) |
|---|---:|---:|---:|---:|---:|
| Teacher | 2,176,010 | 8.70 MB | 91.4% | 86.4% | 1.76 |
| Student (C) | 19,210 | 0.077 MB | 89.9% | 83.5% | 0.05 |

**113× smaller, 37× faster, 98% of the teacher's accuracy.** The rare slice loses more (2.8 pts): check it before you ship.

Note: the student is evaluated against the same eval set as the teacher, not a generic benchmark.
