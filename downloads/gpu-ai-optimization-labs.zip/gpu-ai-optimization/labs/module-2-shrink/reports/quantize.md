# Module 2 · Quantization report

Teacher: 2,172,928 weights. Eval: 10,000 test requests + 3,000 rare-slice requests. Quality bar: 1.0 pt.

| Format | Bits | Size MB | × smaller | Weight error | Accuracy | Rare slice | Change (pts) | Agrees with FP32 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| FP32 | 32 | 8.70 | 1.0× | 0.00% | 91.4% | 86.4% | +0.0 (rare +0.0) | 100.0% |
| FP16 | 16 | 4.35 | 2.0× | 0.02% | 91.4% | 86.4% | +0.0 (rare +0.0) | 100.0% |
| BF16 | 16 | 4.35 | 2.0× | 0.18% | 91.5% | 86.4% | +0.0 (rare +0.0) | 100.0% |
| FP8 E4M3 per-tensor | 8 | 2.18 | 4.0× | 2.45% | 91.4% | 86.0% | +0.0 (rare -0.3) | 99.5% |
| INT8 per-tensor | 8 | 2.18 | 4.0× | 9.64% | 73.0% | 51.6% | -18.5 (rare -34.8) | 75.6% |
| INT8 per-channel | 8 | 2.19 | 4.0× | 0.61% | 91.3% | 86.3% | -0.1 (rare -0.1) | 99.5% |
| INT4 per-tensor | 4 | 1.09 | 8.0× | 17.74% | 10.2% | 9.7% | -81.3 (rare -76.7) | 10.2% |
| INT4 per-channel | 4 | 1.10 | 7.9× | 9.84% | 90.9% | 85.5% | -0.5 (rare -0.9) | 97.5% |
| INT4 group-128 | 4 | 1.14 | 7.7× | 9.75% | 91.1% | 86.1% | -0.3 (rare -0.3) | 98.0% |
| INT4 group-32 | 4 | 1.26 | 6.9× | 8.14% | 91.4% | 85.8% | -0.1 (rare -0.5) | 98.3% |

**Smallest format within 1.0 pt on both slices:** INT4 per-channel (7.9× smaller than FP32).

Noise level (1 standard error): ±0.3 pt on the eval set, ±0.6 pt on the rare slice. Differences smaller than about two standard errors are not real.

Sizes include scales and zero-points (FP16 scale; INT4 zero-points at 4 bits) and 16-bit biases.

## Weights and activations (W8A8)

| Variant | Accuracy | Rare slice |
|---|---:|---:|
| FP32 baseline | 91.4% | 86.4% |
| W8A8 naive (per-tensor activations) | 85.3% | 80.4% |
| W8A8 + SmoothQuant-style smoothing (α=0.5) | 91.4% | 86.3% |

## The speed trap (CPU, batch 64, emulated)

| Path | ms | vs FP32 |
|---|---:|---:|
| FP32 | 1.72 | 1.0× |
| INT8 (dequantize + FP32 matmul) | 3.14 | 1.8× |
| INT4 (unpack + dequantize + FP32 matmul) | 3.94 | 2.3× |

Low-bit weights only get faster with kernels that read the packed format (on a GPU). On a memory-bound GPU decode, the ceiling scales with bytes per weight (Module 1 `bottleneck.py`).

## What to write in FINDINGS.md

- Baseline: FP32, 8.70 MB, 91.4% accuracy, 86.4% on the rare slice.
- Chosen: INT4 per-channel, 1.10 MB (7.9× smaller), within 1.0 pt.
- What broke first and why (look at INT8 per-tensor and the rare slice).
