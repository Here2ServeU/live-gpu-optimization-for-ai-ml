# Module 2 · Pruning report

Pruned: the two 1024×1024 hidden layers (unstructured, 2:4) or every hidden layer's neurons (structured). CPU latency: batch of 64, best of 40 interleaved runs.

| Variant | Non-zero params | Sparse (CSR) MB | Accuracy | Rare slice | CPU ms | Speed vs dense |
|---|---:|---:|---:|---:|---:|---:|
| dense teacher | 2,176,010 |  | 91.4% | 86.4% | 1.74 | 1.0× |
| unstructured 50% | 1,127,434 | 9.0 | 90.6% | 85.9% | 1.84 | 0.9× |
| unstructured 70% | 708,005 | 5.7 | 87.7% | 82.2% | 1.83 | 1.0× |
| unstructured 90% | 288,574 | 2.3 | 59.8% | 49.4% | 1.81 | 1.0× |
| 2:4 semi-structured | 1,127,434 |  | 89.6% | 84.5% | 1.87 | 0.9× |
| structured, keep 50% neurons | 563,722 |  | 48.9% | 52.3% | 0.57 | 3.1× |
| + fine-tune 2 epochs | 563,722 |  | 90.7% | 83.7% | 0.56 | 3.1× |
| structured, keep 25% neurons | 150,794 |  | 25.0% | 39.1% | 0.19 | 9.4× |
| + fine-tune 2 epochs | 150,794 |  | 85.2% | 68.8% | 0.18 | 9.5× |

**Unstructured pruning makes the model smaller on paper, not faster on dense hardware.** Structured pruning changes the shapes, so the speedup is real; fine-tuning heals the accuracy.

Dense FP32 is 8.7 MB; baseline accuracy 91.4%.
