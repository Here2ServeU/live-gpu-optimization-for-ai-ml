# Module 2 · Routing report

Student INT8 (20 KB) first; escalate to teacher INT8 (2.19 MB) when the student's top softmax probability is below the threshold.

Cost proxy: weight bytes read per request, relative to the teacher in FP16 (4.35 MB) = 1.00 = $0.95 per 1M tokens (assumed). Memory-bound decode makes bytes a fair proxy for GPU time.

| Threshold | To student | Accuracy | Rare slice | Acc. on kept | Acc. on escalated | Relative cost | $ / 1M tokens |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 0.00 | 100.0% | 89.9% | 83.5% | 89.9% | - | 0.005 | $0.004 |
| 0.50 | 96.9% | 90.4% | 84.6% | 91.6% | 54.4% | 0.020 | $0.019 |
| 0.60 | 93.2% | 91.0% | 85.2% | 93.3% | 59.5% | 0.039 | $0.037 |
| 0.70 | 89.3% | 91.3% | 85.7% | 94.8% | 62.9% | 0.059 | $0.056 |
| 0.80 | 84.7% | 91.4% | 86.2% | 96.0% | 66.2% | 0.081 | $0.077 |
| 0.90 | 77.3% | 91.4% | 86.2% | 97.7% | 69.9% | 0.119 | $0.113 |
| 0.95 | 70.4% | 91.4% | 86.2% | 98.6% | 74.3% | 0.153 | $0.146 |
| 0.98 | 60.9% | 91.3% | 86.3% | 99.2% | 79.1% | 0.201 | $0.191 |
| 0.99 | 53.2% | 91.3% | 86.3% | 99.5% | 82.1% | 0.239 | $0.227 |
| never | 0.0% | 91.3% | 86.3% | - | 91.3% | 0.507 | $0.481 |

**Recommended threshold: 0.70** (picked on validation, within 0.5 pt of the teacher; reported on held-out test).

## Change one thing at a time

| Step | Accuracy | Rare slice | Relative cost | $ / 1M tokens |
|---|---:|---:|---:|---:|
| 1. baseline: teacher FP16, every request | 91.4% | 86.4% | 1.000 | $0.950 |
| 2. one change: teacher INT8 per-channel | 91.3% | 86.3% | 0.502 | $0.477 |
| 3. + routing at 0.70 (INT8 student first) | 91.3% | 85.7% | 0.059 | $0.056 |

**For FINDINGS.md:** cost -94% ($0.95 -> $0.06 per 1M tokens), accuracy -0.1 pts, rare slice -0.7 pts.

Sanity check: with a small model at 1/9 of the big one's cost (8B vs 70B), the same routing is -89% vs. the baseline. This lab's student is ~100× smaller than its teacher, which flatters routing.

Caveat: escalated requests pay for both models in latency. Watch their p95.
