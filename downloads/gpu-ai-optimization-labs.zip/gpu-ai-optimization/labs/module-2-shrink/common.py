"""
Module 2 · shared helpers (numpy only).

A tiny multi-layer perceptron (MLP) library: build, run, train, time, save.
Every script in this lab imports from here, so the model code lives in one place.

Conventions
  * A model is a list of layers: [(W, b), (W, b), ...]
  * W has shape (inputs, outputs), so a layer is  y = x @ W + b
  * An "output channel" of a layer is one COLUMN of W (one neuron).
  * Hidden layers use ReLU. The last layer returns logits (raw scores).
"""
import os, time
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "data")
REPORTS = os.path.join(HERE, "reports")


# ---- data --------------------------------------------------------------------
def load_data():
    path = os.path.join(DATA, "dataset.npz")
    if not os.path.exists(path):
        raise SystemExit("data/dataset.npz not found. Run:  python3 data/make_data.py")
    return dict(np.load(path))


def load_model(name):
    path = os.path.join(DATA, name)
    if not os.path.exists(path):
        hint = "python3 distill.py" if "student" in name else "python3 data/make_data.py"
        raise SystemExit(f"data/{name} not found. Run:  {hint}")
    z = np.load(path)
    n = len([k for k in z.files if k.startswith("W")])
    return [(z[f"W{i}"], z[f"b{i}"]) for i in range(n)]


def save_model(model, name):
    arrays = {}
    for i, (W, b) in enumerate(model):
        arrays[f"W{i}"] = W.astype(np.float32)
        arrays[f"b{i}"] = b.astype(np.float32)
    np.savez_compressed(os.path.join(DATA, name), **arrays)


# ---- the model -----------------------------------------------------------------
def init_mlp(sizes, rng):
    """He initialisation, float32."""
    model = []
    for fan_in, fan_out in zip(sizes[:-1], sizes[1:]):
        W = (rng.standard_normal((fan_in, fan_out)) * np.sqrt(2.0 / fan_in)).astype(np.float32)
        model.append((W, np.zeros(fan_out, np.float32)))
    return model


def forward(model, X, act_hook=None):
    """Logits for X. act_hook(i, h) may transform the input of layer i (used to quantize activations)."""
    if len(X) > 8192:                      # big inputs in chunks: less memory, often faster
        return np.concatenate([forward(model, X[s:s + 8192], act_hook) for s in range(0, len(X), 8192)])
    h = X
    for i, (W, b) in enumerate(model):
        if act_hook is not None:
            h = act_hook(i, h)
        h = h @ W + b
        if i < len(model) - 1:
            h = np.maximum(h, 0.0)
    return h


def layer_inputs(model, X):
    """The input activations seen by every layer (for calibration)."""
    acts, h = [], X
    for i, (W, b) in enumerate(model):
        acts.append(h)
        h = h @ W + b
        if i < len(model) - 1:
            h = np.maximum(h, 0.0)
    return acts


def softmax(z, T=1.0):
    z = z / T
    z = z - z.max(axis=1, keepdims=True)
    e = np.exp(z)
    return e / e.sum(axis=1, keepdims=True)


def n_params(model):
    return int(sum(W.size + b.size for W, b in model))


def accuracy(model, X, y, mask=None):
    pred = forward(model, X).argmax(1)
    ok = pred == y
    return float(ok.mean()) if mask is None else float(ok[mask].mean())


def scores(model, d, act_hook=None):
    """(test accuracy, rare-slice accuracy). The rare slice is a separate eval set
    made only of rare-style requests, so it is big enough to measure."""
    acc = float((forward(model, d["X_test"], act_hook).argmax(1) == d["y_test"]).mean())
    rare = float((forward(model, d["X_rare"], act_hook).argmax(1) == d["y_rare"]).mean())
    return acc, rare


# ---- training ------------------------------------------------------------------
def train(model, X, targets, epochs, rng, lr=1e-3, batch=256, T=1.0, weight_decay=0.0, log=None):
    """Adam on cross-entropy.
    targets: int labels (hard) OR a probability matrix (soft labels, e.g. from a teacher).
    T: temperature applied to the model's logits (distillation uses T > 1)."""
    soft = targets.ndim == 2
    m = [(np.zeros_like(W), np.zeros_like(b)) for W, b in model]
    v = [(np.zeros_like(W), np.zeros_like(b)) for W, b in model]
    b1, b2, eps, t = 0.9, 0.999, 1e-8, 0
    n = len(X)
    for ep in range(epochs):
        order = rng.permutation(n)
        for s in range(0, n, batch):
            idx = order[s:s + batch]
            xb = X[idx]
            # forward, keeping activations
            hs = [xb]
            h = xb
            for i, (W, b) in enumerate(model):
                h = h @ W + b
                if i < len(model) - 1:
                    h = np.maximum(h, 0.0)
                hs.append(h)
            p = softmax(hs[-1], T)
            if soft:
                g = (p - targets[idx]) / len(idx)
            else:
                g = p
                g[np.arange(len(idx)), targets[idx]] -= 1.0
                g /= len(idx)
            # Zero out vanishingly small gradients: float32 "subnormal" numbers make CPUs
            # up to 10x slower, and these values change nothing.
            g[np.abs(g) < 1e-12] = 0.0
            g = g * T  # d/dlogits of CE(softmax(z/T)) is (p - q)/T; times T^2 (Hinton) -> (p - q) * T
            # backward + Adam
            t += 1
            for i in range(len(model) - 1, -1, -1):
                W, b = model[i]
                gW = hs[i].T @ g
                if weight_decay:
                    gW += weight_decay * W
                gb = g.sum(0)
                if i > 0:
                    g = (g @ W.T) * (hs[i] > 0)
                for j, (param, grad) in enumerate(((W, gW), (b, gb))):
                    mj = m[i][j]; vj = v[i][j]
                    mj *= b1; mj += (1 - b1) * grad
                    gg = grad * grad; gg[gg < 1e-30] = 0.0
                    vj *= b2; vj += (1 - b2) * gg
                    mhat = mj / (1 - b1 ** t); vhat = vj / (1 - b2 ** t)
                    param -= (lr * mhat / (np.sqrt(vhat) + eps)).astype(np.float32)
        if log:
            log(ep)
    return model


# ---- timing --------------------------------------------------------------------
def time_ms(fn, repeat=15, warmup=3):
    """Best-of-N wall time of fn() in milliseconds (the minimum is the least noisy estimate)."""
    return time_many([fn], repeat, warmup)[0]


def time_many(fns, rounds=30, warmup=3):
    """Time several functions fairly: interleave them, round after round, and keep each one's
    best time. Background load on your laptop then hits every variant equally."""
    for fn in fns:
        for _ in range(warmup):
            fn()
    best = [float("inf")] * len(fns)
    for _ in range(rounds):
        for k, fn in enumerate(fns):
            t = time.perf_counter(); fn(); best[k] = min(best[k], time.perf_counter() - t)
    return [b * 1000 for b in best]


def write_report(name, lines):
    os.makedirs(REPORTS, exist_ok=True)
    path = os.path.join(REPORTS, name)
    with open(path, "w") as f:
        f.write("\n".join(lines) + "\n")
    return os.path.relpath(path, HERE)
