# Module 2 Lab · Shrink the Model Without Breaking It

**Time:** ~50 minutes · **Runs on:** any laptop (Python 3.9+, numpy, about 1 minute of compute in total) · **Optional:** a machine with an NVIDIA GPU

You will take a "big model" (a 2.2M-parameter teacher), make it smaller four different ways, and measure what each one costs you in quality, **on your own eval set and on the rare slice where damage shows up first**.

| Script | Question it answers |
|---|---|
| `data/make_data.py` | What is the task, and what does the big model score? (builds the data and trains the teacher) |
| `quantize.py` | How far can I turn the precision dial (FP32 → FP16 → BF16 → FP8 → INT8 → INT4) before quality moves? Why does per-tensor INT8 fail? |
| `distill.py` | Can a model 100x smaller learn to copy the big one? Do soft labels and unlabelled domain prompts help? |
| `prune.py` | Which kind of pruning makes the model faster, and which only makes it smaller on paper? |
| `router.py` | If easy requests go to the small model and hard ones escalate, what is the blended cost and quality? |

**What the model is.** A synthetic, seeded classification task: 64-number "requests", 10 intents. Each intent has 16 common styles and one **rare** style (about 3% of traffic), a stand-in for rare languages, odd formats and long reasoning in real LLMs. The teacher has **six deliberate outlier channels**, made with an exact identity (`ReLU(k·z) = k·ReLU(z)`): the answers do not change, but the weights and activations now have outliers 100x larger than the rest, like real LLMs do. The lessons transfer directly to LLMs; the absolute numbers do not.

---

## Stage 1 · Set up and build the teacher (5 min)

```bash
# macOS / Linux
cd labs/module-2-shrink
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt     # numpy only
python3 data/make_data.py           # ~20-60 s: builds the data, trains the teacher
```
```powershell
# Windows PowerShell
cd labs\module-2-shrink
py -m venv .venv; .venv\Scripts\Activate.ps1
pip install -r requirements.txt
py data\make_data.py
```
On Windows, use `py` wherever this guide says `python3`.

Expected (last lines):

```
injected 6 outlier channels x100 into layer 0 (max logit change 3.8e-06: same model, new outliers)
teacher: test accuracy 91.4% | rare slice 86.4% | saved data/teacher.npz
```

Everything is seeded. Different math libraries can move a number in the last digit on your machine; the patterns below will not change.

## Stage 2 · Turn the precision dial (10 min)

```bash
python3 quantize.py
```

Expected (excerpt):

```
  format                  MB smaller  w.err    acc   rare    change, pts
  FP32                  8.70    1.0x   0.0%  91.4%  86.4%    +0.0 /  +0.0
  BF16                  4.35    2.0x   0.2%  91.5%  86.4%    +0.0 /  +0.0
  FP8 E4M3 per-tensor   2.18    4.0x   2.4%  91.4%  86.0%    +0.0 /  -0.3
  INT8 per-tensor       2.18    4.0x   9.6%  73.0%  51.6%   -18.5 / -34.8  <- moved
  INT8 per-channel      2.19    4.0x   0.6%  91.3%  86.3%    -0.1 /  -0.1
  INT4 per-tensor       1.09    8.0x  17.7%  10.2%   9.7%   -81.3 / -76.7  <- moved
  INT4 group-128        1.14    7.7x   9.8%  91.1%  86.1%    -0.3 /  -0.3

  change = overall / rare slice. Noise (1 SE): +/-0.3 pt overall, +/-0.6 pt rare.
    W8A8 naive               acc 85.3%  rare 80.4%
    W8A8 SmoothQuant-style   acc 91.4%  rare 86.3%   (alpha 0.5)
```

Read it:

- **Same bits, opposite results.** INT8 per-tensor and INT8 per-channel are the same size. One scale for the whole matrix lets six outlier channels set the step size, and every normal weight gets rounded to almost nothing: **-18.5 pts, and -34.8 on the rare slice.** One scale per output channel: -0.1.
- **The rare slice breaks first and worst.** Always report it next to the headline number.
- **FP8 per-tensor survives the same outliers** because it is floating point: its exponent gives it range. INT8 has evenly spaced steps.
- **INT4 group-128 is 7.7x smaller than FP32 and within noise.** Group-wise scales cost a few percent of extra bytes (1.14 MB vs 1.10 MB per-channel) and buy back quality.
- **Weight error is a poor proxy.** INT8 per-tensor and INT4 per-channel both move the weights ~10%, yet one loses 18 points and the other loses 0.5. Where the error lands matters. Measure accuracy.
- **Activations have outliers too.** Quantizing activations with one scale per tensor (W8A8) costs 6 points; SmoothQuant-style smoothing moves the outliers into the weights (same answers, exact identity) and wins it all back.
- **The speed trap.** On this CPU the INT8 and INT4 paths are about 2x *slower* than FP32 (unpacking costs time, and numpy has no low-bit kernels). On a GPU, decode is memory-bound (Module 1), so fewer bytes raise the speed ceiling, but only with kernels that read the packed format. Speed is a measurement, not a consequence.

**Do:** write down the smallest format that stays within 1 point on **both** slices. Then run `python3 quantize.py --group 32` and `--max-drop 0.5`. Did your answer change?

## Stage 3 · Distill a student (10 min)

```bash
python3 distill.py
```

Expected:

```
  A  hard labels (2k)               accuracy 75.4%  rare 47.1%  agrees 76.3%
  B  soft labels (2k)               accuracy 80.1%  rare 59.5%  agrees 83.2%
  C  soft labels (2k) + 60k prompts accuracy 89.9%  rare 83.5%  agrees 93.7%

                   params  FP32 MB  accuracy    rare  CPU ms (batch 64)
  teacher       2,176,010     8.70     91.4%   86.4%               1.76
  student C        19,210     0.08     89.9%   83.5%               0.05

  Student: 113x smaller, 37x faster, 98% of the teacher's accuracy.
  It gives up 1.5 pts overall and 2.8 pts on the rare slice.
  Distillation (C) vs hard labels (A): +14.5 pts overall, +36.4 pts rare.
```

The same small network, trained three ways. You have only **2,000 human labels** (labels are expensive). **Soft labels** (the teacher's full probability distribution, softened with temperature T=2) teach more per example than one right answer. **Unlabelled domain prompts** that the teacher labels for free are the biggest win: this is the usual real-world recipe for distilling an LLM onto your product's traffic. Your speedup will differ (CPU timings are noisy); the size ratio will not.

**Do:** run `python3 distill.py --labels 20000`. With 10x more human labels, how much does distillation still add? Then try `--hidden 64`. Where does "small enough" stop being "good enough"?

## Stage 4 · Prune: paper vs. practice (8 min)

```bash
python3 prune.py
```

Expected:

```
  variant                                non-zero  accuracy    rare  CPU ms  speed
  dense teacher                         2,176,010     91.4%   86.4%    1.74   1.0x
  unstructured 50%                      1,127,434     90.6%   85.9%    1.84   0.9x
  unstructured 70%                        708,005     87.7%   82.2%    1.83   1.0x
  unstructured 90%                        288,574     59.8%   49.4%    1.81   1.0x
  2:4 semi-structured                   1,127,434     89.6%   84.5%    1.87   0.9x
  structured, keep 50% neurons            563,722     48.9%   52.3%    0.57   3.1x
    + fine-tune 2 epochs                  563,722     90.7%   83.7%    0.56   3.1x
  structured, keep 25% neurons            150,794     25.0%   39.1%    0.19   9.4x
    + fine-tune 2 epochs                  150,794     85.2%   68.8%    0.18   9.5x
```

- **Unstructured pruning** halves the non-zero count and changes nothing about speed: a dense matmul multiplies the zeros too. Stored as a sparse matrix (value + index per weight), 50% sparse is 9.0 MB versus 8.7 MB dense. Smaller on paper only.
- **2:4 sparsity** (2 of every 4 weights zero) is the pattern NVIDIA Ampere-and-later sparse tensor cores can accelerate. A CPU cannot, so here you only see the quality cost.
- **Structured pruning** removes whole neurons, so the matrices really shrink and it really gets faster. It breaks the model at first (48.9%); **two epochs of fine-tuning heal it to 90.7%**. Prune, then fine-tune, then measure latency, not parameter count.

**Do:** note which variant you would ship and why. Check its rare-slice number before you answer.

## Stage 5 · Route, then change one thing at a time (12 min)

```bash
python3 router.py
```

Expected (excerpt):

```
  threshold to student  accuracy   rare  acc kept acc escalated   cost   $/1M
       0.00     100.0%     89.9%  83.5%     89.9%             -  0.005  0.004
       0.70      89.3%     91.3%  85.7%     94.8%         62.9%  0.059  0.056
       0.90      77.3%     91.4%  86.2%     97.7%         69.9%  0.119  0.113
      never       0.0%     91.3%  86.3%         -         91.3%  0.507  0.481

  Picked on VALIDATION: threshold 0.70, the cheapest setting within 0.5 pt
  of the teacher (91.8% vs 92.2%).

  step                                              accuracy   rare   cost   $/1M
  1. baseline: teacher FP16, every request             91.4%  86.4%  1.000  0.950
  2. one change: teacher INT8 per-channel              91.3%  86.3%  0.502  0.477
  3. + routing at 0.70 (INT8 student first)            91.3%  85.7%  0.059  0.056

  FINDINGS.md, baseline -> step 3: cost -94% ($0.95 -> $0.06 per 1M tokens)
  accuracy -0.1 pts, rare slice -0.7 pts
```

Every request tries the INT8 student first. If its confidence (top softmax probability) is below the threshold, the request escalates to the INT8 teacher. The threshold is **picked on the validation set and reported on the held-out test set**: choosing and grading on the same data flatters you.

**The cost model, stated so you can argue with it:** decode is memory-bound (Module 1), so a request's GPU time is roughly proportional to the bytes of weights read. The baseline (teacher in FP16) is 1.00 = $0.95 per 1M tokens, Module 1's chat-assistant. Change it with `--usd-per-1m`.

**Be honest about it:** this student is ~100x smaller than its teacher, which flatters routing. The script prints a sanity check: with a small model at 1/9 of the big one's cost (like 8B vs 70B), the same routing would be -89%. And escalated requests pay **both** models' latency: check their p95 before you ship.

**Do:** the story is told one change at a time (step 2, then step 3), so you can say which change bought what. Write FINDINGS.md from it.

---

## Optional · GPU track (real models, real tools)

Only if you have an NVIDIA GPU. Tool flags change between versions: check `--help` and the docs for the version you install.

**1. Serve FP16 vs FP8 with vLLM** and compare memory, throughput and quality on the same prompts:

```bash
pip install vllm
vllm serve <model> --dtype bfloat16                # baseline
vllm serve <model> --quantization fp8              # FP8 weights, quantized on load
nvidia-smi --query-gpu=memory.used --format=csv    # in another terminal, for each
```

FP8 compute needs FP8 tensor cores (Ada, e.g. L4/L40S, or Hopper, e.g. H100/H200). On older GPUs some vLLM versions fall back to FP8 weights with 16-bit math (smaller, not faster), and some refuse. Benchmark throughput with vLLM's serving benchmark (`vllm bench serve` in recent versions).

**2. Serve a pre-quantized INT4 checkpoint** (AWQ or GPTQ, usually group size 128). vLLM normally detects the method from the checkpoint's config; you can also pass `--quantization awq`:

```bash
vllm serve <org>/<model>-AWQ
```

**3. Evaluate both with lm-evaluation-harness** on tasks that break first (math, code), then on your own eval set:

```bash
pip install lm-eval
lm_eval --model vllm --model_args pretrained=<model>,dtype=bfloat16 --tasks gsm8k --batch_size auto
lm_eval --model vllm --model_args pretrained=<model>,quantization=fp8 --tasks gsm8k --batch_size auto
```

Generic benchmarks are a smoke test. The decision is made on **your** prompts: lm-eval can run a custom task from a YAML file pointing at your own data. Record size, tokens/s, and quality for both, like `quantize.py` does.

---

## Deliverable (portfolio)

Commit `reports/quantize.md`, `reports/distill.md`, `reports/prune.md`, `reports/router.md` and add a Module 2 section to your `FINDINGS.md`:

1. Baseline: the model, its size, accuracy and rare-slice accuracy, and cost per 1M tokens
2. What you changed, one step at a time (precision, then routing)
3. The result, with numbers: cost -94%, accuracy -0.1 pts, rare slice -0.7 pts (use yours)
4. What broke first, and why (INT8 per-tensor and outliers; the rare slice)
5. What you would do next, and the caveat you would tell your manager (escalation latency, the cost model)

**Resume line you can now defend:** _Built a quantization, distillation and routing evaluation harness; showed per-channel INT8 within 0.1 pt where per-tensor lost 18.5, and cut modelled serving cost 94% at -0.1 pt accuracy by routing to a 113x smaller distilled model._

## Interview check

- How would you quantize a model for production without hurting quality? (start at FP8/INT8 per-channel or INT4 group-128, measure on your own eval set and the rare slice, turn the dial until quality moves, then stop)
- Why does per-channel or group-wise quantization beat per-tensor? (outliers set the scale; finer scales isolate them)
- Why doesn't unstructured pruning make a model faster? (dense kernels multiply zeros; you need structured or 2:4 sparsity with hardware that supports it)
- When would you distill instead of quantize? (when you need a step change in size or latency, have the teacher and your domain prompts, and can afford a training run)
- How do you pick a routing threshold? (sweep it on validation, report on held-out test, check escalated latency and quality per route)
