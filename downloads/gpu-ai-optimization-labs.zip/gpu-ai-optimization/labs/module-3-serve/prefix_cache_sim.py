#!/usr/bin/env python3
"""
Module 3 · Stage 5 — Prefix caching, and the timestamp that breaks it.

Most production prompts start the same way: a system prompt, tool definitions,
maybe a shared document. Prefix caching (vLLM --enable-prefix-caching; SGLang's
RadixAttention; provider "prompt caching") keeps the KV blocks for that shared
start and reuses them, so the next request only prefills what is new.

How a block-level prefix cache decides a hit (the vLLM approach, simplified):
  * the prompt is cut into fixed blocks of 16 tokens
  * each full block gets a hash of ITS tokens AND every token before it
  * a block is a hit only if that exact chain was seen before
So a single changed token invalidates its own block and every block after it.
That is why the stable part must come FIRST, and why "Current time: 12:04:31" at
the top of the prompt quietly sets the hit rate to zero.

The simulation: tenants share a 2,000-token system prompt + tool definitions; each
request adds its own short user turn. We run three prompt layouts through an LRU
block cache and count hit rate, prefill tokens saved and estimated TTFT.

Usage:
  python3 prefix_cache_sim.py
  python3 prefix_cache_sim.py --system 4000 --requests 1000 --cache-blocks 20000
"""
import argparse, hashlib, os, random
from collections import OrderedDict

HERE = os.path.dirname(os.path.abspath(__file__))


class PrefixCache:
    def __init__(self, capacity_blocks, block):
        self.cap, self.block, self.lru = capacity_blocks, block, OrderedDict()

    def lookup_and_insert(self, tokens):
        """returns how many leading prompt tokens were served from cache"""
        h = hashlib.sha256()
        hit_tokens, still_hitting = 0, True
        n_full = len(tokens) // self.block
        for b in range(n_full):
            h.update(repr(tokens[b * self.block:(b + 1) * self.block]).encode())
            key = h.hexdigest()                       # depends on this block AND all earlier blocks
            if still_hitting and key in self.lru:
                self.lru.move_to_end(key); hit_tokens += self.block
            else:
                still_hitting = False
                self.lru[key] = True
                if len(self.lru) > self.cap:
                    self.lru.popitem(last=False)
        return min(hit_tokens, len(tokens) - 1)        # the last token is always computed


def build_prompts(a, layout):
    rng = random.Random(a.seed)
    systems = [[rng.randrange(1, 128000) for _ in range(a.system)] for _ in range(a.tenants)]
    out = []
    for i in range(a.requests):
        tenant = rng.randrange(a.tenants)
        user = [rng.randrange(1, 128000) for _ in range(rng.randint(30, 300))]
        hh, mm, ss = 9 + i // 3600, (i // 60) % 60, i % 60   # one request per second
        stamp = [900000 + hh, 910000 + mm, 920000 + ss]       # "Current time: HH:MM:SS" as tokens
        if layout == "stable-first":
            p = systems[tenant] + user
        elif layout == "timestamp-first":
            p = stamp + systems[tenant] + user
        else:                                                 # timestamp moved after the stable part
            p = systems[tenant] + stamp + user
        out.append(p)
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--system", type=int, default=2000, help="tokens of system prompt + tool definitions")
    ap.add_argument("--tenants", type=int, default=4, help="distinct system prompts (apps or customers)")
    ap.add_argument("--requests", type=int, default=500)
    ap.add_argument("--block", type=int, default=16)
    ap.add_argument("--cache-blocks", type=int, default=5000, help="blocks the cache may keep (LRU)")
    ap.add_argument("--prefill-ms-per-tok", type=float, default=0.04, help="same constant as batch_sim.py")
    ap.add_argument("--seed", type=int, default=3)
    ap.add_argument("--out", default=os.path.join(HERE, "reports", "prefix_cache.md"))
    a = ap.parse_args()

    print(f"\n{a.requests} requests, {a.tenants} tenants, {a.system:,}-token shared prefix + 30-300 user tokens, "
          f"{a.block}-token blocks, cache {a.cache_blocks:,} blocks.\n")
    print(f"  {'prompt layout':18s} {'hit rate':>9s} {'prefill tokens':>15s} {'saved':>7s} {'mean TTFT*':>11s}")
    md = ["# Prefix caching", "",
          f"{a.requests} requests, {a.tenants} tenants, {a.system:,}-token shared prefix, {a.block}-token blocks, "
          f"LRU cache of {a.cache_blocks:,} blocks. TTFT* = prefill only, {a.prefill_ms_per_tok} ms/token.", "",
          "| Prompt layout | Hit rate | Prefill tokens computed | Saved | Mean TTFT* |", "|---|---:|---:|---:|---:|"]
    results = {}
    for layout in ("no cache", "stable-first", "timestamp-first", "timestamp-after"):
        prompts = build_prompts(a, "stable-first" if layout == "no cache" else layout)
        cache = PrefixCache(a.cache_blocks if layout != "no cache" else 0, a.block)
        total = sum(len(p) for p in prompts)
        hits = 0 if layout == "no cache" else sum(cache.lookup_and_insert(p) for p in prompts)
        computed = total - hits
        ttft = computed / len(prompts) * a.prefill_ms_per_tok
        results[layout] = (hits / total, computed, ttft)
        print(f"  {layout:18s} {hits/total:9.1%} {computed:15,d} {hits/total:7.1%} {ttft:8.0f} ms")
        md.append(f"| {layout} | {hits/total:.1%} | {computed:,} | {hits/total:.1%} | {ttft:.0f} ms |")
    base, good, bad = results["no cache"], results["stable-first"], results["timestamp-first"]
    print(f"\n  Stable prefix first: {good[0]:.0%} of prompt tokens come from cache; mean prefill "
          f"{base[2]:.0f} -> {good[2]:.0f} ms ({base[1]/good[1]:.1f}x less prefill work).")
    print(f"  Put a timestamp at the top: hit rate {good[0]:.0%} -> {bad[0]:.0%}. One changing token at the start "
          f"breaks every block after it.")
    print("  Move the timestamp after the stable part and you get the hits back.")
    print("  * TTFT here is prefill time only (no queueing); real gains depend on load and prompt length.\n")
    md += ["", f"Stable-first: hit rate **{good[0]:.0%}**, {base[1]/good[1]:.1f}x less prefill. "
               f"Timestamp-first: hit rate **{bad[0]:.0%}**."]
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    open(a.out, "w").write("\n".join(md) + "\n")
    print(f"wrote {os.path.relpath(a.out)}")


if __name__ == "__main__":
    main()
