#!/usr/bin/env python3
"""
Module 3 · Stage 6 — When does speculative decoding pay off?

A small, fast DRAFT model guesses the next k tokens. The big TARGET model checks
all k guesses in ONE forward pass (decode is memory-bound, so checking k tokens
costs about the same as generating one). Accepted guesses are free tokens.

With the standard rejection-sampling rule (Leviathan et al. 2023; Chen et al. 2023)
the output follows exactly the target model's distribution: accept draft token x
with probability min(1, p(x)/q(x)); on rejection, sample from max(0, p - q),
renormalized. With greedy decoding this reduces to "keep guesses while they match".

If each guess is accepted with probability alpha (assumed independent), and one
draft step costs c target steps, the expected speedup over plain decoding is

    tokens per target pass  = (1 - alpha^(k+1)) / (1 - alpha)
    speedup                 = (1 - alpha^(k+1)) / ((1 - alpha) * (k*c + 1))

Predictable text (code, JSON, boilerplate) has high alpha and speeds up most. Low
alpha, an expensive draft, or a k that is too big can make it SLOWER than no
speculation. Also, at large batch sizes the target becomes compute-bound, so
verifying k tokens is no longer "free" and real gains shrink; measure on your traffic.

This script prints the formula table and checks it two ways by Monte-Carlo:
tokens accepted per pass, and that rejection sampling really preserves p.

Usage:
  python3 spec_decode.py              # c = 0.05 (draft ~1/20 the cost of the target)
  python3 spec_decode.py --c 0.25     # an expensive draft
"""
import argparse, os, random

HERE = os.path.dirname(os.path.abspath(__file__))


def speedup(alpha, k, c):
    return (1 - alpha ** (k + 1)) / ((1 - alpha) * (k * c + 1))


def tokens_per_pass(alpha, k):
    return (1 - alpha ** (k + 1)) / (1 - alpha)


def mc_tokens_per_pass(alpha, k, trials, rng):
    tot = 0
    for _ in range(trials):
        acc = 0
        while acc < k and rng.random() < alpha:
            acc += 1
        tot += acc + 1          # +1: the target's own token (a correction, or a bonus if all k were accepted)
    return tot / trials


def mc_distribution(trials, rng):
    p = [0.40, 0.25, 0.15, 0.10, 0.06, 0.04]           # target model's next-token distribution
    q = [0.20, 0.35, 0.20, 0.05, 0.15, 0.05]           # draft model's (different) distribution
    resid = [max(0.0, pi - qi) for pi, qi in zip(p, q)]
    z = sum(resid); resid = [r / z for r in resid]
    counts = [0] * len(p)
    accepted = 0
    for _ in range(trials):
        x = rng.choices(range(len(q)), q)[0]
        if rng.random() < min(1.0, p[x] / q[x]):
            accepted += 1
        else:
            x = rng.choices(range(len(p)), resid)[0]
        counts[x] += 1
    emp = [c / trials for c in counts]
    alpha = sum(min(pi, qi) for pi, qi in zip(p, q))
    return p, emp, alpha, accepted / trials


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--c", type=float, default=0.05, help="cost of one draft step / one target step")
    ap.add_argument("--trials", type=int, default=20000)
    ap.add_argument("--seed", type=int, default=11)
    ap.add_argument("--out", default=os.path.join(HERE, "reports", "spec_decode.md"))
    a = ap.parse_args()
    rng = random.Random(a.seed)
    alphas = (0.5, 0.6, 0.7, 0.8, 0.9)
    ks = range(1, 9)

    print(f"\nExpected speedup, draft cost c = {a.c} (Leviathan et al. 2023). Best k per row marked *.\n")
    print("  alpha | " + " ".join(f"{'k=' + str(k):>6s}" for k in ks))
    md = ["# Speculative decoding: expected speedup", "",
          f"speedup = (1 - a^(k+1)) / ((1 - a)(k*c + 1)), c = {a.c}. Best k per row in bold.", "",
          "| alpha | " + " | ".join(f"k={k}" for k in ks) + " |", "|---" * (len(ks) + 1) + "|"]
    for al in alphas:
        vals = [speedup(al, k, a.c) for k in ks]
        best = max(range(len(vals)), key=lambda i: vals[i])
        print(f"  {al:5.1f} | " + " ".join(f"{v:5.2f}{'*' if i == best else ' '}" for i, v in enumerate(vals)))
        md.append(f"| {al} | " + " | ".join(f"**{v:.2f}**" if i == best else f"{v:.2f}" for i, v in enumerate(vals)) + " |")

    print("\n  Where it stops paying:")
    md += ["", "Where it stops paying:", ""]
    for why, al, k, c in (("k too big for the text", 0.5, 8, a.c), ("expensive draft, hard text", 0.4, 4, 0.25),
                          ("expensive draft, big k", 0.6, 8, 0.25)):
        s = speedup(al, k, c)
        tag = "SLOWER than no speculation" if s < 1 else f"(vs {max(speedup(al, j, c) for j in ks):.2f}x at the best k)"
        print(f"    {why:27s} alpha {al}, k {k}, c {c}:  {s:.2f}x  {tag}")
        md.append(f"- {why}: alpha {al}, k {k}, c {c}: **{s:.2f}x** {tag}")

    print(f"\n  Monte-Carlo check, tokens per target pass ({a.trials:,} passes each):")
    md += ["", "Monte-Carlo check, tokens per target pass:", "", "| alpha | k | formula | simulated |", "|---|---|---:|---:|"]
    for al, k in ((0.6, 4), (0.8, 4), (0.9, 8)):
        f, m = tokens_per_pass(al, k), mc_tokens_per_pass(al, k, a.trials, rng)
        print(f"    alpha {al}, k {k}:  formula {f:.3f}   simulated {m:.3f}")
        md.append(f"| {al} | {k} | {f:.3f} | {m:.3f} |")

    p, emp, alpha, acc = mc_distribution(a.trials * 5, rng)
    err = max(abs(x - y) for x, y in zip(p, emp))
    print(f"\n  Rejection sampling keeps the target's distribution ({a.trials*5:,} samples, draft != target):")
    print("    target p   " + " ".join(f"{x:.3f}" for x in p))
    print("    output     " + " ".join(f"{x:.3f}" for x in emp) + f"   max error {err:.3f}")
    print(f"    acceptance rate {acc:.3f} (theory: sum of min(p, q) = {alpha:.3f})\n")
    md += ["", f"Rejection sampling: output matches target p within {err:.3f} (max abs error); "
               f"acceptance {acc:.3f} vs theory {alpha:.3f}."]
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    open(a.out, "w").write("\n".join(md) + "\n")
    print(f"wrote {os.path.relpath(a.out)}")


if __name__ == "__main__":
    main()
