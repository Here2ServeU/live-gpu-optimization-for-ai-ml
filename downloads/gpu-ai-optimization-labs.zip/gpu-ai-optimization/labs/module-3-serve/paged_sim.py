#!/usr/bin/env python3
"""
Module 3 · Stage 3 — Contiguous reservation vs paged KV blocks.

The old way: when a request starts, reserve one contiguous slab of KV memory big
enough for the LONGEST answer it might write (prompt + max_tokens), because you do
not know how long the answer will be. Two kinds of waste follow:
  * internal fragmentation: reserved slots the answer never fills
  * external fragmentation: free memory chopped into holes too small for the next slab

The paged way (PagedAttention, introduced by vLLM): split the KV cache into fixed
blocks of, say, 16 tokens, and give a sequence a new block only when it needs one,
like an operating system hands out virtual-memory pages. Waste is at most one
partly-filled block per sequence. If memory runs out mid-answer, the newest
sequence is preempted (its blocks are freed and it is recomputed later).

The simulation: a backlog of requests from data/requests.csv, a fixed KV budget,
one decode token per running sequence per step. We measure how many sequences run
at once, what share of the allocated memory holds real tokens, and how many
requests finish in the same number of steps.

Usage:
  python3 paged_sim.py                        # 50 GiB budget (Llama-3-8B FP16 on one A100-80GB), max 256 seqs
  python3 paged_sim.py --max-seqs 0           # no cap: pack memory full (watch preemptions)
  python3 paged_sim.py --kv-gib 23 --block 32
  python3 paged_sim.py --max-tokens 8192      # reserve for the model's full context
"""
import argparse, csv, os

HERE = os.path.dirname(os.path.abspath(__file__))
KV_KIB_PER_TOKEN = 128     # Llama-3-8B, FP16 (see kv_calc.py)


def load_requests(path, n):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))[:n]
    return [(int(r["prompt_tokens"]), int(r["output_tokens"])) for r in rows]


def run_contiguous(reqs, cap, max_tokens, steps, max_seqs=0):
    """First-fit contiguous allocation of prompt + max_tokens per request."""
    free = [(0, cap)]                      # sorted list of (start, length) holes
    queue = list(range(len(reqs)))
    running = {}                           # id -> [start, reserved, written, remaining]
    done = 0
    s_run = s_used = s_alloc = s_blocked_free = 0
    for _ in range(steps):
        # admit in FIFO order while the head of the queue fits in some hole
        while queue and not (max_seqs and len(running) >= max_seqs):
            rid = queue[0]
            need = reqs[rid][0] + max_tokens
            hole = next((i for i, (st, ln) in enumerate(free) if ln >= need), None)
            if hole is None:
                break
            st, ln = free[hole]
            free[hole] = (st + need, ln - need)
            if free[hole][1] == 0:
                free.pop(hole)
            running[rid] = [st, need, reqs[rid][0], reqs[rid][1]]
            queue.pop(0)
        # one decode step
        for rid in list(running):
            r = running[rid]
            r[2] += 1; r[3] -= 1
            if r[3] == 0:
                _release(free, r[0], r[1])
                del running[rid]; done += 1
        used = sum(r[2] for r in running.values())
        alloc = sum(r[1] for r in running.values())
        s_run += len(running); s_used += used; s_alloc += alloc
        if queue:
            s_blocked_free += cap - alloc   # memory free but unusable for the next request
    n = steps
    return {"running": s_run / n, "util": s_used / max(1, s_alloc), "alloc": s_alloc / n / cap,
            "stranded": s_blocked_free / n / cap, "done": done, "preempt": 0}


def _release(free, st, ln):
    free.append((st, ln)); free.sort()
    merged = []
    for s, l in free:
        if merged and merged[-1][0] + merged[-1][1] == s:
            merged[-1] = (merged[-1][0], merged[-1][1] + l)
        else:
            merged.append((s, l))
    free[:] = merged


def run_paged(reqs, cap, block, steps, max_seqs=0):
    """Blocks allocated on demand; preempt the newest sequence when blocks run out."""
    total_blocks = cap // block
    free_blocks = total_blocks
    queue = list(range(len(reqs)))
    running = {}                           # id -> [blocks, written, remaining]  (dict keeps admission order)
    done = preempt = 0
    s_run = s_used = s_alloc = 0
    blocks_for = lambda t: -(-t // block)
    for _ in range(steps):
        while queue and not (max_seqs and len(running) >= max_seqs):
            rid = queue[0]
            need = blocks_for(reqs[rid][0] + 1)
            if need > free_blocks:
                break
            free_blocks -= need
            running[rid] = [need, reqs[rid][0], reqs[rid][1]]
            queue.pop(0)
        for rid in list(running):
            if rid not in running:
                continue
            r = running[rid]
            if blocks_for(r[1] + 1) > r[0]:        # this token starts a new block
                while free_blocks == 0:
                    victim = next(reversed(running))
                    free_blocks += running[victim][0]
                    del running[victim]; preempt += 1
                    queue.insert(0, victim)          # recompute from scratch later
                    if victim == rid:
                        break
                if rid not in running:
                    continue
                r[0] += 1; free_blocks -= 1
            r[1] += 1; r[2] -= 1
            if r[2] == 0:
                free_blocks += r[0]
                del running[rid]; done += 1
        used = sum(r[1] for r in running.values())
        alloc = sum(r[0] for r in running.values()) * block
        s_run += len(running); s_used += used; s_alloc += alloc
    n = steps
    return {"running": s_run / n, "util": s_used / max(1, s_alloc), "alloc": s_alloc / n / cap,
            "stranded": 0.0, "done": done, "preempt": preempt}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--kv-gib", type=float, default=50.0, help="KV-cache budget in GiB (kv_calc.py prints yours)")
    ap.add_argument("--block", type=int, default=16, help="tokens per KV block (vLLM default 16)")
    ap.add_argument("--max-tokens", type=int, default=2048, help="answer length the contiguous way reserves for")
    ap.add_argument("--max-seqs", type=int, default=256, help="cap on running sequences, like vLLM --max-num-seqs (0 = no cap)")
    ap.add_argument("--steps", type=int, default=3000, help="decode steps to simulate")
    ap.add_argument("--requests", default=os.path.join(HERE, "data", "requests.csv"))
    ap.add_argument("--out", default=os.path.join(HERE, "reports", "paged_sim.md"))
    a = ap.parse_args()

    base = load_requests(a.requests, 100000)
    reqs = (base * (1 + 20 * a.steps // len(base)))         # cycle the mix so the backlog never runs dry
    cap = int(a.kv_gib * 1024 * 1024 // KV_KIB_PER_TOKEN)        # tokens that fit in the budget
    c = run_contiguous(reqs, cap, a.max_tokens, a.steps, a.max_seqs)
    p = run_paged(reqs, cap, a.block, a.steps, a.max_seqs)

    print(f"\nKV budget {a.kv_gib:g} GiB = {cap:,} tokens (Llama-3-8B FP16, {KV_KIB_PER_TOKEN} KiB/token). "
          f"Backlog: the {len(base):,}-request mix, repeated. {a.steps:,} decode steps.")
    print(f"Contiguous reserves prompt + {a.max_tokens:,} tokens per request. Paged uses {a.block}-token blocks.\n")
    print(f"  {'':12s} {'avg running':>11s} {'allocated KV':>13s} {'allocated KV':>13s} {'finished':>9s} {'preempted':>10s}")
    print(f"  {'':12s} {'sequences':>11s} {'holding tokens':>13s} {'wasted':>13s} {'requests':>9s} {'':>10s}")
    rows = [("contiguous", c), ("paged", p)]
    for name, r in rows:
        print(f"  {name:12s} {r['running']:11.0f} {r['util']:13.1%} {1-r['util']:13.1%} {r['done']:9d} {r['preempt']:10d}")
    gain = p["running"] / c["running"]
    print(f"\n  Paged runs {gain:.1f}x more sequences at once and finishes "
          f"{p['done']/max(1,c['done']):.1f}x more requests in the same number of steps.")
    print(f"  Contiguous also stranded {c['stranded']:.1%} of the budget on average: free, but in holes too small for the next request.")
    if p["preempt"]:
        print(f"  Paged packs memory so full that {p['preempt']} sequences were preempted and recomputed. Real servers")
        print("  keep a small free-block reserve and cap running sequences (--max-seqs) to limit this.")
    print("  (Each step here is one decode token for every running sequence; batch_sim.py prices the step.)\n")

    md = ["# Paged vs contiguous KV cache", "",
          f"KV budget **{a.kv_gib:g} GiB = {cap:,} tokens** (Llama-3-8B FP16). Backlog: the {len(base):,}-request mix in "
          f"`{os.path.relpath(a.requests, HERE)}`, repeated, {a.steps:,} decode steps. Contiguous reserves prompt + {a.max_tokens:,}; "
          f"paged uses {a.block}-token blocks.", "",
          "| Allocator | Avg running sequences | Allocated KV holding tokens | Allocated KV wasted | Finished | Preempted |",
          "|---|---:|---:|---:|---:|---:|"]
    for name, r in rows:
        md.append(f"| {name} | {r['running']:.0f} | {r['util']:.1%} | {1-r['util']:.1%} | {r['done']} | {r['preempt']} |")
    md += ["", f"Paged runs **{gain:.1f}x** more sequences at once. Contiguous also stranded {c['stranded']:.1%} "
               "of the budget in holes too small to use (external fragmentation)."]
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    open(a.out, "w").write("\n".join(md) + "\n")
    print(f"wrote {os.path.relpath(a.out)}")


if __name__ == "__main__":
    main()
