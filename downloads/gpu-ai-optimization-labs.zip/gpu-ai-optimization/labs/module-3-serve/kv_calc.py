#!/usr/bin/env python3
"""
Module 3 · Stage 2 — Size the KV cache.

While a model writes an answer, it keeps "notes" for every token it has seen: one
Key vector and one Value vector per layer per KV head. That is the KV cache. It
saves the model from recomputing the whole conversation for every new token, and
it lives in GPU memory next to the weights.

  KV bytes per token = 2 (K and V) x layers x KV heads x head_dim x bytes per value
  KV per sequence    = KV bytes per token x tokens in that sequence
  KV for the server  = KV per sequence x concurrent sequences

Weights are a FIXED cost (paid once). The KV cache is the VARIABLE cost: it grows with
context length x number of users, and it decides how many users fit on one GPU.

Memory budget (vLLM style): total GPU memory x gpu_memory_utilization (default 0.9),
minus the weights, minus runtime overhead (activations, CUDA graphs, allocator slack;
we assume 2 GB; measure yours). Whatever is left is the KV cache.

Simplifications: GPU memory is the spec-sheet figure in decimal GB; real usable memory
differs a little. Weights are params x bytes; quantized formats add small scale tensors.

Usage:
  python3 kv_calc.py --model llama-3-8b --context 8192 --users 32
  python3 kv_calc.py --model llama-3-8b --gpu A100-80GB --context 8192 --kv-dtype fp8
  python3 kv_calc.py --compare --gpu A100-80GB --context 4096
  python3 kv_calc.py --list
"""
import argparse, json, os

HERE = os.path.dirname(os.path.abspath(__file__))
BYTES = {"fp32": 4, "bf16": 2, "fp16": 2, "fp8": 1, "int8": 1, "int4": 0.5}
GiB = 1024 ** 3
KiB = 1024


def load(name):
    d = json.load(open(os.path.join(HERE, "data", name)))
    d.pop("_note", None)
    return d


def kv_bytes_per_token(m, kv_dtype):
    return 2 * m["layers"] * m["kv_heads"] * m["head_dim"] * BYTES[kv_dtype]


def kv_budget(gpu, m, weight_dtype, util, overhead_gb, n_gpus=1):
    total = gpu["memory_gb"] * 1e9 * n_gpus
    weights = m["params"] * BYTES[weight_dtype]
    return total * util - weights - overhead_gb * 1e9 * n_gpus, weights


def fit(m, gpu, context, kv_dtype, weight_dtype, util, overhead_gb, n_gpus=1):
    budget, weights = kv_budget(gpu, m, weight_dtype, util, overhead_gb, n_gpus)
    bpt = kv_bytes_per_token(m, kv_dtype)
    if budget <= 0:
        return {"budget": budget, "weights": weights, "tokens": 0, "seqs": 0}
    return {"budget": budget, "weights": weights, "tokens": int(budget // bpt),
            "seqs": int(budget // (bpt * context))}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--model", default="llama-3-8b")
    ap.add_argument("--context", type=int, default=8192, help="tokens per sequence (prompt + answer)")
    ap.add_argument("--users", type=int, default=32, help="concurrent sequences you want to serve")
    ap.add_argument("--gpu", help="show one GPU only (default: all GPUs in data/gpus.json)")
    ap.add_argument("--gpus", type=int, default=1, help="GPUs the model is split across (tensor parallel)")
    ap.add_argument("--kv-dtype", default="fp16", choices=BYTES)
    ap.add_argument("--weight-dtype", default="fp16", choices=BYTES)
    ap.add_argument("--gpu-util", type=float, default=0.9, help="like vLLM --gpu-memory-utilization")
    ap.add_argument("--overhead-gb", type=float, default=2.0, help="activations + runtime, per GPU (assumed)")
    ap.add_argument("--compare", action="store_true", help="FP16 vs FP8 KV, GQA vs no-GQA, on one GPU")
    ap.add_argument("--list", action="store_true", help="list the model configs")
    ap.add_argument("--out", help="markdown report (default reports/kv_calc.md, or reports/kv_compare.md with --compare)")
    a = ap.parse_args()
    a.out = a.out or os.path.join(HERE, "reports", "kv_compare.md" if a.compare else "kv_calc.md")

    models, gpus = load("models.json"), load("gpus.json")
    md = ["# KV-cache sizing", ""]

    if a.list:
        print(f"{'model':12s} {'params':>7s} {'layers':>6s} {'heads':>5s} {'KV heads':>8s} {'head_dim':>8s} {'KV/token fp16':>14s}")
        for k, m in models.items():
            print(f"{k:12s} {m['params']/1e9:6.1f}B {m['layers']:6d} {m['heads']:5d} {m['kv_heads']:8d} {m['head_dim']:8d} "
                  f"{kv_bytes_per_token(m, 'fp16')/KiB:10.0f} KiB")
        return

    if a.compare:
        g = a.gpu or "A100-80GB"
        ctx = a.context
        rows = []
        for key, kvd in (("llama-2-7b", "fp16"), ("llama-3-8b", "fp16"), ("llama-3-8b", "fp8")):
            m = models[key]
            r = fit(m, gpus[g], ctx, kvd, a.weight_dtype, a.gpu_util, a.overhead_gb)
            attn = "GQA" if m["kv_heads"] < m["heads"] else "MHA (no GQA)"
            rows.append((m["name"], attn, m["kv_heads"], kvd, kv_bytes_per_token(m, kvd) / KiB,
                         kv_bytes_per_token(m, kvd) * ctx / GiB, r["seqs"], r["tokens"]))
        print(f"\nOne {g}, {ctx:,}-token sequences, weights {a.weight_dtype}, gpu-util {a.gpu_util}, overhead {a.overhead_gb} GB")
        print(f"  {'model':11s} {'attention':13s} {'KV heads':>8s} {'KV dtype':>8s} {'KV/token':>9s} {'per seq':>9s} {'max seqs':>9s} {'cache tokens':>13s}")
        md += [f"## Compare on one {g} at {ctx:,} tokens per sequence", "",
               "| Model | Attention | KV heads | KV dtype | KV / token | Per sequence | Max sequences | Tokens in cache |",
               "|---|---|---:|---|---:|---:|---:|---:|"]
        for name, attn, kvh, kvd, kib, seq_gib, seqs, toks in rows:
            print(f"  {name:11s} {attn:13s} {kvh:8d} {kvd:>8s} {kib:5.0f} KiB {seq_gib:5.2f} GiB {seqs:9d} {toks:13,d}")
            md.append(f"| {name} | {attn} | {kvh} | {kvd} | {kib:.0f} KiB | {seq_gib:.2f} GiB | {seqs} | {toks:,} |")
        base, gqa, fp8 = rows[0][6], rows[1][6], rows[2][6]
        print(f"\n  GQA (32 -> 8 KV heads): {gqa/base:.1f}x more sequences.  FP8 KV on top: {fp8/gqa:.1f}x again "
              f"({base} -> {gqa} -> {fp8}).")
        print("  (Llama-3-8B also has more weights than Llama-2-7B, so the GQA gain is a little under 4x.)\n")
        md += ["", f"GQA: {gqa/base:.1f}x more sequences; FP8 KV on top: {fp8/gqa:.1f}x again ({base} -> {gqa} -> {fp8})."]
        _write(a.out, md)
        return

    m = models[a.model]
    bpt = kv_bytes_per_token(m, a.kv_dtype)
    per_seq = bpt * a.context
    need = per_seq * a.users
    weights = m["params"] * BYTES[a.weight_dtype]
    if a.context > m["max_context"]:
        print(f"  note: {m['name']} was trained for {m['max_context']:,} tokens; {a.context:,} is beyond that.")
    print(f"\n{m['name']}  ({m['layers']} layers, {m['kv_heads']} KV heads of {m['heads']}, head_dim {m['head_dim']}, KV in {a.kv_dtype})")
    print(f"  KV per token   = 2 x {m['layers']} x {m['kv_heads']} x {m['head_dim']} x {BYTES[a.kv_dtype]} B = {bpt:,.0f} B = {bpt/KiB:.0f} KiB")
    print(f"  per sequence   = {bpt/KiB:.0f} KiB x {a.context:,} tokens = {per_seq/GiB:.2f} GiB")
    print(f"  {a.users} users     = {need/GiB:.1f} GiB of KV cache  + {weights/GiB:.1f} GiB of weights ({a.weight_dtype})")
    md += [f"## {m['name']}, {a.context:,} tokens, {a.users} users, KV {a.kv_dtype}, weights {a.weight_dtype}", "",
           f"- KV per token: 2 x {m['layers']} x {m['kv_heads']} x {m['head_dim']} x {BYTES[a.kv_dtype]} B = **{bpt/KiB:.0f} KiB**",
           f"- Per sequence at {a.context:,} tokens: **{per_seq/GiB:.2f} GiB**",
           f"- {a.users} concurrent users: **{need/GiB:.1f} GiB** of KV cache, plus {weights/GiB:.1f} GiB of weights", "",
           f"Budget per GPU = memory x {a.gpu_util} - weights - {a.overhead_gb} GB overhead.", "",
           "| GPU | KV budget | Tokens in cache | Max sequences at this context | Fits the users? |",
           "|---|---:|---:|---:|---|"]
    print(f"\n  {'GPU':12s} {'KV budget':>10s} {'cache tokens':>13s} {'max seqs @ ' + format(a.context, ','):>16s}  {a.users} users?")
    for gname, g in gpus.items():
        if a.gpu and gname != a.gpu:
            continue
        r = fit(m, g, a.context, a.kv_dtype, a.weight_dtype, a.gpu_util, a.overhead_gb, a.gpus)
        if r["budget"] <= 0:
            verdict = "weights do not fit"
            print(f"  {gname:12s} {'-':>10s} {'-':>13s} {'-':>16s}  {verdict}")
            md.append(f"| {gname} | - | - | - | {verdict} |")
            continue
        verdict = "yes" if r["seqs"] >= a.users else f"no ({r['seqs']} max)"
        print(f"  {gname:12s} {r['budget']/GiB:6.1f} GiB {r['tokens']:13,d} {r['seqs']:16d}  {verdict}")
        md.append(f"| {gname} | {r['budget']/GiB:.1f} GiB | {r['tokens']:,} | {r['seqs']} | {verdict} |")
    print("\n  Weights are the fixed cost. The KV cache is the variable cost that decides how many users fit.")
    print("  Shrink it: FP8 KV (--kv-dtype fp8), GQA models, shorter prompts, and paging (paged_sim.py).\n")
    _write(a.out, md)


def _write(path, md):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w") as f:
        f.write("\n".join(md) + "\n")
    print(f"wrote {os.path.relpath(path)}")


if __name__ == "__main__":
    main()
