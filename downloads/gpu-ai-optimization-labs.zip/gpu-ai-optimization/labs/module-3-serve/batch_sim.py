#!/usr/bin/env python3
"""
Module 3 · Stage 4 — Static vs continuous batching, simulated.

Requests arrive at random (data/requests.csv: Poisson arrivals, skewed prompt and
answer lengths). One GPU serves them. Two schedulers:

  static      When the server is free, take up to B waiting requests, run them
              together until the LONGEST answer is done, then take the next group.
              Short answers finish early, but their slots sit idle; new arrivals wait.
  continuous  (also called in-flight or iteration-level batching; vLLM, TGI, TensorRT-LLM)
              Re-decide the batch every decode step. Finished sequences leave at once,
              waiting requests join at once, up to --max-batch (vLLM: --max-num-seqs)
              and the KV-cache budget.

Step-time model (illustrative constants, roughly an 8B FP16 model on one H100-class GPU;
change them with flags, and replace them with measurements from your own server):

  decode step   = 8 ms + 0.05 ms x sequences in the batch   (memory-bound: weights are read
                                                              once per step, shared by the batch)
  prefill       = 0.04 ms x prompt tokens                    (compute-bound)

Without chunked prefill, a new request's whole prompt is processed inside one step,
so every decoding user waits for it (prefill-decode interference). With --chunk N,
each step processes at most N tokens in total and long prompts are split across steps.

Simplifications: no network, tokenizer or sampling time; static batching is not
memory-limited here (that is generous to static); prefill cost is linear in length.
It is a model of the scheduler, not a benchmark. Every run is deterministic.

Usage:
  python3 batch_sim.py                               # static vs continuous at max batch 256
  python3 batch_sim.py --sweep                       # sweep max batch: find the knee
  python3 batch_sim.py --chunk 1024                  # add continuous + chunked prefill
  python3 batch_sim.py --rate 6 --max-batch 64       # heavier traffic, smaller cap
"""
import argparse, csv, os

HERE = os.path.dirname(os.path.abspath(__file__))


def load(path, rate):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    base_rate = len(rows) / float(rows[-1]["arrival_s"])
    scale = base_rate / rate if rate else 1.0                 # stretch or squeeze the same arrival pattern
    return [{"arr": float(r["arrival_s"]) * scale, "p": int(r["prompt_tokens"]), "o": int(r["output_tokens"])}
            for r in rows]


def pct(xs, q):
    xs = sorted(xs)
    return xs[min(len(xs) - 1, int(q / 100 * len(xs)))] if xs else float("nan")


def wpct(pairs, q):
    """weighted percentile of (value, weight) pairs"""
    pairs = sorted(pairs); tot = sum(w for _, w in pairs); acc = 0
    for v, w in pairs:
        acc += w
        if acc >= q / 100 * tot:
            return v
    return float("nan")


class Cost:
    def __init__(self, a):
        self.base, self.per_seq, self.pre = a.decode_base_ms / 1e3, a.decode_per_seq_ms / 1e3, a.prefill_ms_per_tok / 1e3

    def decode(self, n):
        return self.base + self.per_seq * n if n else 0.0

    def prefill(self, tokens):
        return self.pre * tokens


def static(reqs, B, cost):
    t = 0.0; i = 0; n = len(reqs)
    first, fin, itl = [0.0] * n, [0.0] * n, []
    run_area = wait_area = 0.0
    while i < n:
        if reqs[i]["arr"] > t:
            t = reqs[i]["arr"]
        batch = [j for j in range(i, n) if reqs[j]["arr"] <= t][:B]
        i += len(batch)
        t0 = t
        t += cost.prefill(sum(reqs[j]["p"] for j in batch))
        step = cost.decode(len(batch))                        # finished rows are padding: they still ride along
        longest = max(reqs[j]["o"] for j in batch)
        for j in batch:
            first[j] = t
            fin[j] = t + (reqs[j]["o"] - 1) * step
        if longest > 1:
            itl.append((step, sum(reqs[j]["o"] - 1 for j in batch)))
        t_end = t + (longest - 1) * step
        run_area += len(batch) * (t_end - t0)
        waiting_ids = [j for j in range(i, n) if reqs[j]["arr"] < t_end]
        wait_area += sum(t_end - max(t0, reqs[j]["arr"]) for j in waiting_ids)
        t = t_end
    return summarize(reqs, first, fin, itl, run_area, wait_area, preempt=0)


def continuous(reqs, B, cost, kv_tokens, chunk=0):
    n = len(reqs); t = 0.0; nxt = 0
    queue, running = [], []             # running: dicts with id, done (prompt tokens processed), gen
    first, fin, itl = [0.0] * n, [0.0] * n, []
    run_area = wait_area = 0.0; preempt = 0
    while nxt < n or queue or running:
        while nxt < n and reqs[nxt]["arr"] <= t:
            queue.append(nxt); nxt += 1
        if not queue and not running:
            t = reqs[nxt]["arr"]; continue
        # admit: max batch and KV budget (tokens currently held + the new prompt)
        held = sum(r["done"] + r["gen"] for r in running)
        while queue and len(running) < B and held + reqs[queue[0]]["p"] <= kv_tokens:
            j = queue.pop(0)
            running.append({"id": j, "done": 0, "gen": 0}); held += reqs[j]["p"]
        decoders = [r for r in running if r["done"] >= reqs[r["id"]]["p"]]
        prefilling = [r for r in running if r["done"] < reqs[r["id"]]["p"]]
        budget = (chunk - len(decoders)) if chunk else float("inf")
        pre_tok = 0
        for r in prefilling:
            if budget <= 0:
                break
            take = min(reqs[r["id"]]["p"] - r["done"], budget)
            r["done"] += take; pre_tok += take; budget -= take
        dt = cost.decode(len(decoders)) + cost.prefill(pre_tok)
        if not decoders and pre_tok:
            dt += cost.base                                     # a step always reads the weights once
        run_area += len(running) * dt; wait_area += len(queue) * dt
        t += dt
        if decoders:
            itl.append((dt, len(decoders)))
        for r in decoders:
            r["gen"] += 1
        for r in prefilling:
            if r["done"] >= reqs[r["id"]]["p"] and r["gen"] == 0:   # prefill finished: emits the first token
                r["gen"] = 1; first[r["id"]] = t
        for r in list(running):
            if r["gen"] >= reqs[r["id"]]["o"]:
                fin[r["id"]] = t; running.remove(r)
        # KV overflow while sequences grow: preempt the newest and recompute later
        while running and sum(r["done"] + r["gen"] for r in running) > kv_tokens:
            v = running.pop(); queue.insert(0, v["id"]); preempt += 1
    return summarize(reqs, first, fin, itl, run_area, wait_area, preempt)


def summarize(reqs, first, fin, itl, run_area, wait_area, preempt):
    t0 = min(r["arr"] for r in reqs); t1 = max(fin)
    ttft = [first[j] - r["arr"] for j, r in enumerate(reqs)]
    e2e = [fin[j] - r["arr"] for j, r in enumerate(reqs)]
    out = sum(r["o"] for r in reqs)
    span = t1 - t0
    return {"tok_s": out / span, "req_s": len(reqs) / span, "span": span,
            "ttft50": pct(ttft, 50), "ttft95": pct(ttft, 95), "e2e95": pct(e2e, 95),
            "itl95": wpct(itl, 95) * 1e3 if itl else 0.0,
            "running": run_area / span, "waiting": wait_area / span, "preempt": preempt}


def row(name, m):
    return (f"  {name:24s} {m['tok_s']:8,.0f} {m['ttft50']:8.2f} {m['ttft95']:8.2f} {m['e2e95']:8.1f} "
            f"{m['itl95']:8.1f} {m['running']:8.1f} {m['waiting']:8.1f}")


HEAD = (f"  {'scheduler':24s} {'tok/s':>8s} {'TTFT p50':>8s} {'TTFT p95':>8s} {'E2E p95':>8s} "
        f"{'ITL p95':>8s} {'running':>8s} {'waiting':>8s}\n"
        f"  {'':24s} {'output':>8s} {'s':>8s} {'s':>8s} {'s':>8s} {'ms':>8s} {'avg':>8s} {'avg':>8s}")
MD_HEAD = ["| Scheduler | Output tok/s | TTFT p50 (s) | TTFT p95 (s) | E2E p95 (s) | ITL p95 (ms) | Avg running | Avg waiting |",
           "|---|---:|---:|---:|---:|---:|---:|---:|"]


def md_row(name, m):
    return (f"| {name} | {m['tok_s']:,.0f} | {m['ttft50']:.2f} | {m['ttft95']:.2f} | {m['e2e95']:.1f} | "
            f"{m['itl95']:.1f} | {m['running']:.1f} | {m['waiting']:.1f} |")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--requests", default=os.path.join(HERE, "data", "requests.csv"))
    ap.add_argument("--rate", type=float, default=0, help="arrivals per second (default: as recorded, ~4/s)")
    ap.add_argument("--max-batch", type=int, default=256, help="static group size; continuous max running sequences")
    ap.add_argument("--kv-tokens", type=int, default=409600, help="KV budget in tokens (50 GiB of Llama-3-8B FP16)")
    ap.add_argument("--chunk", type=int, default=0, help="also run continuous + chunked prefill with this token budget per step")
    ap.add_argument("--decode-base-ms", type=float, default=8.0)
    ap.add_argument("--decode-per-seq-ms", type=float, default=0.05)
    ap.add_argument("--prefill-ms-per-tok", type=float, default=0.04)
    ap.add_argument("--sweep", action="store_true", help="sweep max batch: find the knee")
    ap.add_argument("--out", help="markdown report (default reports/batch_sim.md, or batch_sweep.md with --sweep)")
    a = ap.parse_args()
    a.out = a.out or os.path.join(HERE, "reports", "batch_sweep.md" if a.sweep else "batch_sim.md")
    reqs = load(a.requests, a.rate)
    flood = load(a.requests, 1e6)                 # same requests, all queued at once: measures capacity
    cost = Cost(a)
    span = reqs[-1]["arr"] - reqs[0]["arr"]
    rate, offered = len(reqs) / span, sum(r["o"] for r in reqs) / span
    hdr = (f"{len(reqs)} requests at {rate:.1f} req/s (offered load ~{offered:,.0f} output tok/s). "
           f"Decode step {a.decode_base_ms:g} ms + {a.decode_per_seq_ms:g} ms/seq; prefill {a.prefill_ms_per_tok:g} ms/token.")
    print("\n" + hdr)
    md = ["# Static vs continuous batching (simulated)", "", hdr, ""]

    if a.sweep:
        print("\n  Capacity = output tok/s with every request queued at once. ITL = gap between tokens at capacity.")
        print(f"  TTFT p95 = at the recorded traffic ({rate:.1f} req/s).\n")
        print(f"  {'max batch':>9s} | {'static':>8s} | {'continuous':>10s} {'ITL p95':>8s} {'running':>8s} | {'TTFT p95':>8s}")
        print(f"  {'':9s} | {'tok/s':>8s} | {'tok/s':>10s} {'ms':>8s} {'avg':>8s} | {'s':>8s}")
        md += [f"Capacity = output tok/s with every request queued at once; ITL p95 at capacity; TTFT p95 at {rate:.1f} req/s.", "",
               "| Max batch | Static capacity tok/s | Continuous capacity tok/s | Continuous ITL p95 (ms) | Avg running | Continuous TTFT p95 (s) |",
               "|---:|---:|---:|---:|---:|---:|"]
        prev = None
        for B in (1, 4, 16, 32, 64, 128, 256, 512):
            s = static(flood, B, cost); c = continuous(flood, B, cost, a.kv_tokens, a.chunk)
            t = continuous(reqs, B, cost, a.kv_tokens, a.chunk)
            gain = f"  (+{(c['tok_s']/prev-1)*100:.0f}%)" if prev else ""
            print(f"  {B:9d} | {s['tok_s']:8,.0f} | {c['tok_s']:10,.0f} {c['itl95']:8.1f} {c['running']:8.1f} | {t['ttft95']:8.2f}{gain}")
            md.append(f"| {B} | {s['tok_s']:,.0f} | {c['tok_s']:,.0f} | {c['itl95']:.1f} | {c['running']:.1f} | {t['ttft95']:.2f} |")
            prev = c["tok_s"]
        print("\n  The knee: each doubling of max batch buys less throughput and costs more per-token latency.")
        print("  Pick the largest max batch whose ITL p95 still meets your target; past the knee you pay latency for little.\n")
        _write(a.out, md)
        return

    B = a.max_batch
    sched = [(f"static (B={B})", lambda r: static(r, B, cost)),
             (f"continuous (max {B})", lambda r: continuous(r, B, cost, a.kv_tokens, 0))]
    if a.chunk:
        sched.append((f"continuous + chunk {a.chunk}", lambda r: continuous(r, B, cost, a.kv_tokens, a.chunk)))
    res = []                                       # [traffic rows..., capacity rows...]
    for label, data in ((f"At the recorded traffic ({rate:.1f} req/s)", reqs), ("At capacity (every request queued at once)", flood)):
        print(f"\n  {label}\n" + HEAD)
        md += [f"### {label}", ""] + MD_HEAD
        for name, fn in sched:
            m = fn(data); res.append(m)
            print(row(name, m)); md.append(md_row(name, m))
        md.append("")
    n = len(sched)
    s_t, c_t, s_c, c_c = res[0], res[1], res[n], res[n + 1]
    line = (f"static -> continuous (one change, same GPU, same traffic): capacity {(c_c['tok_s']/s_c['tok_s']-1)*100:+.0f}% "
            f"({s_c['tok_s']:,.0f} -> {c_c['tok_s']:,.0f} tok/s), p95 TTFT {s_t['ttft95']:.1f} s -> {c_t['ttft95']:.2f} s, "
            f"p95 end-to-end {s_t['e2e95']:.1f} s -> {c_t['e2e95']:.1f} s")
    print("\n  " + line)
    if a.chunk:
        k = res[-1]
        cl = (f"chunked prefill at capacity: ITL p95 {c_c['itl95']:.1f} -> {k['itl95']:.1f} ms, "
              f"throughput {(k['tok_s']/c_c['tok_s']-1)*100:+.1f}%")
        print("  " + cl); md += [f"- {cl}"]
    pre = sum(m["preempt"] for m in res)
    if pre:
        print(f"  (continuous preempted {pre} sequences when the KV cache filled)")
    print()
    md += [f"- **{line}**", "",
           "> FINDINGS.md line: _Switched static to continuous batching: capacity +X%, p95 TTFT A s -> B s, same GPU and traffic._"]
    _write(a.out, md)


def _write(path, md):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w") as f:
        f.write("\n".join(md) + "\n")
    print(f"wrote {os.path.relpath(path)}")


if __name__ == "__main__":
    main()
