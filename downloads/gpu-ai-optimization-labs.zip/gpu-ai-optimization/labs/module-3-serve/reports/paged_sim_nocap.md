# Paged vs contiguous KV cache

KV budget **50 GiB = 409,600 tokens** (Llama-3-8B FP16). Backlog: the 1,200-request mix in `data/requests.csv`, repeated, 3,000 decode steps. Contiguous reserves prompt + 2,048; paged uses 16-token blocks.

| Allocator | Avg running sequences | Allocated KV holding tokens | Allocated KV wasted | Finished | Preempted |
|---|---:|---:|---:|---:|---:|
| contiguous | 134 | 33.5% | 66.5% | 1476 | 0 |
| paged | 444 | 99.2% | 0.8% | 4853 | 993 |

Paged runs **3.3x** more sequences at once. Contiguous also stranded 11.6% of the budget in holes too small to use (external fragmentation).
