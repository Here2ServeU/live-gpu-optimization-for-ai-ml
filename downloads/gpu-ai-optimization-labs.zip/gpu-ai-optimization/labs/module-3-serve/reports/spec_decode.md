# Speculative decoding: expected speedup

speedup = (1 - a^(k+1)) / ((1 - a)(k*c + 1)), c = 0.05. Best k per row in bold.

| alpha | k=1 | k=2 | k=3 | k=4 | k=5 | k=6 | k=7 | k=8 |
|---|---|---|---|---|---|---|---|---|
| 0.5 | 1.43 | 1.59 | **1.63** | 1.61 | 1.57 | 1.53 | 1.48 | 1.43 |
| 0.6 | 1.52 | 1.78 | 1.89 | **1.92** | 1.91 | 1.87 | 1.82 | 1.77 |
| 0.7 | 1.62 | 1.99 | 2.20 | 2.31 | 2.35 | **2.35** | 2.33 | 2.28 |
| 0.8 | 1.71 | 2.22 | 2.57 | 2.80 | 2.95 | 3.04 | 3.08 | **3.09** |
| 0.9 | 1.81 | 2.46 | 2.99 | 3.41 | 3.75 | 4.01 | 4.22 | **4.38** |

Where it stops paying:

- k too big for the text: alpha 0.5, k 8, c 0.05: **1.43x** (vs 1.63x at the best k)
- expensive draft, hard text: alpha 0.4, k 4, c 0.25: **0.82x** SLOWER than no speculation
- expensive draft, big k: alpha 0.6, k 8, c 0.25: **0.82x** SLOWER than no speculation

Monte-Carlo check, tokens per target pass:

| alpha | k | formula | simulated |
|---|---|---:|---:|
| 0.6 | 4 | 2.306 | 2.312 |
| 0.8 | 4 | 3.362 | 3.376 |
| 0.9 | 8 | 6.126 | 6.122 |

Rejection sampling: output matches target p within 0.002 (max abs error); acceptance 0.749 vs theory 0.750.
