# Paged vs contiguous KV cache

KV budget **50 GiB = 409,600 tokens** (Llama-3-8B FP16). Backlog: the 1,200-request mix in `data/requests.csv`, repeated, 3,000 decode steps. Contiguous reserves prompt + 8,192; paged uses 16-token blocks.

| Allocator | Avg running sequences | Allocated KV holding tokens | Allocated KV wasted | Finished | Preempted |
|---|---:|---:|---:|---:|---:|
| contiguous | 40 | 9.9% | 90.1% | 447 | 0 |
| paged | 255 | 99.2% | 0.8% | 2803 | 0 |

Paged runs **6.4x** more sequences at once. Contiguous also stranded 14.5% of the budget in holes too small to use (external fragmentation).
