# Static vs continuous batching (simulated)

1200 requests at 4.1 req/s (offered load ~1,142 output tok/s). Decode step 8 ms + 0.05 ms/seq; prefill 0.04 ms/token.

Capacity = output tok/s with every request queued at once; ITL p95 at capacity; TTFT p95 at 4.1 req/s.

| Max batch | Static capacity tok/s | Continuous capacity tok/s | Continuous ITL p95 (ms) | Avg running | Continuous TTFT p95 (s) |
|---:|---:|---:|---:|---:|---:|
| 1 | 123 | 123 | 8.1 | 1.0 | 2293.23 |
| 4 | 232 | 466 | 8.2 | 4.0 | 397.56 |
| 16 | 472 | 1,513 | 13.8 | 15.6 | 0.60 |
| 32 | 670 | 2,361 | 31.6 | 29.8 | 0.10 |
| 64 | 941 | 3,265 | 48.9 | 56.2 | 0.10 |
| 128 | 1,197 | 4,042 | 70.1 | 106.0 | 0.10 |
| 256 | 1,495 | 4,599 | 104.5 | 200.9 | 0.10 |
| 512 | 1,625 | 4,909 | 161.9 | 375.5 | 0.10 |
