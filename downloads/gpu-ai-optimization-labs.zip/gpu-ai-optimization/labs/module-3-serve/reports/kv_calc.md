# KV-cache sizing

## Llama-3-8B, 8,192 tokens, 32 users, KV fp16, weights fp16

- KV per token: 2 x 32 x 8 x 128 x 2 B = **128 KiB**
- Per sequence at 8,192 tokens: **1.00 GiB**
- 32 concurrent users: **32.0 GiB** of KV cache, plus 15.0 GiB of weights

Budget per GPU = memory x 0.9 - weights - 2.0 GB overhead.

| GPU | KV budget | Tokens in cache | Max sequences at this context | Fits the users? |
|---|---:|---:|---:|---|
| L4 | 3.3 GiB | 27,008 | 3 | no (3 max) |
| A10G | 3.3 GiB | 27,008 | 3 | no (3 max) |
| L40S | 23.4 GiB | 191,802 | 23 | no (23 max) |
| A100-80GB | 50.2 GiB | 411,529 | 50 | yes |
| H100-SXM | 50.2 GiB | 411,529 | 50 | yes |
| H200 | 101.4 GiB | 830,383 | 101 | yes |
