# KV-cache sizing

## Llama-3-8B, 8,192 tokens, 32 users, KV fp8, weights fp16

- KV per token: 2 x 32 x 8 x 128 x 1 B = **64 KiB**
- Per sequence at 8,192 tokens: **0.50 GiB**
- 32 concurrent users: **16.0 GiB** of KV cache, plus 15.0 GiB of weights

Budget per GPU = memory x 0.9 - weights - 2.0 GB overhead.

| GPU | KV budget | Tokens in cache | Max sequences at this context | Fits the users? |
|---|---:|---:|---:|---|
| L4 | 3.3 GiB | 54,016 | 6 | no (6 max) |
| A10G | 3.3 GiB | 54,016 | 6 | no (6 max) |
| L40S | 23.4 GiB | 383,605 | 46 | yes |
| A100-80GB | 50.2 GiB | 823,059 | 100 | yes |
| H100-SXM | 50.2 GiB | 823,059 | 100 | yes |
| H200 | 101.4 GiB | 1,660,766 | 202 | yes |
