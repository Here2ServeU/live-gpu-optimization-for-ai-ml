# Prefix caching

500 requests, 4 tenants, 2,000-token shared prefix, 16-token blocks, LRU cache of 5,000 blocks. TTFT* = prefill only, 0.04 ms/token.

| Prompt layout | Hit rate | Prefill tokens computed | Saved | Mean TTFT* |
|---|---:|---:|---:|---:|
| no cache | 0.0% | 1,080,494 | 0.0% | 86 ms |
| stable-first | 91.8% | 88,494 | 91.8% | 7 ms |
| timestamp-first | 0.0% | 1,081,994 | 0.0% | 87 ms |
| timestamp-after | 91.7% | 89,994 | 91.7% | 7 ms |

Stable-first: hit rate **92%**, 12.2x less prefill. Timestamp-first: hit rate **0%**.
