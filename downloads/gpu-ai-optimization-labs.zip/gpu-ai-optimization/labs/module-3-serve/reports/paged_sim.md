# Paged vs contiguous KV cache

KV budget **50 GiB = 409,600 tokens** (Llama-3-8B FP16). Backlog: the 1,200-request mix in `data/requests.csv`, repeated, 3,000 decode steps. Contiguous reserves prompt + 2,048; paged uses 16-token blocks.

| Allocator | Avg running sequences | Allocated KV holding tokens | Allocated KV wasted | Finished | Preempted |
|---|---:|---:|---:|---:|---:|
| contiguous | 134 | 33.5% | 66.5% | 1476 | 0 |
| paged | 255 | 99.2% | 0.8% | 2803 | 0 |

Paged runs **1.9x** more sequences at once. Contiguous also stranded 11.6% of the budget in holes too small to use (external fragmentation).
