# Static vs continuous batching (simulated)

1200 requests at 4.1 req/s (offered load ~1,142 output tok/s). Decode step 8 ms + 0.05 ms/seq; prefill 0.04 ms/token.

### At the recorded traffic (4.1 req/s)

| Scheduler | Output tok/s | TTFT p50 (s) | TTFT p95 (s) | E2E p95 (s) | ITL p95 (ms) | Avg running | Avg waiting |
|---|---:|---:|---:|---:|---:|---:|---:|
| static (B=256) | 1,048 | 15.92 | 31.54 | 37.5 | 15.7 | 100.9 | 51.3 |
| continuous (max 256) | 1,114 | 0.04 | 0.10 | 7.9 | 9.1 | 10.8 | 0.0 |
| continuous + chunk 1024 | 1,114 | 0.04 | 0.11 | 7.9 | 9.1 | 10.8 | 0.0 |

### At capacity (every request queued at once)

| Scheduler | Output tok/s | TTFT p50 (s) | TTFT p95 (s) | E2E p95 (s) | ITL p95 (ms) | Avg running | Avg waiting |
|---|---:|---:|---:|---:|---:|---:|---:|
| static (B=256) | 1,495 | 105.91 | 187.28 | 191.9 | 20.8 | 241.3 | 486.7 |
| continuous (max 256) | 4,599 | 23.34 | 49.51 | 58.1 | 104.5 | 200.9 | 385.9 |
| continuous + chunk 1024 | 4,540 | 24.39 | 50.49 | 59.1 | 51.5 | 201.7 | 387.5 |

- chunked prefill at capacity: ITL p95 104.5 -> 51.5 ms, throughput -1.3%
- **static -> continuous (one change, same GPU, same traffic): capacity +208% (1,495 -> 4,599 tok/s), p95 TTFT 31.5 s -> 0.10 s, p95 end-to-end 37.5 s -> 7.9 s**

> FINDINGS.md line: _Switched static to continuous batching: capacity +X%, p95 TTFT A s -> B s, same GPU and traffic._
