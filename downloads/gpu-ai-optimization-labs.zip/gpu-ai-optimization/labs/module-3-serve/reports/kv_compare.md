# KV-cache sizing

## Compare on one A100-80GB at 4,096 tokens per sequence

| Model | Attention | KV heads | KV dtype | KV / token | Per sequence | Max sequences | Tokens in cache |
|---|---|---:|---|---:|---:|---:|---:|
| Llama-2-7B | MHA (no GQA) | 32 | fp16 | 512 KiB | 2.00 GiB | 26 | 107,803 |
| Llama-3-8B | GQA | 8 | fp16 | 128 KiB | 0.50 GiB | 100 | 411,529 |
| Llama-3-8B | GQA | 8 | fp8 | 64 KiB | 0.25 GiB | 200 | 823,059 |

GQA: 3.8x more sequences; FP8 KV on top: 2.0x again (26 -> 100 -> 200).
