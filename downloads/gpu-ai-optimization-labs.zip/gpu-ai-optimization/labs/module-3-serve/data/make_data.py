#!/usr/bin/env python3
"""
Module 3 · Sample data — a deterministic request mix for the simulators.

Writes data/requests.csv: one row per chat request with
  arrival_s      when it arrives (Poisson arrivals, i.e. random gaps with a fixed average rate)
  prompt_tokens  how long the prompt is   (log-normal: most are short, a few are very long)
  output_tokens  how long the answer is   (log-normal, capped at max_tokens = 2048)

Real traffic looks like this: lengths are skewed, and you never know an answer's
length in advance. That uncertainty is exactly what wastes KV-cache memory (paged_sim.py)
and stalls static batches (batch_sim.py).

Usage:
  python3 data/make_data.py                 # 1,200 requests at 4 req/s, seed 7
  python3 data/make_data.py --n 3000 --rate 12 --seed 1
"""
import argparse, csv, math, os, random

HERE = os.path.dirname(os.path.abspath(__file__))
MAX_TOKENS = 2048


def lognormal_int(rng, median, sigma, lo, hi):
    return int(min(hi, max(lo, round(rng.lognormvariate(math.log(median), sigma)))))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--n", type=int, default=1200, help="number of requests")
    ap.add_argument("--rate", type=float, default=4.0, help="average arrivals per second")
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--out", default=os.path.join(HERE, "requests.csv"))
    a = ap.parse_args()

    rng = random.Random(a.seed)
    t = 0.0
    rows = []
    for i in range(a.n):
        t += rng.expovariate(a.rate)
        rows.append({"id": i, "arrival_s": f"{t:.4f}",
                     "prompt_tokens": lognormal_int(rng, 500, 0.8, 16, 6000),
                     "output_tokens": lognormal_int(rng, 180, 0.9, 4, MAX_TOKENS)})
    with open(a.out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader(); w.writerows(rows)
    p = sorted(r["prompt_tokens"] for r in rows); o = sorted(r["output_tokens"] for r in rows)
    print(f"wrote {a.out}: {a.n} requests over {t:.0f} s | prompt median {p[len(p)//2]} "
          f"| output median {o[len(o)//2]}, p99 {o[int(len(o)*0.99)]}, max {o[-1]} (cap {MAX_TOKENS})")


if __name__ == "__main__":
    main()
