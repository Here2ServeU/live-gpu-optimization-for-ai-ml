# Module 3 Lab · Size the Cache, Simulate the Batch

**Time:** ~50 minutes · **Runs on:** any laptop (Python 3.9+, no installs, offline) · **Optional:** a Linux machine with an NVIDIA GPU and vLLM

The model is fixed. Now you stop the server from wasting the GPU. You will build the tools an LLM inference engineer uses to reason about a serving stack before touching a config file:

| Script | Question it answers |
|---|---|
| `kv_calc.py` | How big is the KV cache per token and per user? How many users fit on this GPU? What do FP8 KV and GQA buy? |
| `paged_sim.py` | How much KV memory does "reserve for the longest answer" waste, and what does paging (16-token blocks) get back? |
| `batch_sim.py` | Static vs continuous batching on the same GPU and traffic: throughput, p50/p95 TTFT, p95 end-to-end, and where the max-batch knee is. |
| `prefix_cache_sim.py` | How much prefill does a shared system prompt save, and how does one timestamp destroy the hit rate? |
| `spec_decode.py` | When does speculative decoding pay off, and when does it make things slower? |

Every script is deterministic (seeded), takes `--help`, prints a readable table, and writes a markdown report into `reports/`. The traffic is `data/requests.csv`, made by `data/make_data.py` (1,200 chat requests, Poisson arrivals at ~4 req/s, skewed prompt and answer lengths, answers capped at 2,048 tokens). Model shapes are in `data/models.json` (public configs); GPU figures in `data/gpus.json` are the same as Module 1.

> **Honesty note.** `paged_sim.py` and `batch_sim.py` are *models of the scheduler*, not benchmarks. The step-time constants (decode step = 8 ms + 0.05 ms per sequence; prefill = 0.04 ms per prompt token) are illustrative, roughly an 8B FP16 model on one H100-class GPU. Change them with flags, and replace them with numbers measured on your own server (Optional GPU track). The *direction and size* of each effect is what you are learning; your absolute numbers will differ.

---

## Stage 1 · Set up (5 min)

```bash
# macOS / Linux
cd labs/module-3-serve
python3 -m venv .venv && source .venv/bin/activate
python3 data/make_data.py        # regenerates data/requests.csv (same seed, same file)
```
```powershell
# Windows PowerShell
cd labs\module-3-serve
py -m venv .venv; .venv\Scripts\Activate.ps1
py data\make_data.py
```
On Windows, use `py` wherever this guide says `python3`. Expected:

```
wrote .../data/requests.csv: 1200 requests over 290 s | prompt median 499 | output median 179, p99 1460, max 2048 (cap 2048)
```

## Stage 2 · Size the KV cache (10 min)

```bash
python3 kv_calc.py --list
python3 kv_calc.py --model llama-3-8b --context 8192 --users 32
python3 kv_calc.py --model llama-3-8b --context 8192 --users 32 --kv-dtype fp8 --out reports/kv_calc_fp8.md
python3 kv_calc.py --compare --gpu A100-80GB --context 4096
```

Expected (the first two lines are the classic interview arithmetic):

```
  KV per token   = 2 x 32 x 8 x 128 x 2 B = 131,072 B = 128 KiB
  per sequence   = 128 KiB x 8,192 tokens = 1.00 GiB
  32 users     = 32.0 GiB of KV cache  + 15.0 GiB of weights (fp16)

  GPU           KV budget  cache tokens max seqs @ 8,192  32 users?
  L4              3.3 GiB        27,008                3  no (3 max)
  L40S           23.4 GiB       191,802               23  no (23 max)
  A100-80GB      50.2 GiB       411,529               50  yes
```

With `--kv-dtype fp8` the L40S goes from 23 to **46** full-length sequences and the A100 from 50 to **100**. The comparison:

```
  Llama-2-7B  MHA (no GQA)        32     fp16   512 KiB  2.00 GiB        26       107,803
  Llama-3-8B  GQA                  8     fp16   128 KiB  0.50 GiB       100       411,529
  Llama-3-8B  GQA                  8      fp8    64 KiB  0.25 GiB       200       823,059
  GQA (32 -> 8 KV heads): 3.8x more sequences.  FP8 KV on top: 2.0x again (26 -> 100 -> 200).
```

Notice:
- **Weights are a fixed cost; the KV cache is the variable cost.** It grows with context length x concurrent users, and it decides how many users one GPU can hold.
- **GQA** (fewer KV heads than query heads) is chosen when the model is trained; you choose it by choosing the model. **FP8 KV** is a serving flag; check quality on your evals before you ship it.
- The budget assumes vLLM-style `gpu_memory_utilization 0.9` and 2 GB of runtime overhead. Measure your own overhead: the server logs how much KV cache it allocated at startup.

**Do:** size the KV cache for a model you care about at your real average context, not the maximum. How many users fit on one GPU?

## Stage 3 · Page the cache (8 min)

```bash
python3 paged_sim.py
python3 paged_sim.py --max-seqs 0 --out reports/paged_sim_nocap.md
python3 paged_sim.py --max-tokens 8192 --out reports/paged_sim_8k.md
```

Same 50 GiB budget, same request mix, two allocators. Expected:

```
               avg running  allocated KV  allocated KV  finished  preempted
                 sequences holding tokens        wasted  requests
  contiguous           134         33.5%         66.5%      1476          0
  paged                255         99.2%          0.8%      2803          0
  Paged runs 1.9x more sequences at once and finishes 1.9x more requests in the same number of steps.
  Contiguous also stranded 11.6% of the budget on average: free, but in holes too small for the next request.
```

- Reserving prompt + 2,048 tokens for every request wastes **two thirds** of the memory it reserves (internal fragmentation), and leaves **11.6%** of the budget in unusable holes (external fragmentation).
- Paging wastes **under 1%**: at most one half-empty 16-token block per sequence. The paged run here hits the 256-sequence cap (`--max-num-seqs` in vLLM), not the memory limit.
- With `--max-seqs 0` paged packs memory full: **444** sequences (3.3x), but **993 preemptions** when blocks run out mid-answer. That is why servers keep a reserve and a cap.
- With `--max-tokens 8192` (reserve for the full context) contiguous waste climbs to **90.1%** and only 40 sequences fit.

**Do:** run `--block 32` and `--block 8`. What changes, and why does waste stay tiny either way?

## Stage 4 · Batch it: static vs continuous (12 min)

```bash
python3 batch_sim.py --chunk 1024
python3 batch_sim.py --sweep
```

Expected (first command, abbreviated):

```
  At the recorded traffic (4.1 req/s)
  scheduler                   tok/s TTFT p50 TTFT p95  E2E p95  ITL p95  running  waiting
  static (B=256)              1,048    15.92    31.54     37.5     15.7    100.9     51.3
  continuous (max 256)        1,114     0.04     0.10      7.9      9.1     10.8      0.0

  At capacity (every request queued at once)
  static (B=256)              1,495   105.91   187.28    191.9     20.8    241.3    486.7
  continuous (max 256)        4,599    23.34    49.51     58.1    104.5    200.9    385.9
  continuous + chunk 1024     4,540    24.39    50.49     59.1     51.5    201.7    387.5

  static -> continuous (one change, same GPU, same traffic): capacity +208% (1,495 -> 4,599 tok/s), p95 TTFT 31.5 s -> 0.10 s, p95 end-to-end 37.5 s -> 7.9 s
  chunked prefill at capacity: ITL p95 104.5 -> 51.5 ms, throughput -1.3%
```

Read it:
- At normal traffic both schedulers deliver about the traffic you send them, so look at **latency**: static makes new requests wait for the slowest answer in the current group (p95 TTFT **31.5 s**). Continuous lets them join at the next step (**0.10 s**).
- At capacity, continuous does **3.1x** the work on the same GPU, because finished slots are refilled every step instead of idling until the longest answer is done.
- **ITL p95** (inter-token latency, the gap between streamed tokens) jumps at capacity because big prefills land in the same steps as decodes. **Chunked prefill** splits prompts into pieces and halves it, for about 1% throughput.
- **running vs waiting** is what your server's metrics page shows. A growing *waiting* number is the first sign you are past capacity.

The sweep (capacity, continuous scheduler):

```
  max batch |   static | continuous  ITL p95  running | TTFT p95
          1 |      123 |        123      8.1      1.0 |  2293.23
         16 |      472 |      1,513     13.8     15.6 |     0.60  (+225%)
         32 |      670 |      2,361     31.6     29.8 |     0.10  (+56%)
         64 |      941 |      3,265     48.9     56.2 |     0.10  (+38%)
        128 |    1,197 |      4,042     70.1    106.0 |     0.10  (+24%)
        256 |    1,495 |      4,599    104.5    200.9 |     0.10  (+14%)
        512 |    1,625 |      4,909    161.9    375.5 |     0.10  (+7%)
```

That is **the knee**: each doubling of max batch buys less throughput (+56%, +38%, +24%, +14%, +7%) and costs more per-token latency. At this traffic, anything from 32 up already gives a 0.10 s p95 TTFT. Choose the largest max batch whose ITL p95 still meets your target.

**Do:** run `python3 batch_sim.py --rate 6 --max-batch 64`. Where does the waiting queue start to grow?

## Stage 5 · Cache the prefix, speculate the decode (10 min)

```bash
python3 prefix_cache_sim.py
python3 spec_decode.py
```

Expected:

```
  prompt layout       hit rate  prefill tokens   saved  mean TTFT*
  no cache                0.0%       1,080,494    0.0%       86 ms
  stable-first           91.8%          88,494   91.8%        7 ms
  timestamp-first         0.0%       1,081,994    0.0%       87 ms
  timestamp-after        91.7%          89,994   91.7%        7 ms
```

A 2,000-token shared system prompt, stable part first: **92%** of prompt tokens come from cache and prefill work drops **12.2x**. Put "Current time: HH:MM:SS" at the top and the hit rate is **0%**: a block is reused only if it *and every block before it* match. Move the timestamp after the stable part and the hits come back.

```
  alpha |    k=1    k=2    k=3    k=4    k=5    k=6    k=7    k=8
    0.5 |  1.43   1.59   1.63*  1.61   1.57   1.53   1.48   1.43
    0.7 |  1.62   1.99   2.20   2.31   2.35   2.35*  2.33   2.28
    0.9 |  1.81   2.46   2.99   3.41   3.75   4.01   4.22   4.38*
  Where it stops paying:
    expensive draft, hard text  alpha 0.4, k 4, c 0.25:  0.82x  SLOWER than no speculation
  Monte-Carlo check, tokens per target pass:
    alpha 0.8, k 4:  formula 3.362   simulated 3.376
  Rejection sampling keeps the target's distribution: max error 0.002
```

The formula is from Leviathan et al. (2023): speedup = (1 - a^(k+1)) / ((1 - a)(k*c + 1)), with acceptance rate a, k drafted tokens, and c = draft cost / target cost. Predictable text (high a) speeds up most; an expensive draft on hard text makes it **slower**. The last check shows the rejection-sampling rule really does preserve the target model's output distribution.

---

## Change one thing (for FINDINGS.md)

The one change: **static batching -> continuous batching**, same GPU, same traffic, same max batch (256).

| | Static | Continuous | Change |
|---|---:|---:|---:|
| Capacity (output tok/s) | 1,495 | 4,599 | **+208%** |
| p95 TTFT at 4.1 req/s | 31.5 s | 0.10 s | **-99.7%** |
| p95 end-to-end at 4.1 req/s | 37.5 s | 7.9 s | **-79%** |

Supporting numbers from the other stages: paging cut wasted KV memory from **66.5% to 0.8%** of what was allocated; FP8 KV doubled concurrent 8K sequences on an A100 (**50 -> 100**); a stable-first prompt gave a **92%** prefix-cache hit rate, and a leading timestamp took it to **0%**.

---

## Optional GPU track (vLLM, Linux + NVIDIA GPU)

Not required. Use it to replace the simulator's constants with your own measurements. vLLM's flags, defaults and benchmark entry points change between versions: **check `vllm serve --help` and the docs for the version you installed** before copying these.

```bash
pip install vllm
# Serve with the knobs from this module (a gated model needs a Hugging Face token; any open model works)
vllm serve meta-llama/Meta-Llama-3-8B-Instruct \
  --max-model-len 8192 --max-num-seqs 256 \
  --gpu-memory-utilization 0.9 \
  --enable-prefix-caching --kv-cache-dtype fp8
```

1. **Read the startup log.** vLLM prints how much memory it gave the KV cache and how many tokens fit. Compare it with `kv_calc.py --gpu <yours>`.
2. **Benchmark the server.** Recent versions: `vllm bench serve --model <model> --dataset-name random --random-input-len 512 --random-output-len 256 --num-prompts 500 --request-rate 4`. Older versions ship `benchmarks/benchmark_serving.py` in the vLLM repo with similar flags. Record throughput, p50/p95 TTFT, and ITL/TPOT.
3. **Change one thing, re-run:** `--max-num-seqs 32` vs `256`; with and without `--enable-prefix-caching` on prompts that share a long prefix; `--kv-cache-dtype auto` vs `fp8`.
4. **Watch the scheduler:** `curl -s localhost:8000/metrics | grep -E "num_requests_running|num_requests_waiting|cache_usage|time_to_first_token"` (metric names vary by version).
5. **Profile a kernel (advanced):** `nsys profile -o serve vllm serve ...` with NVIDIA Nsight Systems, then look at where time goes between attention, matmuls and memory copies.

Speculative decoding is configured with a speculative-decoding option on `vllm serve` (its name and format have changed across versions; see the docs).

---

## Deliverable (portfolio)

Commit `reports/` and add to your `FINDINGS.md`:

1. KV cache per token and per user for one real model, and how many users fit on one GPU (FP16 and FP8 KV)
2. Wasted KV memory, contiguous vs paged
3. The one change: static -> continuous batching, with capacity and p95 TTFT before and after
4. The max-batch knee you would pick, and the latency target that decided it
5. One prompt-layout rule for your team (stable prefix first, nothing that changes at the top)

**Resume line you can now defend:** _Built a KV-cache sizing tool and an LLM serving simulator; showed continuous batching tripled capacity (+208% tokens/s) and cut p95 TTFT from 31.5 s to 0.10 s, and paged KV allocation cut wasted cache memory from 66.5% to under 1%._

## Interview check

- Estimate the KV cache for an 8B model at 8K context and 32 users. (128 KiB/token -> 1 GiB per sequence -> 32 GiB, plus ~15 GiB of weights; fits an 80 GB GPU, not a 24 GB one)
- Why does continuous batching beat static batching? (iteration-level scheduling: no idle slots waiting for the longest answer; no new request waiting for a whole group)
- What problem does PagedAttention solve? (KV fragmentation from reserving max length; fixed blocks on demand, like OS pages; prefix blocks can be shared)
- When does speculative decoding help, and when does it hurt? (high acceptance and a cheap draft help; low acceptance, a costly draft, too large a k, or big batches where the target is compute-bound hurt)
