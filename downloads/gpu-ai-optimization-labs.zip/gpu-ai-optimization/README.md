# GPU & AI Model Optimization

**Make AI models faster and cheaper to run, and prove it with numbers.**
A 6-module, hands-on course by Emmanuel Naweji · Transformed 2 Succeed

This course teaches the skills that ML Infrastructure, AI Platform, LLM Inference / Performance, and MLOps / SRE-for-AI roles hire for. Every module ends with a lab that produces a **portfolio artifact with real numbers**, three **interview questions** with strong answers, and a **resume line you can defend**.

## The six modules

| # | Module | You learn | Hands-on lab (`labs/`) | Portfolio artifact |
|---|---|---|---|---|
| 1 | **Measure Before You Optimize** | Cost per 1M tokens, compute- vs memory-bound (roofline), TTFT / TPOT / throughput, GPU observability, the optimization loop | `module-1-measure` — unit-cost scorecard, bottleneck calculator, GPU snapshot | Baseline + one change: −25% cost, −20% p95 TTFT |
| 2 | **Shrink the Model** | FP16 → FP8 → INT8 → INT4, per-channel and group-wise quantization, outliers, distillation, pruning and 2:4 sparsity, model routing | `module-2-shrink` — quantize, distill, prune, route a real (laptop-sized) model | Quality-checked quantization + routing report |
| 3 | **Serve It Smarter** | KV cache math, paged attention, continuous batching, prefix caching, long context, speculative decoding, FlashAttention | `module-3-serve` — KV-cache calculator, paging and batching simulators | Static → continuous batching before/after |
| 4 | **Run the GPU Fleet** | Right-sizing GPUs, MIG / time-slicing / MPS, autoscaling on queue depth, cold starts, choosing an inference engine | `module-4-fleet` — fleet planner, autoscaling simulator, cold-start model, Kubernetes + KEDA templates | Fleet plan: −60% $/hr; autoscaler comparison |
| 5 | **Train Efficiently at Scale** | Mixed precision and loss scaling, data-loader starvation, DDP / FSDP / TP / PP memory math, goodput, checkpoints, spot GPUs | `module-5-train` — a training loop that survives crashes and spot notices, bit-for-bit resume | Loader fix + goodput + spot cost model |
| 6 | **Prove It in Production** | Realistic LLM load testing, SLOs and error budgets, canary rollouts, performance per watt, telling the story | `module-6-capstone` — mock LLM server, load tester, SLO report, canary judge, power report | **Capstone** optimization report (`CAPSTONE.md`) |

## What you need

- A laptop (macOS, Windows or Linux) with **Python 3.9+** and **git**. No GPU required.
- Modules 1, 3, 4 and 6 use only the Python standard library. Modules 2 and 5 need `numpy` (`pip install -r requirements.txt` inside the lab).
- Optional: access to an NVIDIA GPU (cloud is fine). Each lab README has an **Optional GPU track** (nvidia-smi, DCGM, vLLM, Kubernetes) for real hardware.

```bash
git clone https://github.com/Here2ServeU/gpu-ai-optimization
cd gpu-ai-optimization/labs/module-1-measure
python3 -m venv .venv && source .venv/bin/activate     # Windows: py -m venv .venv; .venv\Scripts\Activate.ps1
python3 scorecard.py data/usage_baseline.csv
```

## How every lab works: the loop

1. **Measure** a baseline.
2. **Find the bottleneck** (compute, memory, network, data, or queueing).
3. **Change one thing.**
4. **Re-measure**, then write it down in `FINDINGS.md`.

By the end of Module 6 you have six `FINDINGS.md` files and a capstone report: a portfolio a hiring manager can read in five minutes.

## Honest labels

Lab numbers come from seeded simulations and laptop-scale models so everyone gets the same results offline. They teach the mechanics and the method. When you put a number on your resume, say whether it came from a simulation or a real system, and replace it with your own measured numbers as soon as you have them.
